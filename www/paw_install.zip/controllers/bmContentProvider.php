<?php

  final class bmContentProvider extends bmCustomContentProvider
  {
    
  }
?>