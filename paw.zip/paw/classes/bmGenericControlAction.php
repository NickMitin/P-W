<?php
  
  class bmGenericControlAction extends bmCustomAction {
    
    
    public function execute($sender, $arguments) {
      
      $methodName = $this->actionName;
      
      return $sender->ownerForm->$methodName($sender, $arguments);
      
    }
    
  }
  
?>
