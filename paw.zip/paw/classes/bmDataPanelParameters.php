<?php

  class bmDataPanelParameters extends bmCollection {
  
    public $collectionItemClass = "bmDataPanelParameter";
    public $keyPropertyName = "parameterName";
    
    
    
  }
?>