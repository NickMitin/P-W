<?php

  class bmCalendarStyles extends bmCustomControlStyles {
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('activeDay', pbValue, 'default');
      $this->serializeProperty('activeDayLink', pbValue, 'default');
      $this->serializeProperty('day', pbValue, 'default');
      $this->serializeProperty('dayLink', pbValue, 'default');
      $this->serializeProperty('navigatorLink', pbValue, 'default');
    
    }

  }

?>
