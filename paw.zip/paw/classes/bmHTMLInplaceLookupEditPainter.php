<?php

  class bmHTMLInplaceLookupEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    function draw($control, $dataControl, $dataCollection, $style) {
      $result = "";
      switch ($dataControl->mode) {
        case dcmView:
          $result .= $control->options->items[$control->value]->caption;
          break;
        case dcmEdit:
          $result = "<select class=\"$style\" style=\"width: 100%;\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[$control->keyValue]\">\n";
          foreach ($control->options->items as $item) {
            $result .= "<option value=\"$item->value\"" . (($item->selected) ? " selected=\"selected\"" : "") . ">$item->caption</option>\n";
            unset($item);
          }
          $result .= "</select>\n";
          break;
      }
      return $result;
    }
    
  }

?>
