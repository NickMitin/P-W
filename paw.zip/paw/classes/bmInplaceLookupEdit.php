<?php

  class bmInplaceLookupEdit extends bmCustomLookupEdit {
  
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      unset($this->serializedProperties["value"]);
      $this->dbAware = true;

    }
    
  }

?>