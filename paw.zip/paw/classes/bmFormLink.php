<?php

  class bmFormLink extends bmPersistentObject {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("formName", pbValue);

    }
  
  }
  
?>
