<?php

  class bmDateEdit extends bmCustomDateEdit {
  
  }

?>
