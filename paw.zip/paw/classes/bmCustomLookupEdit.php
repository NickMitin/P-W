<?php

  class bmCustomLookupEdit extends bmCustomOptionEdit {  
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('boundData', pbReference);
      if ($this->boundData != null) {
        $this->loadData();
      }

    }

    public function loadData() {
      $this->options->clear();
      $keyPropertyName = $this->keyPropertyName;
      $displayPropertyName = $this->displayPropertyName;
      $this->boundData->loadObjects();
      foreach ($this->boundData->dataObjects->items as $object) {
        $value = $object->$keyPropertyName;
        $option = $this->options->add($value);
        $option->selected = ($value == $this->value);
        $option->caption = $object->$displayPropertyName;
        $option->shouldSerialize = false;
      }
    }

    public function internalSetValue($value) {
      if ($this->options->count == 0) {
        $this->loadData();  
      }
      foreach($this->options->items as $option) {
        if ($option->value == $value) {

          $option->selected = true;
          $this->editValue = $value;
        } else {
          $option->selected = false;
        }
      }
    }

    public function setter($propertyName, $value) {
      switch ($propertyName) {
        case 'value':
          if ($value != $this->value) {
            if (array_key_exists($value, $this->options->items)) {
              $this->internalSetValue($value);
            } else {
              $this->application->errorHandler->addError(0, 'Cannot find apropriate value within the "' . $this->name . '" combo box items.');
            }
          }
        break;
      }
      parent::setter($propertyName, $value);
    }

  }

?>
