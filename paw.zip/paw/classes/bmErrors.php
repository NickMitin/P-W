<?php
  
  class bmErrors extends bmCollection {

    public $collectionItemClass = 'bmError';
    public $keyPropertyName = 'text';

  }
  
?>
