<?php

  class bmPagedControlActions extends bmPersistentObject {
  
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('pageChange', pbValue);
      $this->serializeProperty('sortColumn', pbValue);
    
    }
    
  }
  
?>
