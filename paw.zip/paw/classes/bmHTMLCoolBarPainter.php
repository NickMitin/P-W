<?php
  
  class bmHTMLCoolBarPainter extends bmHTMLStandaloneControlPainter {
    
    function drawControl($control) {
      $result = '<map id="' . $control->name . 'Map" name="' . $control->name . 'Map">';
      $i = 1;
      foreach ($control->buttons->items as $button) {
        print '?';
        if ($button->action != null) {
          $action = $button->action;
          print '!';
        } else {
          $action = 'main.php?application.switchForm=' . $control->ownerForm->name . '&amp;' . $control->getComponentString() . '.click=' . $button->caption;
        }
        switch (get_class($button)) {
          case 'bmCoolBarButton':
            $result .= '<area id="' . $control->name . 'Button' . ($i++) . '" shape="rect" alt="' . $button->caption . '" coords="' . $button->left . ',' . $button->top . ',' . $button->right . ',' . $button->bottom . '" href="' . $action . '"/>'; 
          break;
          case 'bmCoolBarShape':
            $result .= '<area id="' . $control->name . 'Button' . ($i++) . '" shape="poly" alt="' . $button->caption . '" coords="' . $button->coordinates . '" href="' . $action . '"/>';
          break;
        }
      }
      $result .= '</map>';
      $result .= '<img style="border-style: none;" src="' . $control->picture . '" alt="' . $control->name . '" usemap="#' . $control->name . 'Map"/>';
      return $result;
    }
    
  }
  
?>
