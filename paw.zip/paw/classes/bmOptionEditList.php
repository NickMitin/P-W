<?php

  class bmOptionEditList extends bmCollection {
  
    public $collectionItemClass = "bmOptionEditItem";
    public $keyPropertyName = "value";

  }

?>