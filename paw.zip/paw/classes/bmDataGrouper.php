<?php
  
  class bmDataGrouper extends bmPersistentObject {
    
    public $conditions = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->conditions = $this->createOwnedObject("bmDataGroupingConditions", array("name" => "conditions"));

    }
    
  }
  
?>