<?php
  
  class bmCalendar extends bmCustomCalendar {
    
    public $hasClientMirror = 1;
    
  }
  
?>
