<?php

  define("dtXHTMLStrict", "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
  
  class bmHTMLForm extends bmCustomForm {

    public $fileLinks = null;
    private $controlInstance = null;
    public $hasClientMirror = 1;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("title", pbValue, "Form");
      $this->serializeProperty("encoding", pbValue, "utf-8");
      $this->serializeProperty("contentType", pbValue, "text/html");
      $this->serializeProperty("documentType", pbValue, dtXHTMLStrict);
      $this->publishProperty("drawControl", pbValue);

    }
    
    public function drawControlSetter($value) {
      //$controlsTree = split("\.", $value);
      /*$controlsCount = count($controlsTree);
      if ($controlsCount > 0) {
        $currentControl = $this;
        $i = 0;
        while ($i < $controlsCount) {
          if (array_key_exists($controlsTree[$i], $currentControl->components)) {
            $currentControl = $currentControl->components[$controlsTree[$i]];
            if (!($currentControl instanceof bmCustomControl)) {
              return false;
            }
          } else {
            return false;
          } 
          ++$i; 
        }*/
        if (array_key_exists($value, $this->allComponents)) {
          $currentControl = $this->allComponents[$value];
        } else {
          return false;
        }
        header("content-type: " . $currentControl->ownerForm->contentType . "; charset=" . $currentControl->ownerForm->encoding, true);
        header('pragma: no-cache');
        $this->controlInstance = $currentControl;
        return true;
      //} else {
      //  return false;
      //}
    }
    
    public function draw() {
      
      if ($this->container) {
        $GLOBALS['loadedClasses'][] = 'bm' . $this->container;
      }
      
      $this->callEventHandler($this->onDrawing, null); 
      
      if ($this->controlInstance == null) {
        $this->controlInstance = $this;
      }
      return $this->controlInstance->painter->draw($this->controlInstance); 
      
    }

  }

?>
