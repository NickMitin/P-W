<?php

  class bmClassProperties extends bmCollection {

    public $collectionItemClass = "bmClassProperty";
    public $keyPropertyName = "propertyName";

  }

?>