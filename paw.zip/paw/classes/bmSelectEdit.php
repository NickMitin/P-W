<?php
  
  class bmSelectEdit extends bmCustomSelectEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
