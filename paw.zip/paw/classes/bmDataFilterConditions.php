<?php

  class bmDataFilterConditions extends bmCollection {

    public $collectionItemClass = "bmCustomDataFilterCondition";
    public $keyPropertyName = "propertyName";
    public $filter = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      if ($owner instanceof bmDataFilter) {
        $this->filter = $owner;
      } else {
        $this->filter = $owner->filter;
      }

    }
    
    public function addAtRunTime($propertyName, $conditionClassName) {
      $storeItemClass = $this->collectionItemClass;
      $this->collectionItemClass = $conditionClassName;
      $result = $this->add($propertyName);
      $this->collectionItemClass = $storeItemClass;
      return $result;
    }

  }

?>