<?php

  class bmLabel extends bmCustomLabel {
    
    public $hasClientMirror = 1;

  }

?>
