<?php

  define("mnfStandalone", 1);
  define("mnfInPlace", 2);
  define("mnfShort", 3);
  
  define("wdnfFull", 1);
  define("wdnfShort", 2);
  
  class bmDateUtils extends bmObject {
    
    public function monthToString($month, $format = mnfStandalone) {
      switch ($format) {
        case mnfStandalone:
          switch ($month) {
            case 1: return ducJanuary;
            case 2: return ducFebruary;
            case 3: return ducMarch;
            case 4: return ducApril;
            case 5: return ducMay;
            case 6: return ducJune;
            case 7: return ducJuly;
            case 8: return ducAugust;
            case 9: return ducSeptember;
            case 10: return ducOctober;
            case 11: return ducNovember;
            case 12: return ducDecember;
          }
        break;
        case mnfInPlace:
          switch ($month) {
            case 1: return ducInPlaceJanuary;
            case 2: return ducInPlaceFebruary;
            case 3: return ducInPlaceMarch;
            case 4: return ducInPlaceApril;
            case 5: return ducInPlaceMay;
            case 6: return ducInPlaceJune;
            case 7: return ducInPlaceJuly;
            case 8: return ducInPlaceAugust;
            case 9: return ducInPlaceSeptember;
            case 10: return ducInPlaceOctober;
            case 11: return ducInPlaceNovember;
            case 12: return ducInPlaceDecember;
          }
        break;
      }
    }
    
    public function weekDayToString($weekDay, $format = wdnfFull) {
      switch ($format) {
        case wdnfFull:
          switch ($weekDay) {
            case 1: return ducMonday;
            case 2: return ducTuesday;
            case 3: return ducWednsday;
            case 4: return ducThursday;
            case 5: return ducFriday;
            case 6: return ducSaturday;
            case 7: return ducSunday;
          }
        break;
        case wdnfShort:
          switch ($weekDay) {
            case 1: return ducMondayShort;
            case 2: return ducTuesdayShort;
            case 3: return ducWednsdayShort;
            case 4: return ducThursdayShort;
            case 5: return ducFridayShort;
            case 6: return ducSaturdayShort;
            case 7: return ducSundayShort;
          }
        break;
      }
    }
    
    private function escapeString($value) {
      return addcslashes($value, 'dDjlNSwzWFmMntLoYyaABgGhHiseIOTZcrU');
    }
    
    private function fixMonth($before, $monthMarker, $after, $date) {
      $month = date("n", $date);
      $format = ($monthMarker == "F") ? mnfInPlace : mnfShort;
      $month = $this->monthToString($month, $format);
      $month = $this->escapeString($month);
      return $before . $month . $after;
    }
    
    public function SQLTimeToUnixTime($value) {
      preg_match('/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/', $value, $matches);
      return gmmktime($matches[4], $matches[5], $matches[6], $matches[2], $matches[3], $matches[1]);
    }
    
    public function unixTimeToSQLTime($value) {
      $month = gmdate('m', $value);
      $day = gmdate('d', $value);
      $year = gmdate('Y', $value);
      $hour = gmdate('H', $value);
      $minute = gmdate('i', $value);
      $second = gmdate('s', $value);
      return $year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':' . $second;
    }
    
    public function dateToString($date, $format = null) {
      
      if (!isset($format)) {
        $format = ducTextualFormat;
      }
      
      $format = preg_replace('/(\b)([FM])(\b)/sUe', '$this->fixMonth("\1", "\2", "\3", $date);', $format);
      $result = gmdate($format, $date);
      return $result;
        
    }
    
  }
  
?>
