<?php

  class bmFileEditStyles extends bmCustomControlStyles {
    
  }

?>
