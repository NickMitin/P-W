<?php
  
  class bmFlashStyles extends bmCustomControlStyles {
    
  }
  
?>
