<?php

  define('ctStandard', 1);
  define('ctGrouping', 2);

  class bmDataColumn extends bmCollectionItem {
  
    public $inplaceEdit = null;
    public $styles = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('caption', pbValue);
      $this->serializeProperty('propertyName', pbValue);
      $this->serializeProperty('visible', pbValue, true);
      $this->serializeProperty('type', pbValue, ctStandard);
      $this->serializeProperty('readOnly', pbValue, false);
      $this->serializeProperty('inplaceEditClass', pbValue, 'bmInplaceTextEdit');
      
      $inplaceEditClass = (array_key_exists('inplaceEditClass', $parameters)) ? $parameters['inplaceEditClass'] : $this->inplaceEditClass;
      $this->inplaceEditClass = $inplaceEditClass;
      $this->inplaceEdit = $this->createOwnedObject($inplaceEditClass, array('name' => 'inplaceEdit'));
      $this->styles = $this->createOwnedObject('bmDataColumnStyles', array('name' => 'styles'));
    }
    
    public function setter($propertyName, $value) {
      
      switch ($propertyName) {
        case 'type':                               
          $dataControl = $this->owner->owner;
          switch ($value) {
            case ctGrouping:
              $this->visible = false;
            break;
          }
          parent::setter($propertyName, $value);
        break;
        /*case "visible":
          if ($this->type != ctGrouping) {
            if ($value) {
              $dataControl->visibleCount = $dataControl->visibleCount + 1;
            } else {
              $dataControl->visibleCount = $dataControl->visibleCount - 1;
            }
            parent::setter($propertyName, $value);
          }
        break;*/
        default:
          parent::setter($propertyName, $value);
        break;
      }
      
    }
    
  }

?>
