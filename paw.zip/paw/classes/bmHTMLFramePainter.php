<?php
  
  class bmHTMLFramePainter extends bmHTMLStandaloneControlPainter {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
    }
    
    function drawControl($control) {
      return '<object id="' . $control->name . 'Frame" style="width: 99%; height: 99%" type="text/html" data="./main.php?application.switchForm=' . $control->formName . '" />';
    }
    
  }
  
?>
