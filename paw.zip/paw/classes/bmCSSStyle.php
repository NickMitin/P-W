<?php

  define("bsNone", "none");
  define("bsSolid", "solid");
  
  define("haLeft", "left");
  define("haCenter", "center");
  define("haRight", "right");
  define("haJustify", "justify");

  define("vaBaseline", "baseline");
  define("vaMiddle", "middle");
  define("vaSub", "sub");
  define("vaSuper", "super");
  define("vaTextTop", "text-top");
  define("vaTextBottom", "text-bottom");
  define("vaTop", "top");
  define("vaBottom", "bottom");

  class bmCSSStyle extends bmCustomStyle {
  
    public $fontClass = "bmCSSFont";
    public $backgroundImageClass = "bmCSSBackgroundImage";

    function toCSS() {
      $result = " ." . $this->styleName . " {color: $this->foreColor; background-color: $this->backColor; text-align: $this->horizontalAlign; vertical-align: $this->verticalAlign; border: $this->borderStyle $this->borderWidth $this->borderColor;";
      $result .= $this->font->toCSS();
      $result .= $this->backgroundImage->toCSS(); 
      $result .= "}";
      return $result;
    }

  }

?>