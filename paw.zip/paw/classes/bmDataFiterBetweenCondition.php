<?php

  class bmDataFilterBetweenCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("lowerBoundary", pbValue);
      $this->serializeProperty("upperBoundary", pbValue);

    }

  }

?>
