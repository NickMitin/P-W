<?php

  class bmDataTileGridStyles extends bmCustomControlStyles {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("grid", pbValue, "default");
      $this->serializeProperty("oddRow", pbValue, "default");
      $this->serializeProperty("evenRow", pbValue, "default");
      $this->serializeProperty("footer", pbValue, "default");
      $this->serializeProperty("newRow", pbValue, "default");
      $this->serializeProperty("oddDataTile", pbValue, "default");
      $this->serializeProperty("evenDataTile", pbValue, "default");
      $this->serializeProperty("groupingRow", pbValue, "default");
      $this->serializeProperty("pageNumber", pbValue, "default");
      $this->serializeProperty("currentPageNumber", pbValue, "default");

    }

  }

?>
