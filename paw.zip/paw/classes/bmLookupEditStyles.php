<?php
  
    class bmLookupEditStyles extends bmCustomControlStyles {
    
  }
  
?>