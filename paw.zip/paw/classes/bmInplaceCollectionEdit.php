<?php
  
  class bmInplaceCollectionEdit extends bmCustomCollectionEdit {
    
    public $value = null;
    
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      $this->deletePersistentProperty("value");
      
      $this->application->clientScripts->add("./paw/scripts/bmCollectionEdit.js");

    }
    
  }
  
?>
