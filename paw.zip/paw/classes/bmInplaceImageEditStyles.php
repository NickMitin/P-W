<?php
  
  class bmInplaceImageEditStyles extends bmCustomControlStyles {
    
      
    
  }
  
?>
