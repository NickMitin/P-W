<?php
  
  class bmInplaceMemoEditStyles extends bmCustomControlStyles {
    
  }
  
?>
