<?php

  abstract class bmCollectionItem extends bmPersistentObject {
  
    public $collection = null;
    public $collectionOwner = null;
    public $index = 0;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      if ($owner instanceof bmCollection) {
        $owner->items[$parameters["name"]] = $this;
        $this->index = $owner->count;
        $owner->count++;
        $this->collection = $owner;
        $this->collectionOwner = $owner->collectionOwner;
      }

    }
    
    public function getComponentString() {
      return $this->owner->getComponentString() . "." . $this->name; 
    }

  }

?>
