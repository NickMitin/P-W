<?php

  define("pbValue", 1);
  define("pbReference", 2);
  define("pbSet", 3);

  abstract class bmPersistentObject extends bmObject {

    public $name = "";
    public $isProperty = false;
    public $shouldSerialize = true;
    public $fNode = null;
    public $map = null;
    protected $persistentProperties = array();
    protected $publishedMethods = array();      

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->name = $parameters["name"];
      if ($this->map == null) {
        $this->map = $owner->map;
      }
      if (isset($owner) && ($owner->fNode != null) && ($this->map === $owner->map)) {
        $xPath = new DOMXPath($this->map);
        $nodes = $xPath->query('object[@name=\'' . $this->name . '\']', $owner->fNode);
        if ($nodes->length) {
          $this->node = $nodes->item(0);
        }
      } elseif ($this->fNode != null) {
        $xPath = new DOMXPath($this->map);
        $nodes = $xPath->query('object[@name=\'' . $this->name . '\']');
        if ($nodes->length) {
          $this->node = $nodes->item(0);
        }
      }
    }

    public function getNode() {
      return $this->fNode;
    }
    
    public function restoreValue($propertyName) {
      $this->$propertyName = $this->persistentProperties[$propertyName]->initialValue;
    }
    
    public function valueFromXML($propertyName) {
      return $this->persistentProperties[$propertyName]->fromXML;
    }

    public function getter($propertyName) {
      switch ($propertyName) {
        case "node":
          if ($this->fNode == null) {
            $this->fNode = $this->map->createElement("object");
            $this->fNode->setAttribute("class", get_class($this));
            $this->fNode->setAttribute("name", $this->name);
            $this->fNode->setAttribute("isProperty", $this->isProperty);
            $this->fNode->setAttribute("hasClientMirror", $this->hasClientMirror);
            if (isset($this->owner)) {
              $this->owner->node->appendChild($this->fNode);
            }
          }
          return $this->fNode;
        break;
        default:
          if (array_key_exists($propertyName, $this->persistentProperties)) {
            return $this->persistentProperties[$propertyName]->value;
          }                         
        break;
      }
    }

    public function setter($propertyName, $value) {
      switch ($propertyName) {
        case "node":
          $this->fNode = $value;
        break;
        default:
          if (array_key_exists($propertyName, $this->persistentProperties)) {
            $this->persistentProperties[$propertyName]->value = $value;
          }
        break;
      }
    }

    protected function serializeProperty($name, $passBy, $defaultValue = null) {
      if (!array_key_exists($name, $this->persistentProperties)) {
        $this->addPersistentProperty("bmPersistentProperty", $name, $passBy, $defaultValue);
      }
    }
    
    protected function publishProperty($name, $type, $defaultValue = null) {
      if (!array_key_exists($name, $this->persistentProperties)) {
        $this->addPersistentProperty("bmPublishedProperty", $name, $type, $defaultValue);
      }
    }
    
    protected function deletePersistentProperty($name) {
      if (array_key_exists($name, $this->persistentProperties)) {
        $property = $this->persistentProperties[$name];
        if ($property->fNode != null) {
          $this->fNode->removeChild($property->fNode);
          $this->fNode = null;
        }
        unset($this->persistentProperties[$name]);
      }
    }

    protected function publishMethod($name) {
      $this->publishedMethods[$name] = 1;
    }

    protected function addPersistentProperty($propertyClass, $name, $type, $defaultValue = null) {
      $property = new $propertyClass($this->application, $this, array("name" => $name, "type" => $type, "defaultValue" => $defaultValue));
      $this->persistentProperties[$name] = $property;
    }
    
    function customHandleRequest($elementName, $value) {
      return false;
    }

    function customHandleUploadedFile($file) {
      return false;
    }

    public function handleRequest($elementName, $value) {
      if ($this->customHandleRequest($elementName, $value) === true) {
        return true;
      } elseif (preg_match("/^([A-Za-z][A-Za-z0-9]*)(.*?)$/", $elementName, $matches)) {
        $elementName = $matches[1];
        if (strlen($matches[2])) {
          $component = null;
          $furtherRequest = substr($matches[2], 1);
          if (is_object($this->$elementName)) {
            $component = $this->$elementName;
            if (!($component instanceof bmPersistentObject)) {
              $component = null;
            } 
          }
          if ($component != null) {
            $component->handleRequest($furtherRequest, $value);
          } else {
            $this->application->errorHandler->addError(0, "The \"$elementName\" object doesn't exist within the \"$this->name\" object.");
          }
        } else {

          if (array_key_exists($elementName, $this->persistentProperties) && ($this->persistentProperties[$elementName]->scope == psPublished)) {
            $setterName = $elementName . "Setter";
            if (method_exists($this, $setterName)) {
              if (!$this->$setterName($value)) {
                $this->application->errorHandler->addError(0, 'Invalid "' . $this->name . '.' . $elementName.  '" property value.');                
              }    
            } else {
              $this->application->errorHandler->addError(0, "There is no setter defined for the \"" . $this->name . ".$elementName\" property.");
            }  
          } elseif (array_key_exists($elementName, $this->publishedMethods)) {
            $this->$elementName($value);  
          } else {                                                            
            $this->application->errorHandler->addError(0, "The \"" . $this->name . "\" object does not contain or publish the \"" . $elementName . "\" property or method.");
          }
        }
      } else {
        //TODO ERROR
      }
    }
    
    public function createOwnedObject($className, $parameters = null, $isProperty = true) {
      if ($className == "bmObjectLink") {
        $link = new $className($this->application, $this, $parameters);
        $objectNode = $this->ownerForm->map->importNode($link->object->fNode, true);
        $objectNode->setAttribute('name', $link->name);
        $this->fNode->replaceChild($objectNode, $link->fNode);
        $object = parent::createOwnedObject(get_class($link->object), array("name" => $link->name), $link->object->isProperty); 
        unset($link);
      } else {
        $object = parent::createOwnedObject($className, $parameters, $isProperty);
      }
      return $object;
    }
    
  }

?>
