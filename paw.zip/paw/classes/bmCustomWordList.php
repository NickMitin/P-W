<?php

  class bmCustomWordList extends bmCustomDataControl {

    public $items = null;
    public $rowToolBarButtons = null;
    public $inplaceRowEditing = true;
    public $optionsView = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->publishMethod('editRow');
      $this->publishMethod('deleteRow');
    
      $this->serializeProperty('onCustomDrawDataRow', pbValue);

      $this->rowToolBarButtons = $this->createOwnedObject('bmDataRowToolBarButtons', array('name' => 'rowToolBarButtons'));
      $this->items = $this->createOwnedObject('bmDataColumns', array('name' => 'items'));
      $this->optionsView = $this->createOwnedObject('bmWordListOptionsView', array('name' => 'optionsView'));
      
      if (($this->items->count == 0) && ($this->boundData != null)) {
        foreach ($this->boundData->boundDataMap->dataObjectMaps->items as $objectMap) {
          foreach ($objectMap->propertiesMap->items as $propertyMap) {
            $item = $this->items->add($propertyMap->propertyName);
            $item->caption = $propertyMap->propertyName;
          }
        }
      }
      
      if ($this->optionsView->rowToolBar) {
        if (!$this->items->exists('toolBar')) {
          $item = $this->items->add('toolBar', 'bmInplaceToolBar'); 
          $item->shouldSerialize = false;
          $item->caption = 'Операции';
        }
        $buttons = $this->rowToolBarButtons;
        if (!$buttons->exists('delete')) {
          $button = $buttons->add('delete');
        } else {
          $button = $buttons->items['delete'];
        }
        if (!$button->valueFromXML('resource')) {
          $button->resource = 'bDelete';
        }
        if (!$button->valueFromXML('type')) {
          $button->type = drtbbDelete;
        }
        
        if ($buttons->exists('edit')) {
          if (!$this->boundData->optionsData->save) {
            $buttons->delete('edit');
          }
        } else {
          if ($this->boundData->optionsData->save) {
            $button = $buttons->add('edit');
            $button->resource = 'bEdit';
            $button->type = drtbbEdit;
          }
        }
      }
      
      if ($this->mode == dcmEdit) {
        $column = $this->columns->add('delete', 'bmInplaceCheckBoxEdit');
        $column->shouldSerialize = false;
        $column->caption = 'Удалить';
      }

    }
    
    public function deleteRow($dataObjectId) {
      if (($result = $this->callEventHandler($this->onDeleteRow, array('dataObjectId' => $dataObjectId))) === false) { 
        $this->boundData->deleteObject($dataObjectId);
      }
    }
    
    public function editRow($dataObjectId) {
      
      $array = $this->editModeRecordList;
      
      if (($key = array_search($dataObjectId, $array)) === false) {
        $array[] = $dataObjectId;
      } else {
        unset($array[$key]);
      } 
      
      $this->editModeRecordList = $array; 
      
      //if (($result = $this->callEventHandler($this->onEditRow, array('dataObject' => $dataObjectId))) === false) {
        //$this->boundData->deleteObject($dataObjectId);
      //}
      
    }
    
    public function loadData() {
      $this->boundData->flush();
      $this->boundData->loadObjects();
    }

  }
?>
