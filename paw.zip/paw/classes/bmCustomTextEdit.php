<?php

  class bmCustomTextEdit extends bmCustomEdit {
    
    public function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("readOnly", pbValue, false);
    }

  }

?>
