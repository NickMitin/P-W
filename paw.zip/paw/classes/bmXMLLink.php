<?php

  class bmXMLLink extends bmCustomDataLink {
    
    public function countObjects($dataSource, $filter = null) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName . ".xml");    
      $navigator = new DOMXPath($xml);
      
      return $navigator->query("/table/row")->length;
      
    }
    
    public function loadObjects($dataSource, $filter = null, $grouper = null, $sorter = null, $range = null) { 
      
      $mainObjectName = $dataSource->boundDataMap->objectName;
      
      $xml = new DOMDocument();
      $xml->load($this->database . $mainObjectName . ".xml");    
      $navigator = new DOMXPath($xml);
      
      $dataObjects = $dataSource->dataObjects;
      $dataObjects->clear();
      
      $query = "/table/row";
      
      $condition = false;
      
      if ($range != null) {
        
        $query .= '[' . $this->rangeToXPath($range);
        $condition = true;
      }
      
      if ($condition) {
        $query .= ']';
      }
      
      $objectMaps = $navigator->query($query);
      
      foreach ($objectMaps as $objectMap) {
        $id = $objectMap->getAttribute("id");
        $object = $dataObjects->add($id); 
        foreach ($objectMap->childNodes as $propertyMap) {
          $propertyName = $propertyMap->nodeName;
          $object->$propertyName = $propertyMap->nodeValue;
        }
      }
      
    }
    
    public function saveObjects($objects, $objectProperties) {
      foreach ($objects->items as $object) {
        foreach ($objectProperties->items as $property) { 
          $propertyName = $property->propertyName;
          $object->$propertyName = $this->newValues->$propertyName[$object-id];
          $this->saveObject($object, $objectProperties);  
        }
      }
    }
    
    public function objectExists($dataSource, $id) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName . ".xml");
      $navigator = new DOMXPath($xml);
      $objectMaps = $navigator->query("/table/row[@id='$id']");
      if ($objectMaps->length) {
        return ($objectMap = $objectMaps->item(0));
      } else {
        return false;
      }
    }
    
    public function newObject($dataSource, $id) {
      if (!$this->objectExists($dataSource, $id)) {
        return $this->internalNewObject($dataSource, $id);
      } else {
        return false;
        //TODO ERROR HERE
      }
    }
    
    public function internalNewObject($dataSource, $id) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName . ".xml");    
      $navigator = new DOMXPath($xml);
      
      $tables = $navigator->query("/table");
      $table = $tables->item(0);
      $objectMap = $xml->createElement("row");
      $objectMap->setAttribute("id", $id);
      $table->appendChild($objectMap);
      $object = $dataSource->dataObjects->add($id);
      $xml->save($this->database . $dataSource->boundDataMap->objectName . ".xml");
      return $object;
    }
    
    public function loadObject($dataSource, $id) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName . ".xml");    
      $navigator = new DOMXPath($xml);
      
      $objects = $dataSource->dataObjects;
      
      if ($objectMap = $this->objectExists($dataSource, $id)) {
        
        if (array_key_exists($id, $objects->items)) {
          $object = $objects->items[$id];
        } else {
          $object = $objects->add($id);  
        }
        
        $query = "/table/row[@id='" . $id . "']";
        
        $objectMap = $navigator->query($query)->item(0);
          
        foreach ($objectMap->childNodes as $propertyMap) {
          $propertyName = $propertyMap->nodeName;
          $object->$propertyName = $propertyMap->nodeValue;
        }
        return $object;
      } else {
        //TODO ERROR HERE;
      } 
    } 
    
    public function saveObject($dataSource, $id) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName . ".xml");
      $navigator = new DOMXPath($xml);
      
      $objectMap = $dataSource->boundDataMap->dataObjectMaps->items[$dataSource->boundDataMap->objectName];
      $object = $dataSource->dataObjects->items[$id]; 
      foreach ($objectMap->propertiesMap->items as $propertyMap) {
        $propertyName = $propertyMap->propertyName;
        $propertyContainer = $navigator->query("/table/row[@id='$id']/$propertyName");
        $propertyItem = $propertyContainer->item(0);
        $propertyItem->nodeValue = $object->$propertyName;
      }
      $xml->save($this->database . $dataSource->boundDataMap->objectName . ".xml");  
      return $object;
    }
    
    public function deleteObject($dataSource, $id) {
      
      $xml = new DOMDocument();
      $xml->load($this->database . $dataSource->boundDataMap->objectName. ".xml");
      $navigator = new DOMXPath($xml);
      
      if ($objectMap = $this->objectExists($dataSource, $id)) {
        $table = $xml->documentElement;
        $objectMap = $navigator->query("/table/row[@id='$id']")->item(0);
        $table->removeChild($objectMap);
        $dataSource->dataObjects->delete($id);
        $xml->save($this->database . $dataSource->boundDataMap->objectName . ".xml");  
        return true;
      } else {
        //TODO ERROR HERE;
        return false;
      }
    }
    
    public function deleteObjects($objects, $filter = null) {
    }
    
    //TODO
    public function applyFilter($objectMap, $filter) {
      
      $condition = $filter->conditions->internalItems[0];
      $propertyName = $condition->propertyName;
      if ((string)$objectMap->$propertyName == $condition->value) {
        return true;
      }
      return false;
    }
    
    private function rangeToXPath($range) {
      return ($range->length == 0) ? '' : 'position() >= ' . ($range->start + 1) . ' and position() <= ' . ($range->start + $range->length);
    }

    public function connect() {
      return true;
    }

    public function disconnect() {
      return true; 
    }
    
    public function formatValue($value) {
    }
    
  }

?>
