<?php

  class bmRadioGroupEditStyles extends bmCustomControlStyles {
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('item', pbValue);
    
    }

  }

?>
