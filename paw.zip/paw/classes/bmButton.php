<?php

  class bmButton extends bmCustomButton {
    
    public $hasClientMirror = 1;
    
  }
  
?>
