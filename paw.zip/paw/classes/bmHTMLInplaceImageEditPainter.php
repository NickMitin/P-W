<?php

  class bmHTMLInplaceImageEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    function draw($control, $dataControl, $dataCollection, $style) {
      $validator = $this->application->validator;
      $result = '';
      $currentObject = $dataControl->boundData->dataObjects->items[$control->keyValue];
      $preview = $control->preview;
      if ($control->alternativeText != null) {
        $description = $currentObject->$control->alternativeText;
      } else {
        $description = '';
      }
      $value = $this->application->validator->formatXMLValue($control->value);
      if ($control->boundImage) {
        $href = $this->application->path . 'main.php?application.switchForm=' . $control->boundImage->ownerForm->name . '&' . $control->boundImage->getComponentString() . '.picture=' . $value;
        
        /*$clientEvent = 'application.createForm(this.href, \'' . $control->clientName . '\'); return false;';
        $clientEvents = ' onclick="' . $clientEvent . '" onkeypress="' . $clientEvent . '"';*/
        $clientEvents = '';
        $result .= '<a style="display: block;" href="' .$href . '" ' . $clientEvents . '>';
      }
      $width = ($control->width) ? ' width: ' . $control->width . ';' : '';
      $height = ($control->height) ? ' height: ' . $control->height . ';' : '';
      $result .= '<img style="border-style: none;' . $width . $height . '" src="' . $this->application->path . 'files/' . $currentObject->$preview . '" alt="' . $description . '"/>';
      if ($control->boundImage) {
        $result .= '</a>';
      }
      switch ($dataControl->mode) {
        case dcmEdit:
          if ($control->allowUpload) {
            $result .= '<input type="file" name="' . $dataControl->boundData->getComponentString() . '.' . $dataCollection . '.' . $control->owner->propertyName . '.file[' . $validator->formatXMLValue($control->keyValue) . ']"/>';
            $result .= '<input type="hidden" name="' . $dataControl->boundData->getComponentString() . '.' . $dataCollection . '.' . $control->owner->propertyName . '[' . $control->keyValue . ']" value="' . $validator->formatXMLValue($control->value) . '"/>';
          }
        break;
      }
      return $result;
    }

/*    function drawInDataCell() {
      $result = $this->drawImage();
      $control = $this->control;
      $dataControl = $control->owner->collectionOwner;
      switch ($dataControl->mode) {
        case gmEdit:
        $result .= '<br/>\n' . $this->drawUploadControl();
      }
      return $result;
    }

    function drawInNewRow() {
      $control = $this->control;
      $control->keyValue = 0;
      $control->value = 'newFile';
      $result = $this->drawUploadControl();
      return $result;
    }

    function drawUploadControl() {
      $control = $this->control;
      $dataControl = $control->owner->collectionOwner;
      $result = '<input type="file" name="' . $dataControl->dataSource->getComponentString() . '.newValues.' . $control->owner->propertyName . '.file[' . $control->keyValue . ']"/>\n';
      $result .= '<input type="hidden" name="' . $dataControl->dataSource->getComponentString() . '.newValues.' . $control->owner->propertyName . '[' . $control->keyValue . ']" value="' . $this->application->validator->formatOutput($control->value, true) . '"/>\n';
      return $result;
    }      */
  }

?>
