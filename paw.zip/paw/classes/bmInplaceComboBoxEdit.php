<?php

  class bmInplaceComboBoxEdit extends bmCustomComboBoxEdit {
  
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      $this->dbAware = true;

    }
    
  }

?>