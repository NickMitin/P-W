<?php

  class bmDataGridOptionsBehaviour extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('hotTrack', pbValue, false);

    }

  }

?>
