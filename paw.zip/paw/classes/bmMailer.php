<?php

  define('mHeaderLineTerminator', "\r\n");
  
  class bmMailer extends bmPersistentObject {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('contentType', pbValue, 'text/plain');
      $this->serializeProperty('charset', pbValue, 'utf-8');
      
      
    }
    
    public function sendMail($recipient, $subject, $text, $from = null) {
      
      $headers  = 'MIME-Version: 1.0' . mHeaderLineTerminator;
      $headers .= 'content-type: ' . $this->contentType . '; charset=' . $this->charset . mHeaderLineTerminator;
      if (is_array($recipient)) {
        $recipient = join(', ', $recipient);
      }
      $headers .= 'To: ' . $recipient . mHeaderLineTerminator;
      if ($from != null) {
        $headers .= 'From: ' . $from . mHeaderLineTerminator;
      }
      
      $text = wordwrap($text, 70);
      
      return mail($recipient, $subject, $text, $headers);
      
    }
    
  }
    
?>
