<?php

  class bmCoolBarButtons extends bmCollection {

    public $collectionItemClass = "bmCustomCoolBarButton";
    public $keyPropertyName = "caption";

  }

?>