<?php

  define('pcmLowerCaseLetters', 1);
  define('pcmUpperCaseLetters', 2);
  define('pcmDigits', 4);
  define('pcmAllChars', 7);
  
  define('elSuccess', 0);
  define('elNoUserName', 1);
  define('elNoPassword', 2);
  define('elInvalidUser', 4);
  define('elAlreadyLoggedIn', 8);
  define('elNotLoggedIn', 16);

  class bmUserInfo extends bmComponent {

    private $user = null;
    public $fBoundData = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->fBoundData = $this->createOwnedObject("bmDataSource", array("name" => "boundData"));
      $boundDataMap = $this->fBoundData->boundDataMap;
      if (!$boundDataMap->dataObjectMaps->exists('user')) {
        $boundDataMap->objectName = 'user';
        $object = $boundDataMap->dataObjectMaps->add('user'); 
      } else {
        $object = $boundDataMap->dataObjectMaps->items['user']; 
      }
      if (!$object->propertiesMap->exists('password')) {
        $propertyMap = $object->propertiesMap->add('password');
        $propertyMap->fieldName = 'password';
      }
      if (!$object->propertiesMap->exists('email')) {
        $propertyMap = $object->propertiesMap->add('email');
        $propertyMap->fieldName = 'email';
      }
      if (!$object->propertiesMap->exists('lastActivity')) {
        $propertyMap = $object->propertiesMap->add('lastActivity');
        $propertyMap->fieldName = 'lastActivity';
      }
      if (!$object->propertiesMap->exists('timeOffset')) {
        $propertyMap = $object->propertiesMap->add('timeOffset');
        $propertyMap->fieldName = 'timeOffset';
      }
      $this->load(); 

    }
    
    public function load() {
      
      $session = $this->application->session;
      if ($session->persistent) {
        $this->user = $this->fBoundData->loadObject($session->userId);
      } else {
        $this->user = $this->fBoundData->newObject($session->userId);
      }
      $this->user->lastActivity = time();
      
    }
    
    public function save() {
      
      if ($this->application->session->persistent) {
        $this->fBoundData->saveObject($this->user->id);
      }
    }
    
    public function login($userName, $password, $showMessages = true) {
      $error = false;
      $errorFlags = 0;
      if (!($this->application->validator->validateText($userName, true, false))) {
        $errorFlags = $errorFlags | elNoUserName;
        $error = true;
      }
      if (!($this->application->validator->validateText($password, true, false))) {
        $errorFlags = $errorFlags | elNoPassword;
        $error = true;
      }
      if ($error) {
        return $errorFlags;
      }
      $session = $this->application->session;
      if (!$session->persistent) {
        $filter = $this->fBoundData->filter;
        $condition = $filter->conditions->addAtRunTime('id', 'bmDataFilterBinaryCondition');
        $condition->objectName = 'user';
        $condition->operation = oEqual;
        $condition->value = $userName;
        $condition->conjunction = cAnd;
        $condition = $filter->conditions->addAtRunTime('password', 'bmDataFilterBinaryCondition');
        $condition->objectName = 'user';
        $condition->operation = oEqual;
        $condition->value = md5($password);
        $this->fBoundData->loadObjects();
        $users = $this->fBoundData->dataObjects;
        if ($users->count == 1) {
          $this->user = current($users->items);
          $userName = $this->user->id;
          $session->userId = $userName;
          $session->restoreSessionFiles($userName); 
          $session->persistent = true;
          if ($showMessages) {
            $this->application->errorHandler->addError(0, 'Login successful! user id: ' . $userName . ', role: Content Editor');
          }
          $session->deleteSessionsByUser($userName);
          return elSuccess;
        } else {
          if ($showMessages) {
            $this->application->errorHandler->addError(0, 'Invalid users creditials!');
          }
          return elInvalidUser;
        }
      } else {
        if ($showMessages) {
          $this->application->errorHandler->addError(0, 'Aleady logged in!');  
        }
        return elInvalidUser;
      }
    }
    
    public function logout($showMessages = true) {
      $session = $this->application->session;
      if ($session->persistent) {
        $session->userId = 'guest';
        $this->user = $this->fBoundData->newObject($session->userId);
        $session->persistent = false; 
        if ($showMessages) {
          $this->application->errorHandler->addError(0, 'Logout successful!');
        }
        return elSuccess;
      } else {
        if ($showMessages) {
          $this->application->errorHandler->addError(0, 'Not logged in!');
        }
        return elNotLoggedIn;
      }
    }
    
    public function generatePassword($length = 8, $passwordCharMask = pcmAllChars){
      mt_srand(time());
      $result = "";
      $passwordChars = '';
      
      if ($passwordCharMask & pcmLowerCaseLetters) {
        $passwordChars .= 'abcdefghigklmnopqrstvuwxyz';
      }
      
      if ($passwordCharMask & pcmUpperCaseLetters) {
        $passwordChars .= 'ABCDEFGHTJKLMNOPQRSTVUWXYZ';
      }
      
      if ($passwordCharMask & pcmDigits) {
        $passwordChars .= '0123456789';
      }
      
      $passwordCharsLength = mb_strlen($passwordChars) - 1;
      
      for ($i = 0; $i < $length; ++$i) {
        
        $result .= $passwordChars[mt_rand(0, $passwordCharsLength)];
        
      }
      
      return $result;
    }
    
    public function register($userName, $eMail, $shouldConfirm = false, $autoLogin = true) {
      
      $saveUserId = $this->user->id;
      
      $filter = $this->fBoundData->filter;
      $condition = $filter->conditions->addAtRunTime('id', 'bmDataFilterBinaryCondition');
      $condition->objectName = 'user';
      $condition->operation = oEqual;
      $condition->value = $userName;
      $condition->conjunction = cOr;
      $condition = $filter->conditions->addAtRunTime('email', 'bmDataFilterBinaryCondition');
      $condition->objectName = 'user';
      $condition->operation = oEqual;
      $condition->value = $eMail;
      $this->fBoundData->loadObjects();
      $error = false;
      foreach ($this->fBoundData->dataObjects->items as $user) {
        if ($user->id == $userName) {
          $this->application->errorHandler->addError(0, 'User with login ' . $userName . ' already exists!');  
          $error = true;
        }
        if ($user->email == $eMail) {
          $this->application->errorHandler->addError(0, 'User with  mailbox ' . $eMail . ' already exists!');  
          $error = true;
        }
      }    
      if (!$error) {
        $user = $this->fBoundData->newObject($userName);
        $user->password = $this->generatePassword();
        $user->email = $eMail;
        if ($shouldConfirm) {
          $this->sendConfirmationEMail($user);
        } else {
          $this->sendPasswordEMail($user);
        }
        if ($autoLogin) {
          $this->user = $user;
          $session->userId = $userName;
        } else {
          $this->user = $this->fBoundData->loadObject($session->userId);
        }
        return true;
      }
      
    }
    
    public function getter($propertyName) {
      $result = parent::getter($propertyName);
      if (!isset($result)){
        switch ($propertyName) {
          case 'boundData':
            $result = $this->fBoundData;
          break;
          default:
            if ($this->fBoundData->dataPropertyExists($propertyName) || ($propertyName == 'id')) {
              $result = $this->user->$propertyName;
            }
          break;
        }
      }
      return $result;
    }
    
    public function setter($propertyName, $value) {
      if (($this->fBoundData != null) && ($this->fBoundData->dataPropertyExists($propertyName))) {
        $this->user->$propertyName = $value;
      } else {
        parent::setter($propertyName, $value);
      }
    }

  }

?>
