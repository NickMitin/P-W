<?php
  
  class bmHTMLHyperLinkEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      switch ($control->mode) {
        case hlemView:
          $caption = ($control->caption == null) ? $control->value : $control->caption;
          return '<a id="' . $control->name . 'Edit" class="' . $control->styles->default . '" href="' . $control->value . '">' . $caption . '</a>';
        break;
        case hlemEdit:
          return '<input id="' . $control->name . 'Edit" type="text" style="width: 100%;" class="' . $control->styles->default . '" name="' . $control->getComponentString() . '.value" value="' . $this->application->validator->formatOutput($control->value, true) . '"' . $readOnly . '/>';
        break;
      }
    }
  
  }
  
?>
