<?php
    
  class bmHTMLFileEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      $result = "";
      if ($control->maximumSize > 0) {
        $result .= "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"" . $control->maximumSize . "\" />";
      }
      $result .= "<input id=\"" . $control->name . "Edit\" type=\"file\" style=\"width: 100%;\" class=\"" . $control->styles->default . "\" name=\"" . $control->getComponentString() . ".value\"/>";
      return $result;
    }
  
  }
  
?>
