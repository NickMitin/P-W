<?php

  class bmWordListStyles extends bmCustomControlStyles {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      //$this->serializeProperty('grid', pbValue, 'default');
      $this->serializeProperty('oddWord', pbValue, 'default');
      $this->serializeProperty('evenWord', pbValue, 'default');
      $this->serializeProperty('cell', pbValue, 'default');

    }

  }

?>
