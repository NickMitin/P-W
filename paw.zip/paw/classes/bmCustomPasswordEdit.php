<?php

  class bmCustomPasswordEdit extends bmCustomEdit {

  }

?>
