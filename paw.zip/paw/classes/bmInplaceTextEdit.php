<?php

  class bmInplaceTextEdit extends bmCustomTextEdit {
    
    public $value = null;
    
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      $this->deletePersistentProperty("value");

    }

  }

?>
