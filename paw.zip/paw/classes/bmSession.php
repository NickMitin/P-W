<?php

  class bmSession extends bmPersistentObject {

    private $boundData = null;
    private $session = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->boundData = $this->createOwnedObject("bmDataSource", array("name" => "boundData"));
      $this->boundData->onDeleteObject = "deleteSessionFiles";
      $this->boundData->boundDataMap->objectName = "session";
      $object = $this->boundData->boundDataMap->dataObjectMaps->add("session");
      $propertyMap = $object->propertiesMap->add("userId");
      $propertyMap->fieldName = "userId";
      $propertyMap = $object->propertiesMap->add("formName");
      $propertyMap->fieldName = "formName";
      $propertyMap = $object->propertiesMap->add("lastAction");
      $propertyMap->fieldName = "lastAction";
      $propertyMap = $object->propertiesMap->add("persistent");
      $propertyMap->fieldName = "persistent";
      
      $filter = $this->boundData->filter;
      $condition = $filter->conditions->addAtRunTime("lastAction", "bmDataFilterBinaryCondition"); 
      $condition->objectName = "session";
      $condition->operation = oLess;
      
      $condition = $filter->conditions->addAtRunTime("userId", "bmDataFilterBinaryCondition"); 
      $condition->objectName = "session";
      $condition->conjunction = cAnd;
      
      $condition = $filter->conditions->addAtRunTime("id", "bmDataFilterBinaryCondition"); 
      $condition->objectName = "session";
      $condition->operation = oNotEqual;
      
      $this->load();
      
    }

    public function getter($propertyName) {
      $result = parent::getter($propertyName);
      if (!isset($result)) {
        if ($this->boundData->dataPropertyExists($propertyName) || ($propertyName == "id")) {
          $result = $this->session->$propertyName;
        }
      }
      return $result;
    }

    public function setter($propertyName, $value) {
      if ($this->boundData->dataPropertyExists($propertyName)) {
        $this->session->$propertyName = $value;
      } else {
        parent::setter($propertyName, $value);
      }
    }

    public function create() {
      $this->session = $this->boundData->newObject(md5(uniqid(microtime(), true)));
      $this->application->cgi->addCookie("sessionHash", $this->session->id);
      $this->session->userId = "guest";
      $this->session->persistent = false;
      $this->session->formName = "fIndex";
    }

    private function load() {
      $cgi = $this->application->cgi;
      if (array_key_exists("sessionHash", $cgi->cookies)) {
        $id = $cgi->cookies["sessionHash"];
        if ($this->boundData->objectExists($id)) {
          $this->session = $this->boundData->loadObject($id);
        } else {
          $this->create();
        }
      } else {
        $this->create();
      }
    }
    
    public function save() {
      $this->session->lastAction = time();
      $this->boundData->saveObject($this->session->id);
      $this->deleteOutdated();
    }

    private function deleteOutdated() {
      $filter = $this->boundData->filter;
      $lastAction = $filter->conditions->items['lastAction'];
      $lastAction->value = time() - 900;
      $lastAction->active = true;
      $filter->conditions->items['userId']->active = false;
      $filter->conditions->items['id']->active = false;
      $this->boundData->deleteObjects();
    }
    
    public function deleteSessionsByUser($user) {
      $filter = $this->boundData->filter;
      $filter->conditions->items['lastAction']->active = false;
      $condition = $filter->conditions->items['userId'];
      $condition->value = $user;
      $condition->active = true;
      $condition = $filter->conditions->items['id'];
      $condition->value = $this->session->id;
      $condition->active = true;
      $this->boundData->deleteObjects();
    }
    
    public function deleteSessionFiles($arguments) {
      $session = $arguments['dataObject'];
      //if (!$session->persistent) {
        $this->deleteFiles($session->userId, $session->id);   
      //}
      return true;
    }
    
    private function deleteFiles($userId, $sessionHash) {
      $files = scandir('./sessions/');
      $userId = $this->application->textUtils->textToHex($userId);
      foreach($files as $file) {
        if (preg_match('/^' . $userId . '-' . $sessionHash . '-bm\w+\.xml$/', $file)) {
          unlink('./sessions/' . $file);
        }
      }
    }
    
    public function restoreSessionFiles($userId) {
      $files = scandir('./sessions/');
      $userId = $this->application->textUtils->textToHex($userId);
      foreach($files as $file) {
        if (preg_match('/^' . $userId . '-[0-9a-f]{32}-(bm\w+\.xml)$/', $file, $matches)) {
          rename('./sessions/' . $file, './sessions/' . $userId . '-' . $this->session->id . '-' . $matches[1]);
        } elseif (preg_match('/^6775657374-' . $this->session->id . '-(bm\w+\.xml)$/', $file)) {
          unlink('./sessions/' . $file);
        }
      }
    }

  }

?>
