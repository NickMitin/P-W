<?php

  class bmCSSStyleSheets extends bmCollection {
  
    public $collectionItemClass = "bmCSSStyleSheet";
    public $keyPropertyName = "fileName";

  }

?>