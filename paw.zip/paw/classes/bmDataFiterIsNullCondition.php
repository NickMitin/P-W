<?php

  define("lNull", "is null");
  define("lNotNull", "is not null");

  class bmDataFilterIsNullCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("operation", pbValue, lNull);

    }

  }

?>