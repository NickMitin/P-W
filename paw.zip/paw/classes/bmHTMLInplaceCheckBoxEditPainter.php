<?php

  class bmHTMLInplaceCheckBoxEditPainter extends bmHTMLInplaceCustomEditPainter {
        
    function draw($control, $dataControl, $dataCollection, $style) {
      $result = "";
      switch ($dataControl->mode) {                               
        case dcmView:
          if ($control->value) {
            $result .= '<span class="' . $style . '">yes</span>';
          } else {
            $result .= '<span class="' .$style . '">no</span>';
          }
          break;
        case dcmEdit:
        $randomId = mt_rand(1000, 9999);
        $result .= "<input type=\"hidden\" id=\"" . $control->owner->name . $randomId . "Edit\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[$control->keyValue]\" value=\"" . $control->value . "\" />";
        $result .= "<input class=\"$style\" id=\"" . $control->owner->name . $randomId . "Trigger\" type=\"checkbox\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[$control->keyValue]\" value=\"1\"" . (($control->value) ?" checked=\"checked\"" : "") . "/>";
      }
      return $result;
    }

  }

?>
