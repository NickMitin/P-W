<?php

  abstract class bmObject {

    public $application = null;
    public $owner = null;
    public $objects = array();
    public $objectIndex = -1;
    public $isProperty = false;

    public $beforeClientDataProcess = null;
    public $afterClientDataProcess = null;

    function __construct($application, $owner, $parameters) {

      $this->constructor($application, $owner, $parameters);

    }
    
    public function __get($propertyName) {
      return $this->getter($propertyName);
    }
    
    public function __set($propertyName, $value) {
      return $this->setter($propertyName, $value);
    }
    
    function getter($propertyName) {
    }
    
    function setter($propertyName, $value) {
    }

    function getInfo() {
      $result = get_class($this);
      if (isset($this->name)) {
        $result .= "." . $this->name;
      }
      return $result;
    }

    function printHierarchy($offset) {
      $offset = "&nbsp;&nbsp;" . $offset;
      $result = "<p>" . $offset . $this->getInfo() . "<p/>";
      foreach ($this->objects as $object) {
        $result .= $object->printHierarchy($offset);
      }
      return $result;
    }

    function constructor($application, $owner, $parameters) {
    
      $this->application = $application;
      $this->owner = $owner;

      if (isset($owner)) {
        $this->objectIndex = count($owner->objects);
        $owner->objects[] = $this;
      }
      
    }
    
    function createOwnedObject($className, $parameters = null, $isProperty = true) {
      $object = new $className($this->application, $this, $parameters);
      $object->isProperty = $isProperty;
      return $object;
    }

  }

?>
