<?php

  class bmCustomCheckBoxEdit extends bmCustomEdit {
    
    function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("caption", pbValue);
      $this->serializeProperty("onChange", pbValue);
    }

  }

?>
