<?php

  define("oEqual", "=");
  define("oNotEqual", "<>");
  define("oLessOrEqual", "<=");
  define("oGreaterOrEqual", ">=");
  define("oLess", "<");
  define("oGreater", ">");
  define("oRegExp", "regexp");

  class bmDataFilterBinaryCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("operation", pbValue, oEqual);
      $this->serializeProperty("value", pbValue, 1);

    }

  }

?>
