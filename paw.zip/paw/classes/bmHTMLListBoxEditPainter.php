<?php
  
  class bmHTMLListBoxEditPainter extends bmHTMLStandAloneControlPainter {
    
    function drawControl($control) {
      $result = "";
      $style = $control->styles->default;
      $result = "<select class=\"$style\" style=\"width: 100%;\" name=\"" . $control->getComponentString() . ".value\">\n";
      foreach ($control->options->items as $item) {
        $result .= "<option value=\"$item->value\"" . ifElse($item->selected, " selected", "") . ">$item->caption</option>\n";
      }
      $result .= "</select>\n";
      return $result;
    }
    
  }
  
?>