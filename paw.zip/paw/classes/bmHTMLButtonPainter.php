<?php
  
  class bmHTMLButtonPainter extends bmHTMLStandaloneControlPainter {
    
    function drawControl($control) {
      return '<button id="' . $control->name . 'Button" class="' . $control->styles->default . '" style="width: 100%; height: 100%; display: block; margin: 0; padding: 0;" type="' . $control->behaviour . '">' . $control->caption . '</button>';
    }
    
  }
  
?>
