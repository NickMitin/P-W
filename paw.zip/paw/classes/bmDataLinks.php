<?php                          
  
  class bmDataLinks extends bmCollection {
    
    public $keyPropertyName = "database";
    public $collectionItemClass = "bmCustomDataLink";
    
  }
  
?>