<?php

  define('cAnd', 'and');
  define('cOr', 'or');
  define('cNone', '');

  class bmCustomDataFilterCondition extends bmCollectionItem {

    public $collectionClass = 'bmDataFilterConditions';
    public $filter = null;
    public $conditions = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->conditions = $this->createOwnedObject('bmDataFilterConditions', array('name' => 'conditions'));
      
      $this->serializeProperty('active', pbValue, true);
      $this->serializeProperty('propertyName', pbValue, 'id');
      $this->serializeProperty('fieldName', pbValue, 'id');
      $this->serializeProperty('objectName', pbValue);
      $this->serializeProperty('conjunction', pbValue, cNone);
      $this->serializeProperty('invert', pbValue, false);
      
      $this->filter = $this->owner->filter;

    }

  }

?>
