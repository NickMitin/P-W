<?php
  
  class bmDataObjectDatePropertyMap extends bmDataObjectPropertyMap {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
    
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("fieldName", pbValue);
      
    }
    
  }
  
?>