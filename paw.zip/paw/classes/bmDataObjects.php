<?php

  class bmDataObjects extends bmCollection {

    public $keyPropertyName = "id";
    public $collectionItemClass = "bmDataObject";

  }

?>