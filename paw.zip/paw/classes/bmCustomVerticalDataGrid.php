<?php
  
  class bmCustomVerticalDataGrid extends bmCustomDataControl {
  
    public $columns = null;
    public $optionsView = null;


    public $onCustomDrawDataRow = null;
    public $onCustomDrawDataCell = null;
    public $onCustomDrawNavigator = null;
    public $onCustomDrawColumnHeader = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->publishProperty("boundData", pbReference);

      $this->publishProperty("onCustomDrawDataRow", pbValue);
      $this->publishProperty("onCustomDrawDataCell", pbValue);
      $this->publishProperty("onCustomDrawNavigator", pbValue);
      $this->publishProperty("onCustomDrawColumnHeader", pbValue);

      $this->columns = $this->createOwnedObject("bmDataColumns", $parameters);
      #$this->optionsView = $this->createOwnedObject("bmDataGridOptionsView", $parameters);

    }

    function initialize() {
      parent::initialize();
      if (!$this->columns->count) {
        $index = 0;
        foreach ($this->boundData->objectProperties->items as $property) {
          $column = $this->columns->add($property->propertyName);
          $column->caption = $property->propertyName;
          $column->index = $index;
          $column->visible = true;
          $column->width = "0";
          $index++;
        }
      }
      
    } 

    /*function prepare() {
      parent::prepare();
      if ($this->mode == gmEdit) {
        $column = $this->columns->add("delete");
        $column->caption = "Delete";
        $column->index = $this->columns->count - 1;
        $column->visible = true;
        $column->width = "0";
        $column->shouldSerialize = false;
        $column->inplaceEditClass = "bmInplaceCheckBoxEdit";
        $column->createOwnedObjects();
      }

    }*/
    
  }
  
?>