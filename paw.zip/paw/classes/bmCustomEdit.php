<?php

  define('emView', 1);
  define('emEdit', 2);


  abstract class bmCustomEdit extends bmCustomControl {

    public $keyValue = '';
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->publishProperty('value', pbValue);
      $this->publishProperty('readonly', pbValue, false);

    } 
    
    public function valueSetter($value) {
      $this->value = $value;
      return true;
    }

  }

?>
