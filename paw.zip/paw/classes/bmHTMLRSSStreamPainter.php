<?php

  class bmHTMLRSSStreamPainter extends bmCustomControlPainter {

    function draw($control) {
      header("content-type: " . $control->contentType . "; charset=" . $control->encoding, true);
      
      return $control->content->saveXML();
    }

  }

?>
