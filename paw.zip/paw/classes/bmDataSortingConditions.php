<?php

  class bmDataSortingConditions extends bmCollection {

    public $collectionItemClass = "bmDataSortingCondition";
    public $keyPropertyName = "propertyName";

  }

?>