<?php

  define('sbAscending', 1);
  define('sbDescending', 2);
  define('sbClear', 3);

  class bmHTMLDataGridPainter extends bmHTMLCustomDataControlPainter {
    
    private $groupingRowValues = array();
    private $switchForm = '';
    private $visibleCount = 0;
    
    public function drawControl($control) {
      
      if ($control->name == 'dgteEvent') {
        
        //print '!';
        
      }
      
      foreach ($control->columns->items as $column) {
        if ($column->type == ctGrouping) {
          $this->groupingRowValues[$column->propertyName] = "";
        }                                  
        if ($column->visible) {
          $this->visibleCount++;
        }
      }
      $this->switchForm = 'application.switchForm=' . $control->ownerForm->name . '&amp;';
      $result = '';
      $width = $control->autoFit ? ' style="width: 100%;"' : '';
      $result .= '<table cellpadding="0" cellspacing="0"' . $width . '><tbody>';
      if ($control->optionsView->topNavigator) {
        $result .= $this->drawNavigator($control);
      }
      if ($control->optionsView->columnHeaders) {
        $result .= $this->drawHeader($control);
      }
      $result .= $this->drawDataRows($control); 
      if (($control->mode == dcmEdit) && ($control->boundData->optionsData->new)) {
        $result .= $this->drawNewRecord($control);
      }
      if ($control->optionsView->bottomNavigator) {
        $result .= $this->drawNavigator($control);
      }
      $result .= '</tbody></table>';
      if ($control->mode == dcmEdit) {
        $result .= '<input type="hidden" name="application.switchForm" value="' . $control->ownerForm->name . '"/><input type="hidden" name="' . $control->boundData->getComponentString() . '.update" value="1"/><button type="submit">Подтвердить изменения</button>';
      }
      return $result;
    }
    
    function drawNavigator($control) {
      $result = '<tr><td colspan="' . $this->visibleCount . '">';
      $componentString = $control->getComponentString();
      $action = ($control->actions->pageChange) ? $control->actions->pageChange :  $this->application->path . 'main.php?' . $this->switchForm . 'application.' . $control->ownerForm->name . '.' . $control->name . '.currentPage=';
      for ($i = 1; $i <= $control->pageCount; ++$i) {
        if (($item = $control->callEventHandler($control->onCustomDrawNavigatorItem, array('sender' => $this, 'pageNumber' => $i))) !== false) {
          $result .= $item;
        } else {
          $style = ($i == $control->currentPage) ? $control->styles->currentPageNumber : $control->styles->pageNumber;
          $result .= '<a class="' . $style . '" href="' . $action . $i . '">' . $i . '</a> ';  
        }        
      }
      $result .= '</td></tr>';
      
      return $result;
    }
                                                             
    function drawNewRecord($control) {
      //$result = "<tr><td colspan=\"" . $control->columns->visibleCount . "\"><button type=\"button\" onclick=\"javascript:dataGridAddNewRow('$control->name')\">+</button></td></tr>";
      $result = '';
      return $result;
    }

    function drawNewRecordRow($control, $id) {
      foreach ($control->columns->items as $column) {
        if ($column->shouldSerialize) {
          $column->inplaceEdit->keyValue = $id;
          $column->inplaceEdit->value = null;
          $result .= $column->inplaceEdit->draw($control, $control->boundData, 'newValues');
        }
      }
      return $result;
    }

    function drawHeader($control) {
      $result = '<tr>';
      if ($control->columns->count) {
        foreach ($control->columns->items as $column) {
          if ($column->visible) {
            if (($customDraw = $control->callEventHandler('onCustomDrawColumnHeader', null) !== false)) {
              $result .= $customDraw;
            } else {
              $result .= $this->drawColumnHeader($control, $column);
            }
          }
        }
        $result .= '</tr>';
      }
      return $result;
    }
    
    function drawColumnHeader($control, $column) {

      $sorter = $control->boundData->sorter;
      $result = '<td class="' . $control->styles->columnHeader . '" style="white-space: nowrap;">' . $column->caption;
      if ($column->shouldSerialize && $control->optionsView->sortingButtons) {
        $propertyName = $column->propertyName;
        if (isset($sorter->conditions->items[$propertyName])) {
          $condition = $sorter->conditions->items[$propertyName];
          switch ($condition->sortOrder) {
            case soAscending:
              $result .= '(A) ' . $this->drawSortingButton($control, $column, sbDescending);
              $result .= ' ' . $this->drawSortingButton($control, $column, sbClear);
              break;
            case soDescending:
              $result .= '(D) ' . $this->drawSortingButton($control, $column, sbAscending);
              $result .= ' ' . $this->drawSortingButton($control, $column, sbClear);
              break;
          }
        } else {
          $result .= ' ' . $this->drawSortingButton($control, $column, sbAscending);
          $result .= ' ' . $this->drawSortingButton($control, $column, sbDescending);
        }
      }  else {
        $result .= '&nbsp;';
      }
      $result .= '</td>';
      return $result;
    }



    function drawSortingButton($control, $column, $buttonType) {
      $methodName = "";
      $sortName = "";
      switch ($buttonType) {
        case sbAscending:
          $methodName = 'sortAscending';
          $sortName = 'A';
          break;
        case sbDescending:
          $methodName = 'sortDescending';
          $sortName = 'D';
          break;
        case sbClear:
          $methodName = 'clearSorting';
          $sortName = 'X';
          break;
      }
       return '<a href="main.php?' . $this->switchForm . $control->boundData->getComponentString() . '.sorter.' . $methodName . '=' . $column->propertyName . '">' . $sortName . '</a>';
    }
    
    function drawDataRows($control) {
      
      $i = 1;
      
      $result = '';
      
      if ($control->boundData->dataObjects->count) {
        foreach ($control->boundData->dataObjects->items as $object) {
          $rowOrder = ($i % 2 == 0) ? rEven : rOdd;
          $result .= $this->drawDataRow($control, $object, $rowOrder, $control->boundData->range->start + $i);
          ++$i;     
        }
      }
      return $result;
    }
    
    function drawDataRow($control, $dataObject, $rowOrder, $rowNumber) {
      if ($control->optionsView->rowToolBar) {
        $dataObject->toolBar = true;
      }
      if ($control->mode == dcmEdit) {
        $dataObject->delete = false;
      }
      switch ($rowOrder) {
        case rOdd:
          $styleName = $control->styles->oddRow;
        break;
        case rEven:
          $styleName = $control->styles->evenRow;
        break;
      }
      $result = "";
      $mode = (in_array($dataObject->id, $control->editModeRecordList)) ? rmEdit : rmView;
      $saveControlMode = $control->mode;
      if (($saveControlMode) && ($mode == rmEdit)) {
        $control->mode = dcmEdit;
      }
      $customDrawDataRow = $control->callEventHandler($control->onCustomDrawDataRow, array("dataObject" => $dataObject, "rowOrder" => $rowOrder, "rowNumber" => $rowNumber, 'mode' => $mode));
      $ownerDraw = is_bool($customDrawDataRow);
      $rowId = $control->name . 'DataRow_' . $this->application->textUtils->textToId($dataObject->id) . '_' . $rowOrder;
      $dataRow = '<tr id="' . $rowId . '" class="' . $styleName . '">';
      foreach ($control->columns->items as $column) {
        $fieldName = $column->propertyName; 
        if ($column->type == ctGrouping) {
          if ($this->groupingRowValues[$fieldName] != $dataObject->$fieldName) {
            $result .= $this->drawGroupingRow($control, $column, $dataObject, $dataObject->$fieldName); 
            $this->groupingRowValues[$fieldName] = $dataObject->$fieldName;
          }
        }
        if ($column->visible && $ownerDraw) {
          $dataRow .= $this->drawDataCell($control, $dataObject, $dataObject->$fieldName, $column, $rowNumber);
        }
      }
      $dataRow .= "</tr>";
      $control->mode = $saveControlMode;
      if ($ownerDraw) {
        $result .= $dataRow;
      } else {
        $result .= $customDrawDataRow;
      }
      return $result;
    }
    
    function drawGroupingRow($control, $column, $dataObject, $value) {
      if (($result = $control->callEventHandler($control->onCustomDrawGroupingRow, array("dataObject" => $dataObject, 'column' => $column))) === false) {
        $column->inplaceEdit->keyValue = $dataObject->id;
      $column->inplaceEdit->value = $value;
        $result = '<tr><td class="' . $control->styles->groupingRow . '" colspan="' . $this->visibleCount . '">' . $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default") . '</td></tr>';
      }
      return $result;
    }
    
    function drawDataCell($control, $dataObject, $value, $column, $rowNumber) {
      $column->inplaceEdit->keyValue = $dataObject->id;
      $column->inplaceEdit->value = $value;
      if (($result = $control->callEventHandler($control->onCustomDrawDataCell, array("dataObject" => $dataObject, "rowNumber" => $rowNumber, "columnName" => $column->name))) === false) {
        $result = $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default");
      }
      if ($rowNumber == 1) {
        $style = $column->styles->firstCell;
      } elseif ($rowNumber == $control->boundData->dataObjects->count) {
        $style = $column->styles->lastCell;
      } else {
        $style = $column->styles->cell;
      }
      return '<td class="' . $style . '">' . $result . '</td>';
    }
    
    function drawNewRow() {
      /*$control = $this->control;
      if ($control->mode == dcmEdit) {
        $dataObject->delete = false;
      }
      $result = "<tr>";
      $keyFieldName = "id";
      $keyValue = $dataRow[$keyFieldName];
      foreach ($control->columns->items as $column) {
        if ($column->visible) {
          $fieldName = $column->propertyName;
          $result .= $this->drawDataCell($keyValue, $dataObject->$fieldName, $column);
        }
      }
      $result .= "</tr>";  */
      $result = "";
      return $result;
    } 
    

  }

?>
