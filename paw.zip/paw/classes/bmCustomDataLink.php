<?php        

  abstract class bmCustomDataLink extends bmCollectionItem {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("database", pbValue);

    }


    abstract function newObject($dataSource, $id);

    abstract function loadObject($dataSource, $id);
    abstract function loadObjects($dataSource, $filter = null, $grouper = null, $sorter = null, $range = null);

    abstract function saveObject($dataSource, $id);

    abstract function deleteObject($dataSource, $id);
    abstract function deleteObjects($dataSource, $filter = null);
    abstract public function formatValue($value);
    abstract function connect();
    abstract function disconnect();
    
    
    public function tryNewObject($objects, $id, $objectProperties) {
      if (!$this->objectExists($objects, $id)) {
        return $this->newObject($objects, $id, $objectProperties);
      } else {
        return false;
        //TODO ERROR HERE
      }
    }
    
    function tryLoadObject($objects, $id, $objectProperties) {

      if ($this->objectExists($objects->objectName, $id)) {
        $this->loadObject($objects, $id, $objectProperties);
      } else {
        //TODO ERROR HERE;
      }
    }
    
    function trySaveObject($object, $objectProperties) {

      if ($this->objectExists($object->owner, $object->id)) {
        $this->saveObject($object, $objectProperties);
      } else {
        //TODO ERROR HERE;
      }
      return $object;
    }
    
    function saveObjects($objects, $objectProperties) {
      foreach ($objects->items as $object) {
        $this->saveObject($object, $objectProperties);
      }
    }
    
    function trySaveObjects($objects, $objectProperties) {
      foreach ($objects->items as $object) {
        $this->trySaveObject($object, $objectProperties);
      }
    }
    
    function tryDeleteObject($objects, $objectProperties) {

      if ($this->objectExists($objects, $object->id)) {
        $this->deleteObject($objects, $object->id);
      } else {
        //TODO ERROR HERE;
      }
      return $object;
    }

  }

?>