<?php

  class bmHTMLFlashMoviePainter extends bmHTMLStandaloneControlPainter {
  
    function drawControl($control) {
      
      return "<embed width=\"" . $control->width . "\" height=\"" . $control->height . "\" src=\"./files/" . $control->movie . "\" alt=\"" . $control->quality . "\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\"/>";
  
    }
  
  }
  
?>