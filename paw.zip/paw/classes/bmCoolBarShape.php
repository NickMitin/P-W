<?php
  
  class bmCoolBarShape extends bmCustomCoolBarButton {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("coordinates", pbValue);
      $this->serializeProperty('action', pbValue);
    }
  }
  
?>
