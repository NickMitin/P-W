<?php
  
  class bmCustomCoolBar extends bmCustomControl {
    
    public $buttons = null;
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("picture", pbValue, "");
      $this->buttons = $this->createOwnedObject("bmCoolBarButtons", array("name" => "buttons"));

    }    
    
  }
  
?>