<?php
 
  class bmUploadedFile extends bmCollectionItem {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("fileName", pbValue);
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("key", pbValue);
      $this->serializeProperty("tempName", pbValue);
      $this->serializeProperty("realName", pbValue);
      $this->serializeProperty("mimeType", pbValue);
      $this->serializeProperty("size", pbValue, 0);
      $this->serializeProperty("error", pbValue, UPLOAD_ERR_OK);
      
    }

  }
 
?>
