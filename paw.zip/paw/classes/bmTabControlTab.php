<?php
  
  class bmTabControlTab extends bmCollectionItem {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('caption', pbValue);

    } 
    
  }
  
?>
