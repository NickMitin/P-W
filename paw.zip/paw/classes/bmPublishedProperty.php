<?php

  define ("psPublished", 2);
  
  class bmPublishedProperty extends bmPersistentProperty {
    
    public $scope = psPublished;
    
  }
  
?>