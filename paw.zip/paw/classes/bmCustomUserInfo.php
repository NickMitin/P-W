<?php

  class bmCustomUserInfo extends bmComponent {

    private $user = null;
    protected $fBoundData = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->fBoundData = $this->createOwnedObject("bmDataSource", array("name" => "boundData"));
      $boundDataMap = $this->fBoundData->boundDataMap;
      if (!$boundDataMap->dataObjectMaps->exists('user')) {
        $boundDataMap->objectName = 'user';
        $object = $boundDataMap->dataObjectMaps->add('user'); 
      } else {
        $object = $boundDataMap->dataObjectMaps->items['user']; 
      }
      if (!$object->propertiesMap->exists('password')) {
        $propertyMap = $object->propertiesMap->add('password');
        $propertyMap->fieldName = 'password';
      }
      if (!$object->propertiesMap->exists('password')) {
        $propertyMap = $object->propertiesMap->add('email');
        $propertyMap->fieldName = 'email';
      }
      $this->load(); 

    }
    
    public function load() {
      
      $session = $this->application->session;
      if ($session->persistent) {
        $this->user = $this->fBoundData->loadObject($session->userId);
      } else {
        $this->user = $this->fBoundData->newObject($session->userId);
      }
      
    }
    
    public function save() {
      
      if ($this->application->session->persistent) {
        $this->fBoundData->saveObject($this->user->id);
      }
    }
    
    public function login($userName, $password) {
      $session = $this->application->session;
      if (!$session->persistent) {
        $filter = $this->fBoundData->filter;
        $condition = $filter->conditions->addAtRunTime('id', 'bmDataFilterBinaryCondition');
        $condition->objectName = 'user';
        $condition->operation = oEqual;
        $condition->value = $userName;
        $condition->conjunction = cAnd;
        $condition = $filter->conditions->addAtRunTime('password', 'bmDataFilterBinaryCondition');
        $condition->objectName = 'user';
        $condition->operation = oEqual;
        $condition->value = md5($password);
        $this->fBoundData->loadObjects();
        $users = $this->fBoundData->dataObjects;
        if ($users->count == 1) {
          $session->userId = $userName; 
          $this->user = $users->items[$userName];
          $session->persistent = true;
          $this->application->errorHandler->addError(0, 'Login successful! user id: ' . $userName . ', role: Content Editor');
          return true;
        } else {
          $this->application->errorHandler->addError(0, 'Invalid users creditials!');
        }
      } else {
        $this->application->errorHandler->addError(0, 'Aleady logged in!');
      }
      return false;
    }
    
    public function logout() {
      $session = $this->application->session;
      if ($session->persistent) {
        $session->userId = 'guest';
        $this->user = $this->fBoundData->newObject($session->userId);
        $session->persistent = false; 
        $this->application->errorHandler->addError(0, 'Logout successful!');
      } else {
        $this->application->errorHandler->addError(0, 'Not logged in!');
      }
    }
    
    private function generatePassword($length = 8, $passwordCharMask = pcmAllChars){
      mt_srand(time());
      $result = "";
      
      if ($passwordCharMask & pcmLowerCaseLetters) {
        $passwordChars .= 'abcdefghigklmnopqrstvuwxyz';
      }
      
      if ($passwordCharMask & pcmUpperCaseLetters) {
        $passwordChars .= 'ABCDEFGHTJKLMNOPQRSTVUWXYZ';
      }
      
      if ($passwordCharMask & pcmDigits) {
        $passwordChars .= '0123456789';
      }
      
      $passwordCharsLength = mb_strlen($passwordChars) - 1;
      
      for ($i = 0; $i < $length; ++$i) {
        
        $result .= $passwordChars[mt_rand(0, $passwordCharsLength)];
        
      }
      
      return $result;
    }
    
    public function register($userName, $eMail, $shouldConfirm = false, $autoLogin = true) {
      
      $saveUserId = $this->user->id;
      
      $filter = $this->fBoundData->filter;
      $condition = $filter->conditions->addAtRunTime('id', 'bmDataFilterBinaryCondition');
      $condition->objectName = 'user';
      $condition->operation = oEqual;
      $condition->value = $userName;
      $condition->conjunction = cOr;
      $condition = $filter->conditions->addAtRunTime('email', 'bmDataFilterBinaryCondition');
      $condition->objectName = 'user';
      $condition->operation = oEqual;
      $condition->value = $eMail;
      $this->fBoundData->loadObjects();
      $error = false;
      foreach ($this->fBoundData->dataObjects->items as $user) {
        if ($user->id == $userName) {
          $this->application->errorHandler->addError(0, 'User with login ' . $userName . ' already exists!');  
          $error = true;
        }
        if ($user->email == $eMail) {
          $this->application->errorHandler->addError(0, 'User with  mailbox ' . $eMail . ' already exists!');  
          $error = true;
        }
      }    
      if (!$error) {
        $user = $this->fBoundData->newObject($userName);
        $user->password = $this->generatePassword();
        $user->email = $eMail;
        if ($shouldConfirm) {
          $this->sendConfirmationEMail($user);
        } else {
          $this->sendPasswordEMail($user);
        }
        if ($autoLogin) {
          $this->user = $user;
          $session->userId = $userName;
        } else {
          $this->user = $this->fBoundData->loadObject($session->userId);
        }
        return true;
      }
      
    }
    
    public function getter($propertyName) {
      $result = parent::getter($propertyName);
      if (!isset($result)){
        if ($this->fBoundData->dataPropertyExists($propertyName) || ($propertyName == 'id')) {
          $result = $this->user->$propertyName;
        }
      }
      return $result;
    }
    
    public function setter($propertyName, $value) {
      if (($this->fBoundData != null) && ($this->fBoundData->dataPropertyExists($propertyName))) {
        $this->user->$propertyName = $value;
      } else {
        parent::setter($propertyName, $value);
      }
    }

  }
?>
