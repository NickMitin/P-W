<?php

  class bmDataFilter extends bmPersistentObject {
    
    public $conditions = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->conditions = $this->createOwnedObject("bmDataFilterConditions", array("name" => "conditions"));
      
    }

  }

?>