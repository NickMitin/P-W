<?php

  class bmCustomErrorHandler extends bmComponent {
    
    public $errorGroups = null;
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->errorGroups = $this->createOwnedObject('bmErrorGroups', array('name' => 'errorGroups'));
      $this->errorGroups->add('default');
    }

    public $errors = array();

    function addError($errorCode, $errorText = null, $parameters = null, $group = 'default') {
      $group = $this->errorGroups->items[$group];
      $error = $group->errors->add($errorText);
      $error->code = $errorCode;
    }

  }

?>
