<?php

  define('crOdd', 1);
  define('crEven', 2);
  
  class bmCustomChat extends bmCustomDataControl {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->publishProperty('historyLength', pbValue, 20);
      $this->publishProperty('roomId', pbValue, 0);
      
      $this->serializeProperty('onCustomDrawReply', pbValue);
      $this->serializeProperty('timestampFormat', pbValue, 'd.m.Y h:i');
      
      $this->publishMethod('getReplies');
      $this->publishMethod('getReplyPattern');

    }
    
    public function historyLengthSetter($value) {
      
      if (is_numeric($value) && (($value = intval($value)) >= 0)) {
        
        $this->historyLength = $value;
        return true;
          
      }
      
      return false;
      
    }
    
    public function roomIdSetter($value) {
      
      if (is_numeric($value) && (($value = intval($value)) >= 0)) {
        
        $this->roomId = $value;
        return true;
          
      }
      
      return false;
      
    }  
    
    public function getReplies($lastId, $clientCall = true) {
      
      $condition = $this->boundData->filter->conditions->items['id'];
      $condition->value = intval($lastId);
      
      $condition = $this->boundData->filter->conditions->items['chatRoomId'];
      $condition->value = $this->roomId;
      
      $objectCount = $this->boundData->totalObjectCount;
      if ($objectCount > $this->historyLength) {
        $this->boundData->range->start = 0;
        $this->boundData->range->length = $this->historyLength;
      }
      $this->boundData->loadObjects();
      if ($clientCall) {
        $result = $this->painter->drawControl($this);
        header('content-type: text/html; charset=utf-8');
        print $result;
        $this->application->preventDraw = true;
      }
        
    }
    
    public function getReplyPattern() {
      
      $dataObject = new stdClass();
      $dataObject->delete = false;
      $dataObject->id = '%id%';
      $dataObject->userName = '%userName%';
      $dataObject->timestamp = '%timestamp%';
      $dataObject->replyText = '%replyText%';
      return $this->painter->drawReply($this, $dataObject, '%rowOrder%', '%rowNumber%');
      
    }
    
    public function getClientPropertyValues() {
      $result = parent::getClientPropertyValues();
      $result .= 'this.roomId = "' . $this->roomId . '";';
      return $result;
    }
    
  }
  
?>
