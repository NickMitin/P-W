<?php
  
  class bmActions extends bmCollection {
    
    public $keyPropertyName = "actionName";
    public $collectionItemClass = "bmCustomAction";
    
    public function execute($actionName, $sender, $arguments) {
      
      $action = $this->items[$actionName];
      return $action->execute($sender, $arguments);
      
    }
    
  }
  
?>
