<?php

  class bmCustomClassInspector extends bmWebCustomControl {

    public $componentMap = "bmHTMLLabel";
    public $mapsPath = "e:/Web/cheese/components/";
    public $properties = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty($)
      $this->properties = $this->createOwnedObject("bmClassProperties", $parameters);

    }

    function initialize() {
      $this->loadComponent();
      parent::initialize();
    }

    function loadComponent() {

      $dom = new DomDocument;
      $dom->load($mapsPath . $componentMap . ".xml");
      $nodes = $dom->getElementsByTagName("component");
      $component = $nodes->item(0);
      $properties = $component->getElementsByTagName("property");
      foreach ($properties as $propertyInfo) {
        $name = $propertyInfo->getAttribute("name")->value;
        $type = $propertyInfo->getAttribute("type")->value;
        $inplaceEdit = $propertyInfo->getAttribute("inplaceEdit")->value;
        $property = $this->properties->add($name);
        $property->type = $type;
      }

    }

  }

?>