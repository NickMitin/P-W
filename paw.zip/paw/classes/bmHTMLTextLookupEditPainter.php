<?php
  
  class bmHTMLTextLookupEditPainter extends bmHTMLStandaloneControlPainter {

    public function drawControl($control) {
      $result = '<input id="' . $control->name . 'Edit" type="text" style="width: 100%;" class="' . $control->styles->default . '" name="' . $control->getComponentString() . '.value" value="' . $this->application->validator->formatOutput($control->value, true) . '"/>';
      //$result .= '<div style="position: absolute; display: none; z-index: 9999;" id="' . $control->name . 'DropDown">&nbsp;</div>';
      return $result;
      
    }
    
    public function drawDropDownValueList($control) {
      $searchResultCount = $control->boundData->dataObjects->count;
      $result = $searchResultCount . ',';
      $i = 0;
      if ($searchResultCount > 0) {
        $propertyName = $control->displayPropertyName;
        $result .= '<ul class="' . $control->styles->searchResultsContainer . ' bmTextLookupEditDropDownValueList">';
        foreach($control->boundData->dataObjects->items as $searchResult) {
          $result .= '<li><a id="' . $control->name . 'Result' . ($i++) . '" href="#" class="' . $control->styles->searchResult . '">' . $searchResult->$propertyName . '</a></li>';
        }
        $result .= '</ul>';
      }
      print $result;
    }
  
  }
  
?>
