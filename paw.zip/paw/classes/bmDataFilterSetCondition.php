<?php

  class bmDataFilterSetCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("value", pbValue, 1);

    }

  }

?>
