<?php

  class bmCustomLabel extends bmCustomControl {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("caption", pbValue, "label");
      $this->serializeProperty("onCustomDrawCaption", pbValue);

    }
  }
?>
