<?php 
  if (!extension_loaded('sybase_ct')) {
    dl('sybase_ct.so');
  }

  class bmMSSQLLink extends bmCustomDataLink {

    private $linkId = 0;
    private $queryCount = 0;
    private $queryCache = array();

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("server", pbValue);
      $this->serializeProperty("username", pbValue);
      $this->serializeProperty("password", pbValue);
      $this->serializeProperty("persistentConnection", pbValue, 0);
      $this->serializeProperty("autoConnect", pbValue);

      if ($this->autoConnect) {
        $this->connect();
      }

    }
    
    private function mapExists($tableName, $id) {
      return ($id = $this->getSingle("select [" . $tableName . "].[id] from [" . $tableName . "] where [" . $tableName . "].[id] = '" . $this->formatValue($id) . "';"));
    }

    public function objectExists($dataSource, $id) {
      return $this->mapExists($dataSource->boundDataMap->objectName, $id);
    }

    public function newObject($dataSource, $id) {
      $object = $dataSource->dataObjects->add($id);
      return $object;

    }
    
    function loadObject($dataSource, $id) {
      $linkTable = "[". $dataSource->boundDataMap->linkName . "]";
      $dataObjects = $dataSource->dataObjects;
      $mainObjectName = $dataSource->boundDataMap->objectName;
      if (array_key_exists($id, $dataObjects->items) === false) {
        $object = $dataObjects->add($id);
      } else {
        $object = $dataObjects->items[$id];
      }
      $fieldString = "";
      foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
        if ($mainObjectName != $objectMap->objectName) {
          $fieldString .= "[" . $objectMap->objectName . "].[id] as [" . $objectMap->objectName . "Id], ";
        }
        foreach ($objectMap->propertiesMap->items as $propertyMap) {
          $fieldString .= "[" . $objectMap->objectName . "].[" . $propertyMap->fieldName . "] as [" . $propertyMap->propertyName . "], ";
        }
      }
      $fieldString = mb_substr($fieldString, 0, mb_strlen($fieldString) - 2);
      
      $tableString = "[" . $mainObjectName . "]";
      if ($dataSource->boundDataMap->dataObjectMaps->count > 1) {
        foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
          if ($mainObjectName == $objectMap->objectName) {

            $tableString .= " join " . $linkTable . " on " . $tableString . ".`id` = " . $linkTable . ".`" . $dataSource->boundDataMap->objectName . "Id`";
          } else {
            $tableString = "(" . $tableString . ") join [" . $objectMap->objectName . "] on [" . $objectMap->objectName . "].[id] = " . $linkTable . ".[" . $objectMap->objectName . "Id]";
          }
        }
      }
      $query = "select " . $fieldString . " from " . $tableString . " where [" . $dataSource->boundDataMap->objectName . "].[id] = '" . $this->formatValue($id) . "';";
      #print $query . "<br/>\n";
      $objectValues = $this->getFirst($query);
      if ($objectValues !== false) {
        foreach (array_keys($objectValues) as $valueName) {
          $object->$valueName = $objectValues[$valueName];
        }
        $object->temporary = false;
        return $object; 
      }
      return null;
    }
    
    public function countObjects($dataSource, $filter = null) {
      $mainObjectName = $dataSource->boundDataMap->objectName;
      $linkTable = "[". $dataSource->boundDataMap->linkName . "]";
      
      $tableString = "[" . $mainObjectName . "]";
      if ($dataSource->boundDataMap->dataObjectMaps->count > 1) {
        foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
          if ($mainObjectName == $objectMap->objectName) {
            $tableString .= " join " . $linkTable . " on " . $tableString . ".[id] = " . $linkTable . ".[" . $dataSource->boundDataMap->objectName . "Id]";
          } else {
            $tableString = "(" . $tableString . ") join [" . $objectMap->objectName . "] on [" . $objectMap->objectName . "].[id] = " . $linkTable . ".[" . $objectMap->objectName . "Id]";
          }
        }
      }
      $dummy = "";
      if ($filter != null) {
        $filterString = $this->filterToSQL($filter, $dummy);
      } else {
        $filterString = "";
      }
      #print "select count(distinct `" .$mainObjectName . "`.`id`) from " . $tableString . $filterString . ";";
      return $this->getSingle("select count(distinct [" .$mainObjectName . "].[id]) from " . $tableString . $filterString . ";");
    }
    
    function loadObjects($dataSource, $filter = null, $grouper = null, $sorter = null, $range = null) {
      $dataObjects = $dataSource->dataObjects;
      $dataObjects->clear();
      $mainObjectName = $dataSource->boundDataMap->objectName;
      $fieldString = "";
      $linkTable = "[". $dataSource->boundDataMap->linkName . "]";
      foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
        if ($mainObjectName == $objectMap->objectName) {
          $fieldString .= "[" . $objectMap->objectName . "].[id] as [id], ";
        } else {
          $fieldString .= "[" . $objectMap->objectName . "].[id] as [" . $objectMap->objectName . "Id], ";
        }
        foreach ($objectMap->propertiesMap->items as $propertyMap) {
          $fieldString .= "[" . $objectMap->objectName . "].[" . $propertyMap->fieldName . "] as [" . $propertyMap->propertyName . "], ";
        }
      }
      $fieldString = mb_substr($fieldString, 0, mb_strlen($fieldString) - 2);
      
      $tableString = "[" . $mainObjectName . "]";
      if ($dataSource->boundDataMap->dataObjectMaps->count > 1) {
        foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
          if ($mainObjectName == $objectMap->objectName) {
            $tableString .= " join " . $linkTable . " on " . $tableString . ".[id] = " . $linkTable . ".[" . $dataSource->boundDataMap->objectName . "Id]";
          } else {
            $tableString = "(" . $tableString . ") join [" . $objectMap->objectName . "] on [" . $objectMap->objectName . "].[id] = " . $linkTable . ".[" . $objectMap->objectName . "Id]";
          }
        }
      }
      $filterFieldString = "";
      if ($filter != null) {
        $filterString = $this->filterToSQL($filter, $filterFieldString);
      } else {
        $filterString = "";
      }
      if ($filterFieldString != "") {
        $fieldString .= ", " . $filterFieldString;
      }
      if ($range != null) {
        $rangeString = $this->rangeToSQL($range);
      } else {
        $rangeString = "";                                                
      }
      if ($sorter != null) {
        $sorterString = $this->sorterToSQL($sorter);
      } else {
        $sorterString = "";
      }
      $grouperString = ($grouper != null) ? $this->grouperToSQL($grouper) : "";
      $query = "select " . $fieldString . " from " . $tableString . $filterString . $grouperString . $sorterString . $rangeString . ";";
      #print $query . "<br />\n";
      $cursor = $this->query($query);
      if (!is_bool($cursor)) {
        while ($objectMap = mssql_fetch_assoc($cursor)) {
          $object = $dataObjects->add($objectMap["id"]); 
          unset($objectMap["id"]);
          foreach (array_keys($objectMap) as $field) {
            $object->$field = $objectMap[$field];
          }
        }
      }
    }
    
    function saveObject($dataSource, $id) {
      
      $fields = array();
      $idFields = array();
      $object = $dataSource->dataObjects->items[$id]; 
      $mainObjectName = $dataSource->boundDataMap->objectName;
      foreach ($dataSource->boundDataMap->dataObjectMaps->items as $objectMap) {
        $query = "";
        foreach ($objectMap->propertiesMap->items as $propertyMap) {
          $propertyName = $propertyMap->propertyName;
          $query .= "[" . $objectMap->objectName . "].[" . $propertyMap->fieldName . "] = '" . $this->formatValue($object->$propertyName) . "', ";
        }
        $fields[$objectMap->objectName] = mb_substr($query, 0, mb_strlen($query) - 2);
        if ($objectMap->objectName != $dataSource->boundDataMap->objectName) {
          $objectIdField = $objectMap->objectName . "Id";
        } else {
          $objectIdField = "id";
        }
        $idFields[$objectMap->objectName . "Id"] = $object->$objectIdField;
      }

      $id = $this->formatValue($object->id);
      
      if ($object->temporary) {
        foreach(array_keys($fields) as $objectName) {
          if ($mainObjectName == $objectName) {
            
            $query = "insert into [" . $objectName . "] ([" . $objectName . "].[id]) values ('" . $id . "');";
            #print $query . "\n";
            $this->query($query);
          } else {
          }
        }
        if (count($fields) > 1) {
          $linkTable = $dataSource->boundDataMap->linkName;
          $fieldList = "";
          $valueList = "";
          foreach(array_keys($idFields) as $idField) {
            $fieldList .= "[" . $linkTable . "`.`" . $idField . "], ";
            //$value = $this->formatValue($idFields[$idField]);
            //$value = mb_
            $valueList .= "'" . $this->formatValue($idFields[$idField]) . "', ";
          }
          $fieldList = mb_substr($fieldList, 0, mb_strlen($fieldList) - 2);
          $valueList = mb_substr($valueList, 0, mb_strlen($valueList) - 2);
          $query = "insert into [" . $linkTable . "] (" . $fieldList . ") values (" . $valueList . ");";
          //print $query . "\n";
          $this->query($query);
        }
        $object->temporary = false;
      }
      if (count($fields) > 1) {
        $linkTable = $dataSource->boundDataMap->linkName;
        $updateList = "";
        foreach(array_keys($idFields) as $idField) {
          $updateList .= "`" . $linkTable . "`.`" . $idField . "` = '" . $this->formatValue($idFields[$idField]) . "', ";
        }
        $updateList = mb_substr($updateList, 0, mb_strlen($updateList) - 2);
        $query = "update [" . $linkTable . "] set " . $updateList . " where [" . $mainObjectName . "Id] = '" . $idFields[$mainObjectName . "Id"]  . "';";
        #print $query . "\n";
        $this->query($query);
      }
      foreach(array_keys($fields) as $objectName) {
        if ($fields[$objectName] != "") {
          $query = "update [" . $objectName . "] set " . $fields[$objectName] . " where [" . $objectName . "].[id] = '" . $idFields[$objectName . "Id"]  . "';";
          #print $query . "\n";
          $this->query($query);
        }
      }
    }

    public function deleteObject($dataSource, $id) {
      $objects = $dataSource->dataObjects;
      if (count($dataSource->boundDataMap->dataObjectMaps->count) > 1) {
        $linkTable = "[". $dataSource->boundDataMap->linkName . "]"; 
        $this->query("delete from " . $linkTable . " where " . $linkTable . ".[" . $dataSource->boundDataMap->objectName . "Id] = '" . $this->formatValue($id) . "';");
      }
      $this->query("delete from [" . $dataSource->boundDataMap->objectName . "] where [" . $dataSource->boundDataMap->objectName . "].[id] = '" . $this->formatValue($id) . "';");
      $objects->delete($id);
    }

    public function deleteObjects($dataSource, $filter = null) {
      $objects = $dataSource->dataObjects;
      if (count($dataSource->boundDataMap->dataObjectMaps->count) > 1) {
        $linkTable = "[". $dataSource->boundDataMap->linkName . "]";
        $this->query("delete from " . $linkTable . ";");
      }
      $dummy = "";
      if ($filter != null) {
        $filterString = $this->filterToSQL($filter, $dummy);
      } else {
        $objects->clear();
        $this->query("delete from [" . $dataSource->boundDataMap->objectName . "];");
        return;
      }                                                                                                 
      $cursor = $this->query("select [" . $dataSource->boundDataMap->objectName . "].[id] from [" . $dataSource->boundDataMap->objectName . "]" . $filterString . ";");
      if (!is_bool($cursor)) {
        while ($row = mssql_fetch_assoc($cursor)) {
          $this->deleteObject($dataSource, $row["id"]);
        }
      }
    }                                                     
    
    private function rangeToSQL($range) {
      return ($range->end == 0) ? "" : " limit $range->start, $range->end";
    }

    private function filterToSQL($filter, &$filterFieldString) {
      if ($filter->conditions->count) {
        return " where " . $this->filterConditionsToSQL($filter->conditions->items, $filterFieldString);
      }
      return "";
    }

    private function filterConditionsToSQL($conditions, &$filterFieldString) {
      $result = "";
      foreach ($conditions as $condition) {
        switch(get_class($condition)) {
          case "bmDataFilterBinaryCondition":
            $result .= $this->filterBinaryConditionToSQL($condition) . " $condition->conjunction ";
          break;
          case "bmDataFilterSetCondition":
            $result .= $this->filterSetConditionToSQL($condition) . " $condition->conjunction ";
          break;
          case "bmDataFilterMaskCondition":
            $result .= $this->filterMaskConditionToSQL($condition) . " $condition->conjunction ";
          break;
          case "bmDataFilterIsNullCondition":
            $result .= $this->filterIsNullConditionToSQL($condition) . " $condition->conjunction ";
          break;
          case "bmDataFilterInRangeCondition":
            $result .= $this->filterInRangeConditionToSQL($condition) . " $condition->conjunction ";
          break;
          case "bmDataFilterFullTextCondition":
            $result .= $this->filterFullTextConditionToSQL($condition, $filterFieldString) . " $condition->conjunction ";
          break;
        }
        if ($condition->conditions->count) {
          $result .= " (" . $this->filterConditionsToSQL($condition->conditions) . ")";
        }
      }
      return $result;
    }

    private function filterBinaryConditionToSQL($condition) {
      
      return "[$condition->objectName].[$condition->propertyName] $condition->operation '" . $this->formatValue($condition->value) . "'";

    }
    
    private function filterSetConditionToSQL($condition) {
      
      return "[$condition->objectName].[$condition->propertyName] in (" . $condition->value . ")";
      
    }
    
    private function filterMaskConditionToSQL($condition) {
      
      return "[$condition->objectName].[mask] & '" . $this->formatValue($condition->mask) . "' <> 0";

    }
    
    private function filterFullTextConditionToSQL($condition, &$filterFieldString) {

      $validator = $this->application->validator;
      $value = $this->formatValue($condition->value);
      $fieldList = "";
      foreach ($condition->fields->items as $field) {
        $fieldList .= "[" . $field->objectName . "].[" . $field->fieldName . "], ";
      }
      $fieldList = mb_substr($fieldList, 0, mb_strlen($fieldList) - 2);
      $relevanceValue = preg_replace("/[\-*\"\'!+~()\/\\\\]/", "", $value);
      $filterFieldString .= "match(" . $fieldList . ") against ('" . $relevanceValue . "') as [$condition->propertyName" . "Relevance]";
      return "match(" . $fieldList . ") against ('" . $value . "' in boolean mode)";
    }
    
    private function filterInRangeConditionToSQL($condition) {

      $result = "[" . $condition->objectName . "].[". $condition->propertyName . "] ";
      $result .= ($condition->invert) ? "not " : "";
      $result .= "in (";
      foreach ($condition->values->items as $value) {
        $result .= "'" . $this->formatValue($value->value) . "', ";
      }
      $result = mb_substr($result, 0, mb_strlen($result) - 2);
      $result .= ")";
      return $result;
    }

    private function filterIsNullConditionToSQL($condition) {
      return "[$condition->objectName].[$condition->propertyName] $condition->operation";
    }
  
    function grouperToSQL($grouper) {
      $result = "";
      if ($grouper->conditions->count > 0) {
        $result = " group by";
        foreach ($grouper->conditions->items as $condition) {
          $result .= " [" . $condition->objectName . "].[" . $condition->fieldName . "], ";
        }
        $result = mb_substr($result, 0, mb_strlen($result) - 2) . " ";
      }
      return $result;
    }
    
    function sorterToSQL($sorter) {
      $result = "";
      if ($sorter->conditions->count > 0) {
        $result = " order by";
        foreach ($sorter->conditions->items as $condition) {
          $result .= " [" . $condition->propertyName . "] " . $this->sortOrderToSQL($condition->sortOrder) . ", ";
        }
        $result = mb_substr($result, 0, mb_strlen($result) - 2) . " ";
      }
      return $result;
    }
    
    function sortOrderToSQL($sortOrder) {
      switch ($sortOrder) {
        case 1: return "asc";
        case 2: return "desc";
      }
    }                                                   

    private function doError() {
      if ($this->linkId) {
        //$errorCode = mssql_errno($this->linkId);
        //$errorDescription = mssql_error($this->linkId);
      } else {
        //$errorCode = mssql_errno();
        //$errorDescription = mssql_error();
      }
      $this->application->errorHandler->addError($errorCode, $errorDescription);
    }

    public function connect() {
      if ($this->linkId == 0) {
        if ($this->persistentConnection) {
          $this->linkId = mssql_pconnect($this->server, $this->username, $this->password);
        } else {
          $this->linkId = mssql_connect($this->server,$this->username, $this->password);
        }
        if (!$this->linkId) {
          $this->doError();
        } else {
          if(!mssql_select_db($this->database, $this->linkId)) {
            $this->doError();
          }
          #$this->query("set names '" . preg_replace("/-/", "", XMLEncoding) . "';");
        }
      }
    }

    public function query($sqltext) {
      #print "<p>" . $sqltext . "</p>\n";
      if (($this->linkId) && ($sqltext)) {
        if ($result = mssql_query($sqltext, $this->linkId)) {
          $this->queryCount++;
          return $result;
        }
        $this->doError();
      }
      return false;
    }

    private function getSingle($sqltext) {
      $cursor = $this->query($sqltext);
      if (!is_bool($cursor)) {
        return mssql_result($cursor, 0, 0);
      }
      return false;
    }

    private function getFirst($sqltext) {
      $cursor = $this->query($sqltext);
      if ($cursor) {
        return mssql_fetch_assoc($cursor);
      }
      return false;
    }

    public function disconnect() {
      if ($this->linkId != 0) {
        mssql_close($this->linkId);
        $this->linkId = 0;
      }
    }
    
    public function formatValue($value) {
      return str_replace("'", "''", $value);
    }
    
  }

?>
