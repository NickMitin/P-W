<?php

  define('dcmView', 1);
  define('dcmEdit', 2);
  
  define ('ielDataCell', 1);
  define ('ielNewRow', 2);
  
  class bmCustomDataControl extends bmCustomControl {
    
    public $optionsData = null;
    
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('mode', pbValue, dcmView);
      $this->serializeProperty('boundData', pbReference);
      
      $this->optionsData = $this->createOwnedObject('bmDataControlOptionsData', array('name' => 'optionsData'));

    }  
    
    public function drawInplaceEdit($inplaceEdit, $dataObject, $dataCollection = 'updatedValues', $style = 'default') {
      $inplaceEdit->keyValue = $dataObject->id;
      $propertyName = $inplaceEdit->owner->propertyName;
      $inplaceEdit->value = $dataObject->$propertyName;
      return $inplaceEdit->painter->draw($inplaceEdit, $this, $dataCollection, $style);
    }       
    
  }
  
?>
