<?php
  
  class bmFormMap extends bmCollectionItem {
    
    public $formName = "fIndex";
    public $map = null;
    public $navigator = null;
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($this, $owner, null);
      $this->map = new DOMDocument();
      
    }
    
    function loadXML($fileName) {
      $this->map->load($fileName);
      $this->navigator = new DOMXPath($this->map);
    }
    
    function saveXML($fileName) {
      $this->map->save($fileName);
    }
    
  }
  
?>