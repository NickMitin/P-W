<?php
  
  class bmCustomCollectionEdit extends bmCustomEdit {
    
    
    
  }
  
?>
