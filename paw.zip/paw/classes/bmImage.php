<?php

  class bmImage extends bmCustomImage {
    
    public $hasClientMirror = 1;

  }

?>
