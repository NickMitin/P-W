<?php

  class bmErrorGroup extends bmCollectionItem {
    
    public $errors = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('groupName', pbValue);
      $this->serializeProperty('description', pbValue, '');
      $this->errors = $this->createOwnedObject('bmErrors', array('name' => 'errors'));
    }
    
  }

?>
