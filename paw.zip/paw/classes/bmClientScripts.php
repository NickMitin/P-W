<?php

  class bmClientScripts extends bmCollection {

    public $collectionItemClass = "bmClientScript";
    public $keyPropertyName = "fileName";

  }

?>