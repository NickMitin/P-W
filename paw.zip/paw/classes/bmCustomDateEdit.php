<?php

  define('devfInteger', 1);
  define('devfDateTime', 2);
  define('deeOk', 0);
  define('deeInvalidValue', 1);
  
  define ('devfFormatRegExp', '(\\\\)*([dDjlNSwzWFmMntLoYyaABgGhHiseIOTZcrU])');
  
  class bmCustomDateEdit extends bmCustomEdit {
    
    public $positions = array();
    public $offset = 0;
    public $hint;
    public $lastError = deeOk;
    
    public function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("format", pbValue, "d.m.Y");
      $this->serializeProperty("caption", pbValue);
      $this->serializeProperty("valueFormat", pbValue, 1);
      
      $this->hint = $this->formatToHint($this->format);
      
    }
    
    public function getter($propertyName) {
      switch ($propertyName) {
        case 'caption':
          if ($this->value == null) {
            $this->caption = $this->formatToHint($this->format);
          }
        break;
      }
      return parent::getter($propertyName);
    }
    
    public function setter($propertyName, $value) {
      switch ($propertyName) {
        case 'value':
          if ($value != null) {
            if ($value === 0 || $value === '') {
              $value = null;
            }
          }
          if ($value == null) {
            $this->caption = $this->hint;
            parent::setter($propertyName, $value);
            return;
          }
          $valueSet = true;
          switch ($this->valueFormat) {
            case devfInteger:
              if (preg_match('/^\d+$/', $value)) {
                parent::setter($propertyName, $value);
                $this->caption = date($this->format, $value);
              } else {
                $valueSet = false;
              }
            break;
            case devfDateTime:
              if (preg_match('/^([1-9]\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12][\d]|3[01]) ([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/', $value, $dateInfo)) {
                $year = $dateInfo[1];
                $month = $dateInfo[2];
                $day = $dateInfo[3];
                if (checkMonthDay($day, $month, $year)) {
                  $format = addcslashes($this->format, '.[]');
                  $this->caption = preg_replace('/' . devfFormatRegExp . '/eu', "\$this->dateItemToValue('\\2', \$dateInfo)", $format);
                } else {
                  $this->restoreValue('caption');
                }
              } else {
                $valueSet = false;
              }
            break;
          }
          if (!$valueSet) {
            if (($realValue = $this->stringToTime($value)) !== false) {
              parent::setter($propertyName, $realValue);
              $this->caption = $value;
            } else {
              $this->lastError = deeInvalidValue;
              $this->restoreValue('caption');
            }
          }
        break;
        default:
          parent::setter($propertyName, $value);
        break;
      }
    }
    
    private function formatToHint($format) {
      //$regExp = addcslashes($this->format, '.[]');
      //$this->offset = 1;
      return preg_replace('/' . devfFormatRegExp . '/eu', "\$this->dateItemToHint('\\2')", $this->format);
      //$regExp = stripcslashes($this->format, '.[]');
    }
    
    private function dateItemToHint($dateItem) {
      switch ($dateItem) {
        case 'd':
          $result = dtDD;
        break;
        case 'm':
          $result = dtMM;
        break;
        case 'Y':
          $result = dtYYYY;
        break;
        default:
          $result = '';
        break;
      }
      return $result;
    }
    
    private function dateItemToValue($dateItem, $dateInfo) {
      switch ($dateItem) {
        case 'd':
          $result = $dateInfo[3];
        break;
        case 'm':
          $result = $dateInfo[2];
        break;
        case 'Y':
          $result = $dateInfo[1];
        break;
      }
      return $result;
    }
    
    private function dateItemToRegExp($dateItem) {
      switch ($dateItem) {
        case 'd':
          $result = '(0[1-9]|[12][\d]|3[01])';
          $this->positions['d'] = $this->offset;
          $this->offset++;
        break;
        case 'm':
          $result = '(0[1-9]|1[0-2])';
          $this->positions['m'] = $this->offset;
          $this->offset++;
        break;
        case 'Y':
          $result = '(\d{4})';
          $this->positions['Y'] = $this->offset;
          $this->offset++;
        break;
      }
      return $result;
    }
    
    private function checkMonthDay($day, $month, $year) {
      switch ($month) {
        case 4:
        case 6:
        case 9:
        case 11:
          $result = ($day <= 30);
        break;
        case 2:
          $maxDay = (($year % 4) == 0) ? 29 : 28;
          $result = ($day <= $maxDay);
        break;
        default:
          $result = true;
        break;
      }
      return $result;
    }
    
    private function stringToTime($value) {
      //print $value . ' - ' . $this->hint;
      if ($value == $this->hint) {
        return null;
      }
      $regExp = addcslashes($this->format, '.[]');
      $this->offset = 1;
      $regExp = preg_replace('/' . devfFormatRegExp . '/eu', "\$this->dateItemToRegExp('\\2')", $regExp);
      $regExp = '/^' . $regExp . '$/';
      
      $day = 0;
      $month = 0;
      $year = 0;
      
      if (preg_match($regExp, $value, $matches)) {
        foreach ($this->positions as $marker => $position) {
          switch ($marker) {
            case 'd':
              $day = $matches[$position];
            break;
            case 'm':
              $month = $matches[$position];
            break;
            case 'Y':
              $year = $matches[$position];
            break;
          }
        }
        if ($this->checkMonthDay($day, $month, $year)) {
            switch ($this->valueFormat) {
              case devfInteger:
                return mktime(0, 0, 0, $month, $day, $year);
              break;
              case devfDateTime:
                return $year . '-' . $month . '-' . $day . ' 00:00:00';
              break;
            }
          } else {
            $this->application->errorHandler->addError(0, deErrorInvalidDateValue);
            return null;
          }
      } else {
        $this->application->errorHandler->addError(0, deErrorInvalidDateValue);
        return null;
      }
    }

  }
  
?>
