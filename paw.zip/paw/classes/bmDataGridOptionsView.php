<?php

  class bmDataGridOptionsView extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("topNavigator", pbValue, false);
      $this->serializeProperty("bottomNavigator", pbValue, true);
      $this->serializeProperty("columnHeaders", pbValue, true);
      $this->serializeProperty("newRecord", pbValue, true);
      $this->serializeProperty("rowToolBar", pbValue, true);
      $this->serializeProperty("rowNumbers", pbValue, true);

    }

  }

?>
