<?php                                       

  class bmComponentMap extends bmComponent {

    private $mapFile = null;
    private $fUpdatedValues = null;
    public $propertyMaps = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("component", pbReference);
      $this->publishMethod("update");
      
      $this->propertyMaps = $this->createOwnedObject("bmComponentPropertyMaps", array("name" => "propertyMaps"));
      
      if ($this->component != null) {
        $this->loadMap(get_class($this->component));  
      } 
      
    }
    
    public function update() {
      
      foreach ($this->propertyMaps->items as $propertyMap) {
        if ($propertyMap->type != 6) {
          $propertyName = $propertyMap->propertyName;
          $value = $this->updatedValues->$propertyName;
          $value = $value[1];
          $this->component->$propertyName = $value;
        }
      }
      
    }
    
    public function getter($propertyName) {
      switch ($propertyName) {
        case "updatedValues":
          if ($this->fUpdatedValues == null) {
            $this->fUpdatedValues = $this->createOwnedObject("bmDataSourceClientValues", array("name" => "updatedValues"));
          }
          return $this->fUpdatedValues;
        break;
        default:
          return parent::getter($propertyName);
        break;
      }
    }
    
    public function setter($propertyName, $value) {
      parent::setter($propertyName, $value);
      switch ($propertyName) {
        case "component":
          $this->loadMap(get_class($this->component));
        break;
      }
    }

    private function loadMap($mapName) {
      $this->mapFile = new DOMDocument("1.0", "utf-8");
      while (!file_exists(engineRoot . 'classes/' . $mapName . ".xml")) {
        if ($mapName == 'bmObject') {
          $mapName = null;
          break;
        } else {
          $mapName = get_parent_class($mapName);
        }
      }
      if ($mapName != null) {
        $this->mapFile->load(engineRoot . 'classes/' . $mapName . ".xml");
        $this->propertyMaps->clear();
        $propertyMaps = $this->mapFile->getElementsByTagName("property");
        foreach ($propertyMaps as $propertyMap) {
          $property = $this->propertyMaps->add($propertyMap->getAttribute("name"));
          $property->type = $propertyMap->getAttribute("type");
          $property->defaultValue = $propertyMap->getAttribute("defaultValue");
          $property->editClass = $propertyMap->getAttribute("editClass");
        }
      }
    }
        
  }

?>
