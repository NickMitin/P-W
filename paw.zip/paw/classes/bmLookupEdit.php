<?php

  class bmLookupEdit extends bmCustomLookupEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
