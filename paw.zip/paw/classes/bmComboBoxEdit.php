<?php
  
  class bmComboBoxEdit extends bmCustomComboBoxEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
