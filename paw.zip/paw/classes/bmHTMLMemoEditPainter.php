<?php

  class bmHTMLMemoEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {         
      $name = $control->getComponentString() . ".value";                                                                            
      $height = $control->height == 'auto' ? ' 100%' : $control->height;
      $readonly = $control->readonly ? ' readonly="readonly"' : '';
      $result = '<textarea id="' . $control->name . 'Edit"' . $readonly . ' name="' . $name . '" rows="0" cols="0" class="' . $control->styles->default . '" style="width: 100%; height: ' . $height . ';">' . $this->application->validator->formatOutput($control->value, true) . '</textarea>';
      return $result;
    }

  }

?>
