<?php
  
  class bmHTMLCheckBoxListEditPainter extends bmHTMLCustomDataControlPainter {
    
    public function drawControl($control) {
      $result = '<table style="width: 100%; height: 100%;" cellpadding="0" cellspacing="0"><tbody>';
      $result .= $this->drawDataRows($control);
      $result .= '</tbody></table>';
      return $result;
    }
    
    private function drawDataRows($control) {
      
      $i = 1;
      
      $result = '';
      
      if ($control->boundData->dataObjects->count) {
        $start = $control->boundData->range->start;
        foreach ($control->boundData->dataObjects->items as $object) {
          $rowOrder = ($i % 2 == 0) ? 2 : 1;
          $result .= $this->drawDataRow($control, $object, $rowOrder, $start + $i);
          ++$i;     
        }
      }
      return $result;
    }
    
    private function drawDataRow($control, $dataObject, $rowOrder, $rowNumber) {
      
      if ($control->mode == dcmEdit) {
        $dataObject->delete = false;
      }
      switch ($rowOrder) {
        case 1:
          $styleName = $control->styles->oddRow;
        break;
        case 2:
          $styleName = $control->styles->evenRow;
        break;
      }
      
      if (($result = $control->callEventHandler($control->onCustomDrawDataRow, array('dataObject' => $dataObject, 'rowOrder' => $rowOrder, 'rowNumber' => $rowNumber))) === false) {
        /*if ($rowNumber == 1) {
          $style = $control->styles->firstDataRow;
        } elseif ($rowNumber == $control->boundData->dataObjects->count) {
          $style = $control->styles->lastDataRow;
        } else {
          $style = $control->styles->dataRow;
        }*/
        $propertyName = $control->displayPropertyName;
        $result = '<tr class="' . $styleName . '">';
        if (($result = $control->callEventHandler($control->onCustomDrawDataCell, array('dataObject' => $dataObject, 'rowNumber' => $rowNumber))) === false) {
          $result .= '<td class="' . $control->styles->valueCell . '">' . $dataObject->$propertyName . '</td><td class="' . $control->checkBoxCell . '">';
          $result .= '<input type="checkbox" name="' . $control->boundData->getComponentString() . '.updatedValues.' . $control->owner->propertyName . '[' . $dataObject->id . ']" value="' . $dataObject->id . '" />';
          $result .= '</td>';
        }
        $result .= '</tr>';
      }
      return $result;
    }      
    
  }
  
?>
