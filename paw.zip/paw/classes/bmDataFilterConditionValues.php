<?php

  class bmDataFilterConditionValues extends bmCollection {

    public $collectionItemClass = "bmDataFilterConditionValue";
    public $keyPropertyName = "value";

  }

?>
