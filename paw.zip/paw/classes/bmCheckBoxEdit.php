<?php
  
  class bmCheckBoxEdit extends bmCustomCheckBoxEdit {
    
    public $hasClientMirror = 1;

  }
  
?>
