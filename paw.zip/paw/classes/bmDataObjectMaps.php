<?php
  
  class bmDataObjectMaps extends bmCollection {
    
    public $keyPropertyName = "objectName";
    public $collectionItemClass = "bmDataObjectMap";
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("masterObjectName", pbValue);
      
    }
    
  }
  
?>