<?php        
   
   class bmSessionDataLink extends bmCustomDataLink {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

    }


    public function newObject($dataSource, $id) {
    
      $object = $dataSource->dataObjects->add($id);
      return $object; 
    
    }
    
    public function countObjects($dataSource) {
    
      return $dataSource->preloadObjectCount;
    
    }

    public function loadObject($dataSource, $id) {
      return $this->newObject($dataSource, $id);
    }
    public function loadObjects($dataSource, $filter = null, $grouper = null, $sorter = null, $range = null) {
    
      if ($dataSource->preloadObjectCount > 0) {
        for ($i = 1; $i <= $dataSource->preloadObjectCount; ++$i) {
          $this->newObject($dataSource, $i);   
        }
      }
      
    }

    public function saveObject($dataSource, $id) {}

    public function deleteObject($dataSource, $id) {}
    public function deleteObjects($dataSource, $filter = null) {}
    public function formatValue($value) { return $value; }
    public function connect() {}
    public function disconnect() {} 

  }

?>