<?php
  
  define('dtglFixed', 1);
  define('dtglDynamic', 2);

  class bmCustomDataTileGrid extends bmCustomDataControl {

    public $columns = null;
    public $actions = null;
    public $optionsView = null;
    public $pageCount = 0;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('onCustomDrawDataTile', pbValue);
      $this->publishProperty('currentPage', pbValue, 1);
      $this->publishProperty('objectsPerPage', pbValue, 12);
      $this->publishProperty('tilesPerRow', pbValue, 3);
      $this->publishProperty('layout', pbValue, dtglFixed);

      $this->columns = $this->createOwnedObject('bmDataColumns', array('name' => 'columns'));
      $this->actions = $this->createOwnedObject('bmPagedControlActions', array('name' => 'actions'));
      $this->optionsView = $this->createOwnedObject('bmDataTileGridOptionsView', array('name' => 'optionsView'));
      
      if (($this->columns->count == 0) && ($this->boundData != null)) {
        foreach ($this->boundData->boundDataMap->dataObjectMaps->items as $objectMap) {
          foreach ($objectMap->propertiesMap->items as $propertyMap) {
            $column = $this->columns->add($propertyMap->propertyName);
            $column->caption = $propertyMap->propertyName;
            $column->visible = true;
          }
        }
      }
    }
    
    public function currentPageSetter($value) {
      if ($value > 0) {
        $this->currentPage = $value;
        return true;
      } else {
        return false;
      }
    }
    
    public function loadData() {
      $objectCount = $this->boundData->totalObjectCount;
      if ($objectCount > 0) {
        $objectsPerPage = $this->objectsPerPage;
        if ($objectsPerPage > 0) {
          $this->pageCount = ceil($objectCount / $objectsPerPage);
          if ($this->currentPage > $this->pageCount) {
            $this->restoreValue('currentPage');
          }
          $this->boundData->range->start = ($this->currentPage - 1) * $objectsPerPage;
          $this->boundData->range->length = $objectsPerPage;
        } else {
          $this->boundData->range->start = 0;
          $this->boundData->range->length = 0;
        }
      }
      $this->boundData->loadObjects();
    }

  }

?>
