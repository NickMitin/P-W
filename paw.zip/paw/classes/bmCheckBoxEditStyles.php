<?php

  class bmCheckBoxEditStyles extends bmCustomControlStyles {

  }

?>
