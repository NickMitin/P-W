<?php

  class bmInplaceCheckBoxEdit extends bmCustomCheckBoxEdit {
    
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      unset($this->serializedProperties["value"]);

    }
        
  }

?>
