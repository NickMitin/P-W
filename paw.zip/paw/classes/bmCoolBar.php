<?php
  
  class bmCoolBar extends bmCustomCoolBar {
    
    public $hasClientMirror = 1;
    
  }
  
?>
