<?php

  class bmDataFilterConditionFields extends bmCollection {

    public $collectionItemClass = "bmDataFilterConditionField";
    public $keyPropertyName = "propertyName";

  }

?>