<?php

  define("irRepeatX", "repeat-x");
  define("irRepeatY", "repeat-y");
  define("irRepeatBoth", "repeat");
  define("irNoRepeat", "no-repeat");
  
  class bmCSSBackgroundImage extends bmPersistentObject {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("picture", pbValue, "none");
      $this->serializeProperty("repeat", pbValue, irNoRepeat);

    }
    
    function toCSS() {
      if ($this->picture == "none") {
        $picture = "";
      } else {
        $picture = "background-image: url(\"" . $this->picture . "\");\n";
      }
      $result = $picture . "background-repeat: " . $this->repeat . ";\n";
      return $result;
    }
    
  }
  
?>