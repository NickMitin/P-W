<?php

  define('dscmNone', 1);
  define('dscmBody', 2);
  define('dscmFull', 3);

  class bmDataSource extends bmComponent {

    private $dataLink = null;
    
    private $fTotalObjectCount = null;

    private $fFilter = null;
    private $fGrouper = null;
    private $fSorter = null;
    private $fRange = null;
    public $fUpdatedValues = null;
    public $fNewValues = null;

    public $dataObjects = null;
    public $boundDataMap = null;

    public $optionsData = null;

    public $active = false;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty('dataStorage', pbValue);
      $this->serializeProperty('prefix', pbValue, '');
      $this->serializeProperty('cache', pbSet, array());
      $this->serializeProperty('cacheMode', pbValue, dscmBody);
      $this->serializeProperty('onDeletingObject', pbValue);
      $this->serializeProperty('onDeleteObject', pbValue);
      $this->serializeProperty('onUpdateObjectPropertyValue', pbValue);
      
      $this->serializeProperty('preloadObjectCount', pbValue, 0);

      $this->boundDataMap = $this->createOwnedObject('bmBoundDataMap', array('name' => 'boundDataMap'));
      $this->dataObjects = $this->createOwnedObject('bmDataObjects', array('name' => 'dataObjects'));
      $this->optionsData = $this->createOwnedObject('bmDataSourceOptionsData', array('name' => 'optionsData'));

      $this->publishMethod('update');
      $this->publishMethod('deleteObject');
      
      if ($this->dataStorage == '') {
        $this->dataLink = $application->mainLink;
      } else {
        $this->updateLink();
      }

    }
    
    //TODO
    //public function __clone() {
      
      
      
    //}
    
    private function updateLink() {
      $dataLinks = $this->application->dataLinks;
      $dataStorage = $this->dataStorage;
      if (array_key_exists($dataStorage, $dataLinks->items)) {
        $this->dataLink = $dataLinks->items[$dataStorage];
      }
    }
    
    public function getter($propertyName) {
      switch ($propertyName) {
        case 'totalObjectCount':
          if ($this->fTotalObjectCount == null) {
            $this->fTotalObjectCount = $this->dataLink->countObjects($this, $this->filter, $this->grouper);
          }
          return $this->fTotalObjectCount;
        break;
        case 'filter':
          if ($this->fFilter == null) {
            $this->fFilter = $this->createOwnedObject('bmDataFilter', array('name' => 'filter')); 
          }
          return $this->fFilter;
        break;
        case 'sorter':
          if ($this->fSorter == null) {
            $this->fSorter = $this->createOwnedObject('bmDataSorter', array('name' => 'sorter'));
          }
          return $this->fSorter;
        break;
        case 'grouper':
          if ($this->fGrouper == null) {
            $this->fGrouper = $this->createOwnedObject('bmDataGrouper', array('name' => 'grouper'));
          }
          return $this->fGrouper;
        break;
        case 'range':
          if ($this->fRange == null) {
            $this->fRange = $this->createOwnedObject('bmDataRange', array('name' => 'range'));
          }
          return $this->fRange;
        break;
        case 'updatedValues':
          if ($this->fUpdatedValues == null) {
            $this->fUpdatedValues = $this->createOwnedObject('bmDataSourceClientValues', array('name' => 'updatedValues'));
          }
          return $this->fUpdatedValues;
        break;
        case 'newValues':
          if ($this->fNewValues == null) {
            $this->fNewValues = $this->createOwnedObject('bmDataSourceClientValues', array('name' => 'newValues'));
          }
          return $this->fNewValues;
        break;
        default:
          return parent::getter($propertyName);
        break;
      }
    }
    
    function setter($propertyName, $value) {
      parent::setter($propertyName, $value); 
      switch ($propertyName) {
        case 'dataStorage':
          $this->updateLink();
        break;
      }
    }
    
    function dataPropertyExists($propertyName) {
      foreach ($this->boundDataMap->dataObjectMaps->items as $objectMap) {
        foreach ($objectMap->propertiesMap->items as $propertyMap) {
          if ($propertyName == $propertyMap->propertyName) {
            return true;
          }
        }
      }
      return false;
    }

    public function update() {
      $this->saveObjects();
      foreach ($this->newValues->values as $values) {
        if ($object = $this->newObject($this->getNewId())) {
          foreach ($this->objectProperties->items as $property) {
            $propertyName = $property->propertyName;
            if (array_key_exists($propertyName, $values)) {
              $object->$propertyName = $values[$object->id];
            } else {
              $object->$propertyName = null;
            }
          }
        }
      }
      if (array_key_exists('delete', $this->updatedValues->values)) {
        foreach ($this->updatedValues->values['delete'] as $key => $value) {
          if ($value) {
            $this->deleteObject($key);
          }
        }
      }
    }

    public function saveObjects() {
      $this->flush();
      if ($this->optionsData->save) {
        foreach ($this->updatedValues->values as $propertyName => $values) {
          foreach ($values as $key => $value) {
            if (!$this->dataObjects->exists($key)) {
              $dataObject = $this->appendObject($key);
            } else {
              $dataObject = $this->dataObjects->items[$key];
            }
            if (($result = $this->callEventHandler($this->onUpdateObjectPropertyValue, array('dataObject' => $dataObject, 'propertyName' => $propertyName, 'value' => $value))) === false) {
              $dataObject->$propertyName = $value;
            }
          }
        }
        
        foreach ($this->dataObjects->items as $object) {
          $this->dataLink->saveObject($this, $object->id);
        }
      } else {
        //TODO
      }
    }

    public function objectExists($id) {
      return $this->dataLink->objectExists($this, $id);
    }

    public function newObject($id = null) {
      if ($this->optionsData->new) {
        if ($id == null) {
          $id = $this->application->getNextId(); 
        }
        return $this->dataLink->newObject($this, $id);
      } else {
        //TODO
      }
    }

    public function saveObject($id) {
      if ($this->optionsData->save) {
        return $this->dataLink->saveObject($this, $id);
      } else {
        //TODO
      }
    }
    
    public function appendObject($id) {
      return $this->dataLink->loadObject($this, $id);
    }

    public function loadObject($id) {
      $this->flush();
      return $this->dataLink->loadObject($this, $id);
    }
    
    public function flush() {
      $this->fTotalObjectCount = null;
      $this->dataObjects->clear();
    }
    
    public function updateRelations($objectIds) {
      $this->dataLink->updateRelations($this, $objectIds);
    }
    
    public function deleteRelations($objectIds) {
      $this->dataLink->deleteRelations($this, $objectIds);
    }

    public function loadObjects() {
      $this->flush();
      $range = $this->range;
      if ($range->length != 0) {
        if (($range->start > $this->totalObjectCount) || ($range->start < 0)) {
          $range->restoreValue('start');
          //TODO ERROR; 
        }
        if ($range->length < 0) {
          
          $range->restoreValue('length');
          //TODO ERROR; 
        }
      } else {
        $range = null;
      }
        //print get_class($this->dataLink);
      return $this->dataLink->loadObjects($this, $this->filter, $this->grouper, $this->sorter, $range);
    }

    public function deleteObject($id) {
      if (($this->callEventHandler($this->onDeletingObject, array('id' => $id))) === false) {
        if ($this->optionsData->delete) {
          $this->dataLink->deleteObject($this, $id);
          $this->fTotalObjectCount--;
          $this->callEventHandler($this->onDeleteObject, array('id' => $id));
        } else {
          //TODO: ERROR
        }
      }
    }
    public function deleteObjects() {
      if ($this->optionsData->delete) {
        return $this->dataLink->deleteObjects($this, $this->filter);
        $this->fTotalObjectCount = null;
      } else {
        //TODO: ERROR
      }
    }
    
    public function setLink($linkName, $linkedObjectName) {
      $this->dataLink->setLink($linkName, array($this->boundDataMap->mainObjectName, $linkedObjectName));
    }

  }

?>
