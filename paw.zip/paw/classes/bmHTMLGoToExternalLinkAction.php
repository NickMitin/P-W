<?php

  class bmHTMLGoToExternalLinkAction extends bmHTMLCustomAction {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("link", pbValue);

    }
    
    public function toHTML() {
      return $this->link;
    }
    
    public function execute($sender, $arguments) {
      $this->application->gotoURL($this->link);
    }
    
  }
  
?>
