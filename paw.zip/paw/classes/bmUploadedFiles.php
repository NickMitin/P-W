<?php

  class bmUploadedFiles extends bmCollection {

    public $collectionItemClass = "bmUploadedFile";
    public $keyPropertyName = "fileName";

    function getFileByPropertyNameKey($propertyName, $key) {
      foreach ($this->items as $file) {
        if (($file->propertyName == $propertyName) && ($file->key == $key)) {
          return $file;
        }
      }
      return null;
    }

  }

?>
