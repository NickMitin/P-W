<?php

  class bmCustomFont extends bmPersistentObject {

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("fontName", pbValue, "Verdana");
      $this->serializeProperty("size", pbValue, 8);
      $this->serializeProperty("style", pbValue, 0);

    }

  }

?>