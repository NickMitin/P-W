<?php

  class bmHTMLWordListPainter extends bmHTMLCustomDataControlPainter {
    
    private $groupingRowValues = array();
    private $switchForm = '';
    private $visibleCount = 0;
    
    public function drawControl($control) {
    
      $result = '';
      $result .= $this->drawDataRows($control); 
      return $result;
    }
    
    function drawDataRows($control) {
      
      $i = 1;
      
      $result = '';
      
      if ($control->boundData->dataObjects->count) {
        foreach ($control->boundData->dataObjects->items as $object) {
          $rowOrder = ($i % 2 == 0) ? 1 : 2;
          $result .= $this->drawDataRow($control, $object, $rowOrder, $control->boundData->range->start + $i);
          ++$i;     
        }
      }
      return $result;
    }
    
    function drawDataRow($control, $dataObject, $rowOrder, $rowNumber) {
      if ($control->optionsView->rowToolBar) {
        $dataObject->toolBar = true;
      }
      if ($control->mode == dcmEdit) {
        $dataObject->delete = false;
      }
      switch ($rowOrder) {
        case 1:
          $styleName = $control->styles->oddWord;
        break;
        case 2:
          $styleName = $control->styles->evenWord;
        break;
      }
      $result = "";
      //$mode = (in_array($dataObject->id, $control->editModeRecordList)) ? rmEdit : rmView;
      //$saveControlMode = $control->mode;
      //if (($saveControlMode) && ($mode == rmEdit)) {
      //  $control->mode = dcmEdit;
      //}
      $customDrawDataRow = $control->callEventHandler($control->onCustomDrawDataRow, array("dataObject" => $dataObject, "rowOrder" => $rowOrder, "rowNumber" => $rowNumber, 'mode' => 1));
      $ownerDraw = is_bool($customDrawDataRow);
      $dataRow = '<div style="float: left;" class="' . $styleName . '">';
      foreach ($control->items->items as $item) {
        $fieldName = $item->propertyName; 
        if ($item->visible) {
          $dataRow .= $this->drawDataCell($control, $dataObject, $dataObject->$fieldName, $item, $rowNumber);
        }
      }
      $dataRow .= '</div>';
      //$control->mode = $saveControlMode;
      if ($ownerDraw) {
        $result .= $dataRow;
      } else {
        $result .= $customDrawDataRow;
      }
      return $result;
    }
    
    function drawDataCell($control, $dataObject, $value, $column, $rowNumber) {
      $column->inplaceEdit->keyValue = $dataObject->id;
      $column->inplaceEdit->value = $value;
      if (($result = $control->callEventHandler($control->onCustomDrawDataCell, array("dataObject" => $dataObject, "rowNumber" => $rowNumber, "columnName" => $column->name))) === false) {
        $result = $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default");
      }
      if ($rowNumber == 1) {
        $style = $column->styles->firstCell;
      } elseif ($rowNumber == $control->boundData->dataObjects->count) {
        $style = $column->styles->lastCell;
      } else {
        $style = $column->styles->cell;
      }
      return '<div style="float: left;" class="' . $style . '">' . $result . '</div>';
    }

  }

?>
