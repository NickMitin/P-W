<?php

  define('miaLeft', 'alignLeft');
  define('miaRight', 'alignRight');
  define('mioVertical', 1);
  define('mioHorizontal', 2);

  class bmMenuItems extends bmCollection {

    public $collectionItemClass = 'bmMenuItem';
    public $keyPropertyName = 'caption';
    public $styles = null;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty('alignment', pbValue, miaLeft);
      $this->serializeProperty('separator', pbValue);
      $this->serializeProperty('orientation', pbValue, mioHorizontal);
      $this->serializeProperty('inheritStyles', pbValue, true);
      
      $this->styles = $this->createOwnedObject('bmMenuItemsStyles', array('name' => 'styles'));
      
    }

  }

?>
