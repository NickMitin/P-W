<?php

  class bmHTMLInplaceComboBoxEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    function drawInDataCell() {
      $control = $this->control;
      $dataControl = $control->owner->collectionOwner;
      $result = "";
      switch ($dataControl->mode) {
        case gmView:
          $result .= $control->options->items[$control->value]->caption;
          break;
        case gmEdit:
          $result = "<select class=\"$this->rowStyle\" style=\"width: 100%;\" name=\"" . $dataControl->dataSource->getComponentString() . ".newValues." . $control->owner->propertyName . "[$control->keyValue]\">\n";
          foreach ($control->options->items as $item) {
            $result .= "<option value=\"$item->value\"" . ifElse($item->selected, " selected", "") . ">$item->caption</option>\n";
            unset($item);
          }
          $result .= "</select>\n";
          break;
      }
      return $result;
    }

    function drawInNewRow() {
      $control = $this->control;
      $dataControl = $control->owner->collectionOwner;
      $result = "<select name=\"" . $dataControl->dataSource->getComponentString() . ".newValues." . $control->owner->propertyName . "[0]\">\n";
      foreach ($control->options->items as $item) {
        $result .= "<option value=\"$item->value\">$item->caption</option>\n";
        unset($item);
      }
      $result .= "</select>\n";
      return $result;
    }
    
  }

?>
