<?php
  
  class bmHTMLPasswordEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      return '<input id="' . $control->name . 'Edit" type="password" style="padding: 0; margin: 0; width: 100%;" class="' . $control->styles->default . '" name="' . $control->getComponentString() . '.value" value="' . $this->application->validator->formatXMLValue($control->value) . '"/>';
    }
  
  }
  
?>