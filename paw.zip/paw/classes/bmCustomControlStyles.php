<?php

  class bmCustomControlStyles extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('container', pbValue, 'default');
      $this->publishProperty('content', pbValue, 'default');
      $this->serializeProperty('default', pbValue, 'default');

    }

  }

?>
