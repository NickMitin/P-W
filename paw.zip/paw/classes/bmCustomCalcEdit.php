<?php

  class bmCustomCalcEdit extends bmCustomEdit {
    
  }

?>