<?php

  class bmComboBoxEditStyles extends bmCustomControlStyles {

  }

?>