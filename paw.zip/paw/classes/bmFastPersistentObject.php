<?php

  define("pbValue", 1);
  define("pbReference", 2);
  define("pbSet", 3);

  abstract class bmPersistentObject extends bmObject {

    public $name = '';
    public $shouldSerialize = true;
    public $fObjectId = 0;
    protected $persistentPropertyValues = array();
    protected $persistentPropertyIds = array();
    protected $persistentPropertyTypes = array();
    protected $persistentPropertyDefaultValues = array();
    protected $persistentPropertyInitialValues = array();
    protected $persistentPropertyFromStorage = array();
    protected $publishedMethods = array();      
    protected $publishedProperties = array();      

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->name = $parameters['name'];
      
                                                     //&& ($this->ownerForm->name === $owner->ownerName))
      $sessionHash = md5($this->application->session->id . $this->application->session->userId);
      $fromSession = false;
      
      if (isset($owner) && ($owner->fObjectId != 0)) {
        if (array_key_exists('id', $parameters)) {
          $this->hasClientMirror = $parameters['hasClientMirror'];
          $this->fObjectId = $parameters['id'];
        } else {
          $cursor = mysql_query("select `id`, `hasClientMirror`, `isProperty` from `object_session` where `name` = '" . mysql_real_escape_string($this->name) . "' and `ownerId` = '" . $owner->fObjectId . "' and `sessionHash` = '" . $sessionHash . "';", $this->application->systemLink);
          $fromSession = mysql_num_rows($cursor) > 0;
          if (!$fromSession) {
            $cursor = mysql_query("select `id`, `hasClientMirror`, `isProperty` from `object` where `name` = '" . mysql_real_escape_string($this->name) . "' and `ownerId` = '" . $owner->fObjectId . "';", $this->application->systemLink);
          }
          if (mysql_num_rows($cursor) > 0) {
            $this->fObjectId = mysql_result($cursor, 0, 0);
            $this->hasClientMirror = mysql_result($cursor, 0, 1);
            $this->isProperty = mysql_result($cursor, 0, 2);
          }
        }
      }
      if ($this->fObjectId != 0) {
        if ($fromSession) {
          $propertiesCursor = mysql_query("select `id`, `name`, `passBy`, `value` from `property_session` where `objectId` = '" . $this->fObjectId . "' and `sessionHash` = '" . $sessionHash . "';", $application->systemLink);
        } else {
          $propertiesCursor = mysql_query("select `id`, `name`, `passBy`, `value` from `property` where `objectId` = '" . $this->fObjectId . "';", $application->systemLink);
        }
        while (($property = mysql_fetch_object($propertiesCursor)) !== false) {
          $this->persistentPropertyIds[$property->name] = $property->id;
          $this->persistentPropertyValues[$property->name] = $property->value;
          $this->persistentPropertyTypes[$property->name] = $property->passBy;
          $this->persistentPropertyDefaultValues[$property->name] = null;  
          $this->persistentPropertyInitialValues[$property->name] = $property->value;  
          $this->persistentPropertyFromStorage[$property->name] = true;  
        }
      }
    }
    
    public function restoreValue($propertyName) {
      $this->persistentPropertyValues[$propertyName] = $this->persistentPropertyInitialValues[$propertyName];
    }
    
    public function valueFromStrorage($propertyName) {
      return array_key_exists($propertyName, $this->persistentPropertyFromStorage);
    }

    public function getter($propertyName) {
      switch ($propertyName) {
        case "objectId":
          if ($this->fObjectId == 0) {
            $query = "insert into `object_session` (`sessionHash`, `name`, `className`, `formName`, `isProperty`, `hasClientMirror`) values (
              '" . md5($this->application->session->id . $this->application->session->userId) . "',
              '" . mysql_real_escape_string($this->name) . "',
              '" . mysql_real_escape_string(get_class($this)) . "',
              '" . mysql_real_escape_string($this->ownerName) . "',
              '" . $this->isProperty . "',
              '" . $this->hasClientMirror . 
            "')";
            mysql_query($query, $this->application->systemLink);
            $this->fObjectId = mysql_insert_id($this->application->systemLink);
          }
          return $this->fObjectId;
        break;
        default:
          if (array_key_exists($propertyName, $this->persistentPropertyValues)) {
            return $this->persistentPropertyValues[$propertyName];
          }                         
        break;
      }
    }

    public function setter($propertyName, $value) {
      switch ($propertyName) {
        case "objectId":
          $this->fObjectId = $value;
        break;
        default:
          if (array_key_exists($propertyName, $this->persistentPropertyValues)) {    
            $this->setPersistentProperty($propertyName, $value);
          }
        break;
      }
    }
    
    public function setPersistentProperty($propertyName, $value) {
      $validator = $this->application->validator;
      if ($value != $this->persistentPropertyDefaultValues[$propertyName]) {
        switch ($this->persistentPropertyTypes[$propertyName]) {
          case pbValue:
            $propertyValue = $value;
            $this->persistentPropertyValues[$propertyName] = $value;
          break;
          case pbReference:
            if (is_object($value)) {
              $propertyValue = $value->getComponentString();
              $this->persistentPropertyValues[$propertyName] = $value;
            } else {
              $currentObject = $this->application;
              $propertyValue = $value;
              $value = substr($value, 12);
              while (preg_match("/^(\w+)\.(.*)$/", $value, $matches)) {
                if (($currentObject instanceof bmCustomForm) && array_key_exists($matches[1], $currentObject->allComponents)) {
                  $currentObject = $currentObject->allComponents[$matches[1]];
                } elseif (array_key_exists($matches[1], $currentObject->components)) {
                  $currentObject = $currentObject->components[$matches[1]];
                } elseif ($currentObject->$matches[1]) {
                  $currentObject = $currentObject->$matches[1];
                }
                $value = $matches[2];
              }
              if ($currentObject instanceof bmCollection) {
                $this->persistentPropertyValues[$propertyName] = $currentObject->items[$value];
              } elseif (($currentObject instanceof bmCustomForm) && array_key_exists($value, $currentObject->allComponents)) {
                $this->persistentPropertyValues[$propertyName] = $currentObject->allComponents[$value];
              } elseif (array_key_exists($value, $currentObject->components)) {
                $this->persistentPropertyValues[$propertyName] = $currentObject->components[$value];
              } elseif (($this->fValue = $this->application->getForm($value)) === false) {
                $this->persistentPropertyValues[$propertyName] = null;
              }
            }
          break;
          case pbSet:
            if (is_array($value)) {
              $this->persistentPropertyValues[$propertyName] = $value;
            } else {
              $this->persistentPropertyValues[$propertyName] = split(',', $value);
            }  
            $propertyValue = $value;
          break;
        }
        if (isset($propertyValue)) {
          if (array_key_exists($propertyName, $this->persistentPropertyIds)) {
            mysql_query("update `property_session` set `value` = '" . mysql_real_escape_string($propertyValue) . "' where `id` = '" . $this->persistentPropertyIds[$propertyName] . "';", $this->application->systemLink); 
          } else {
            mysql_query("insert into `property_session` (`name`, `passBy`, `value`, `objectId`) values (
              '" . mysql_real_escape_string($propertyName) . "','"
                 . $this->persistentPropertyTypes[$propertyName] . "','"
                 . mysql_real_escape_string($propertyValue) . "','"
                 . $this->objectId . "');");
          }
      } else {
        $this->persistentPropertyValues[$propertyName] = $value;
          if (array_key_exists($propertyName, $this->persistentPropertyIds))
            mysql_query("delete from `property_session` where `id` = '" . $this->persistentPropertyIds[$propertyName] . "';", $this->application->systemLink);
          }
      }
    }

    protected function serializeProperty($name, $passBy, $defaultValue = null) {
      if (!array_key_exists($name, $this->persistentPropertyValues)) {
        $this->persistentPropertyValues[$name] = $defaultValue;
        $this->persistentPropertyTypes[$name] = $passBy;
      }
      $this->persistentPropertyDefaultValues[$name] =  $defaultValue;
    }
    
    protected function publishProperty($name, $type, $defaultValue = null) {
      if (!array_key_exists($name, $this->publishedProperties)) {
        $this->serializeProperty($name, $type, $defaultValue);
        $this->publishedProperties[$name] = 1;
      }
    }
    
    protected function deletePersistentProperty($name) {
      if (array_key_exists($name, $this->persistentPropertyValues)) {
        unset($this->persistentPropertyValues[$name]);
        unset($this->persistentPropertyDefaultValues[$name]);
        unset($this->persistentPropertyInitialValues[$name]);
        unset($this->persistentPropertyTypes[$name]);
      }
    }

    protected function publishMethod($name) {
      $this->publishedMethods[$name] = 1;
    }
    
    function customHandleRequest($elementName, $value) {
      return false;
    }

    function customHandleUploadedFile($file) {
      return false;
    }

    public function handleRequest($elementName, $value) {
      if ($this->customHandleRequest($elementName, $value) === true) {
        return true;
      } elseif (preg_match("/^([A-Za-z][A-Za-z0-9]*)(.*?)$/", $elementName, $matches)) {
        $elementName = $matches[1];
        if (strlen($matches[2])) {
          $component = null;
          $furtherRequest = substr($matches[2], 1);
          if (is_object($this->$elementName)) {
            $component = $this->$elementName;
            if (!($component instanceof bmPersistentObject)) {
              $component = null;
            } 
          }
          if ($component != null) {
            $component->handleRequest($furtherRequest, $value);
          } else {
            $this->application->errorHandler->addError(0, "The \"$elementName\" object doesn't exist within the \"$this->name\" object.");
          }
        } else {

          if (array_key_exists($elementName, $this->publishedProperties)) {
            $setterName = $elementName . "Setter";
            if (method_exists($this, $setterName)) {
              if (!$this->$setterName($value)) {
                $this->application->errorHandler->addError(0, 'Invalid "' . $this->name . '.' . $elementName.  '" property value.');                
              }    
            } else {
              $this->application->errorHandler->addError(0, "There is no setter defined for the \"" . $this->name . ".$elementName\" property.");
            }  
          } elseif (array_key_exists($elementName, $this->publishedMethods)) {
            $this->$elementName($value);  
          } else {                                                            
            $this->application->errorHandler->addError(0, "The \"" . $this->name . "\" object does not contain or publish the \"" . $elementName . "\" property or method.");
          }
        }
      } else {
        //TODO ERROR
      }
    }
    
    public function createOwnedObject($className, $parameters = null, $isProperty = true) {
      
      if ($className == "bmObjectLink") {
        $link = new $className($this->application, $this, $parameters);
        $objectNode = $this->ownerForm->map->importNode($link->object->fNode, true);
        $objectNode->setAttribute('name', $link->name);
        $this->fNode->replaceChild($objectNode, $link->fNode);
        $object = parent::createOwnedObject(get_class($link->object), array("name" => $link->name), $link->object->isProperty); 
        unset($link);
      } else {
        $parameters['ownerName'] = $this->name;
        
        $object = parent::createOwnedObject($className, $parameters, $isProperty);
        
      }
      return $object;
    }
    
  }

?>
