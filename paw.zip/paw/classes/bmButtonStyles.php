<?php
  
  class bmButtonStyles extends bmCustomControlStyles {
    
  }
  
?>