<?php

  class bmPasswordEditStyles extends bmCustomControlStyles {

  }

?>