<?php

  class bmDataSourceClientValues extends bmComponent {

    public $values = array();
    
    function customHandleRequest($elementName, $value) {

      $this->$elementName = $value;

      return true;

    }
    
    public function getter($propertyName) {
        
      return $this->values[$propertyName];
      
    }
    
    public function setter($propertyName, $value) {
      
      $this->values[$propertyName] = $value;
      
    }

  }

?>
