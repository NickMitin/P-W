<?php

  class bmDataTableFiles extends bmWebComponent {

    function customHandleUploadedFile($file) {

      $field = $this->owner->fieldList->items[$file->propertyName];
      if (isset($field->acceptFiles)) {
        if (is_int(strpos($field->fileTypes, $file->type))) {
          $fieldName = $file->propertyName;
          $fieldValues = &$this->owner->newValues->$fieldName;
          #$fieldValues[$file->key] = $file->realName;
        }
      }
      return true;

    }

  }

?>