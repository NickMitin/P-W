<?php

  class bmChatStyles extends bmCustomControlStyles {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("oddReply", pbValue, "default");
      $this->serializeProperty("evenReply", pbValue, "default");
      $this->serializeProperty("replyTime", pbValue, "default");
      $this->serializeProperty("userName", pbValue, "default");
      $this->serializeProperty("replyText", pbValue, "default");

    }

  }

?>
