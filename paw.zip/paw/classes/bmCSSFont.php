<?php

  define("fsBold", 1);
  define("fsItalic", 2);
  define("fsUnderlined", 4);
  define("fsStruckOut", 8);

  class bmCSSFont extends bmCustomFont {

    function toCSS() {
      $result = "font-family: \"$this->fontName\", sans-serif;\nfont-size: $this->size" . "pt;\n";
      if ($this->style & fsBold) {
        $result .= "font-weight: bold;\n";
      }
      if ($this->style & fsItalic) {
        $result .= "font-style: italic;\n";
      }
      if ($this->style & fsUnderlined) {
        $result .= "text-decoration: underline;\n";
      }
      if ($this->style & fsStruckOut) {
        $result .= "text-decoration: line-through;\n";
      }
      return $result;
    }  

  }

?>