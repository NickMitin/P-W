<?php

  class bmCSSStyleSheet extends bmCollectionItem {

    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("fileName", pbValue, "");

    }

  }

?>