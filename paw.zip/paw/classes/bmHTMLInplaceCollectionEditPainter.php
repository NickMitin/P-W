<?php

  class bmHTMLInplaceCollectionEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    function draw($control, $dataControl, $dataCollection, $style) {
      $validator = $this->application->validator;
      switch ($dataControl->mode) {
        case dcmEdit:
          $result = "<input style=\"width: 78%;\" type=\"text\" value=\"(" . get_class($control->value) . ")\" readonly=\"readonly\" />";
          $result .= "<button type=\"button\" style=\"width: 19%\" onclick=\"bmCollectionEditOpen('" . $dataControl->boundData->component->getComponentString() . "', '" . $control->owner->name . "')\">...</button>";
        break;
      }
      return $result;
    }

  }

?>
