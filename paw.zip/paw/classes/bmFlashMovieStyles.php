<?php

  class bmFlashMovieStyles extends bmCustomControlStyles {
    
  }
  
?>