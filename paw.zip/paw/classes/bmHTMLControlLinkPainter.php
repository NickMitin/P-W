<?php

  class bmHTMLControlLinkPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      return "";
    }

  }

?>