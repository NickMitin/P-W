<?php

  class bmFieldList extends bmCollection {

    public $collectionItemClass = "bmDataField";
    public $keyPropertyName = "alias";
    
    /*

    function internalAdd($fieldName, $tableName, $type) {
      $field = new bmFieldInfo($this->session, $this, null);
      $this->items[$fieldName] = &$this->internalItems[$this->count - 1];
      $field->propertyName = $fieldName;
      $field->tableName = $tableName;
      $field->type = $type;
    }

    function add($fieldName, $tableName, $type) {
      if (!array_key_exists($fieldName, $this->items)) {
        $this->internalAdd($fieldName, $tableName, $type);
      }
    }
    
    function retrieve() {
      $this->clear();
      if ($this->owner->cursor) {
        while ($fieldInfo = mysql_fetch_field($this->owner->cursor)) {
          if ($fieldInfo)
          $this->internalAdd($fieldInfo->name, $fieldInfo->table, $fieldInfo->type);
        }
      } else {
        $this->session->errorHandler->addError(0, "Failed to retrieve fields. Perhaps " . $this->owner->name . " datasource is not initialized.");
      }
    }
    
    */

    function toSQL() {
      $fields = array();
      if ($this->count) {
        foreach ($this->items as $dataField) {
          $fields[] = $dataField->toSQL();
          unset($dataField);
        }
      }
      return join($fields, ", ");
    }
    
  }

?>