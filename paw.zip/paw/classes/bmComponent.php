<?php                                       

  abstract class bmComponent extends bmPersistentObject {

    public $creationOrder = 0;
    public $ownerForm = null;
    public $components = array();
    public $hasClientMirror = 0;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      if ($owner instanceof bmComponent) {
        $this->creationOrder = count($owner->components);
        $owner->components[$this->name] = $this;
      }
      if ($this instanceof bmCustomForm) {
        $this->ownerForm = $this;
      } else {
        $this->ownerForm = $this->owner;
        while (($this->ownerForm != null) && (!($this->ownerForm instanceof bmCustomForm))) {
          $this->ownerForm = $this->ownerForm->owner;
        }
        if ($this->ownerForm == null) {
          $this->ownerForm = $this->owner;
        }
      }
      
      if (($this->ownerForm != null) && (!($this instanceof bmCustomForm)) && ($this->ownerForm instanceof bmCustomForm)) {
        $this->ownerForm->allComponents[$this->name] = $this;
      }
      
      $this->createOwnedObjects();
      
    }
    
    public function createOwnedObject($className, $parameters = null, $isProperty = true) {
      if ($className == 'bmFormLink') {
        $link = new $className($this->application, $this, $parameters);
        require_once('./forms/bm' . $this->ownerForm->name . '.php');
        $formMap = new DOMDocument('1.0', 'utf-8');
        $formMap->load('./forms/bm' . $this->ownerForm->name . '.xml');
        $xPath = new DOMXPath($formMap);
        
        $properties = $xPath->query('/object/property');
        foreach($properties as $property) {
          $propertyName = (string)$property->getAttribute('name');
          $propertyValue = (string)$property->nodeValue;
          $this->ownerForm->resetProperties[$propertyName] = $propertyValue;
          
        }
        
        $nodes = $xPath->query('/object/object');
        foreach($nodes as $node) {
          $newNode = $this->map->importNode($node, true);
          $this->node->insertBefore($newNode, $link->fNode);
        } 
        $this->fNode->removeChild($link->fNode);
        unset($link);
        $this->createOwnedObjects();
        $object = null;
      } else {
        $object = parent::createOwnedObject($className, $parameters, $isProperty);
      }
      return $object;
    }    
    
    public function createOwnedObjects() {
      if ($this->fNode != null) {
        $xPath = new DOMXPath($this->map);
        $components = $xPath->query("object[@isProperty=0]", $this->fNode);
        foreach ($components as $component) {
          $className = (string)$component->getAttribute("class");
          $name = (string)$component->getAttribute("name");
          if (!array_key_exists($name, get_object_vars($this)) && !array_key_exists($name, $this->components)) { 
            $object = $this->createOwnedObject($className, array("name" => $name), false);
            if (is_subclass_of($className, "bmComponent")) {
              $this->components[$name] = $object;
            }
          }
        }
      }
    }
    
    public function getter($propertyName) {
      if (array_key_exists($propertyName, $this->components)) {
        return $this->components[$propertyName];
      } else {
        return parent::getter($propertyName);
      }
    }

    public function getComponentString() {

      $result = $this->name;
      if (isset($this->owner)) {
        $result = $this->owner->getComponentString() . "." .$result;
      }
      return $result;
    }
    
    public function callEventHandler($methodName, $arguments) {
      if ($this->application->actions->exists($methodName)) {
        return $this->application->actions->execute($methodName, $this, $arguments);
      } elseif (method_exists($this->ownerForm, $methodName)) {
        return $this->ownerForm->$methodName($this, $arguments);
      } elseif (method_exists($this->application->fTemplateContainer, $methodName)) {
        return $this->application->fTemplateContainer->$methodName($this, $arguments);
      } else {
        return false;
      }
    }    
        
  }

?>
