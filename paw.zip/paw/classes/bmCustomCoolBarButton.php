<?php
  
  class bmCustomCoolBarButton extends bmCollectionItem {
    
  }
  
?>
