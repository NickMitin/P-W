<?php

  class bmDataFilterConditionField extends bmCollectionItem {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("fieldName", pbValue);
      $this->serializeProperty("objectName", pbValue);

    }

  }

?>