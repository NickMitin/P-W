<?php

  define('aibLink', 1);
  define('aiText', 2);

  class bmCustomMenu extends bmCustomControl {
    
    public $menuItems = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty('separator', pbValue, '');
      $this->publishProperty('activeItem', pbValue, '');
      $this->serializeProperty('activeItemBehaviour', pbValue, aibLink);
      $this->serializeProperty('subItemsHideDelay', pbValue, 0);
      $this->serializeProperty('IE7', pbValue, false);
      
      $this->serializeProperty('onCustomDrawMenuItem', pbValue);
      $this->serializeProperty('onCustomDrawItemCaption', pbValue);
      $this->serializeProperty('onGetMenuItemStyle', pbValue);
      $this->serializeProperty('onItemClick', pbValue);
      
      $this->menuItems = $this->createOwnedObject('bmMenuItems', array('name' => 'menuItems'));
      
      if (($this->activeItem == '') && ($this->menuItems->count > 0)) {
        $this->activeItem = key($this->menuItems->items); 
      }

    }
    
    public function getClientPropertyValues() {
      $result = '';
      //$result .= 'this.subItemsHideDelay = ' . $this->subItemsHideDelay . ';';
      $result .= 'this.activeItem = "' . addslashes($this->activeItem) . '";';
      $result .= 'this.menuItemStyle = "' . $this->styles->actionLink . '";';
      $result .= 'this.menuItemHoveredStyle = "' . $this->styles->actionLinkHovered . '";';
      return $result;
    }
    
    public function activeItemSetter($value) {
      if ($value == '') {
        $this->activeItem = '';
        return true;
      } elseif (array_key_exists($value, $this->menuItems->items)) {
        $this->activeItem = $value;
        $this->callEventHandler($this->onItemClick, array('item' => $value));
        return true;
      } else {
        //TODO: ERROR;
      }
    }

  }

?>
