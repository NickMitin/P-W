<?php

  define("smPost", "post");
  define("smGet", "get");
  define("smPut", "put");
  
  class bmCustomDataPanel extends bmCustomPanel {
    
    public $parameters = null;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("sendMethod", pbValue, smPost);
      $this->parameters = $this->createOwnedObject("bmDataPanelParameters", array("name" => "parameters"));

    }    
    
    
  }
  
?>
