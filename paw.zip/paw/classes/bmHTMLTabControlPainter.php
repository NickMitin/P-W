<?php
  
  class bmHTMLTabControlPainter extends bmHTMLStandaloneControlPainter {
    
    public function drawControl($control) {
      
      $result = '';
      
      $result = $this->drawTabs($control);
      
      
      foreach ($control->components as $component) {
        if ($component instanceof bmCustomControl) {
          $result .= $component->draw();
        }
      }
      return $result;
      
    }
    
    public function drawTabs($control) {
      $result = '<ul class="bmTabControlTabs">';
      foreach($control->tabs->items as $tab) {
        $result .= '<li class="bmTabControlTab">' . $tab->caption . '</li>';
      }
      $result .= '</ul>';
      return $result;
    }
    
    
  }
  
?>
