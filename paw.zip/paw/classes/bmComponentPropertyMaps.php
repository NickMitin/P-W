<?php

  class bmComponentPropertyMaps extends bmCollection {

    public $collectionItemClass = "bmComponentPropertyMap";
    public $keyPropertyName = "propertyName";

  }

?>
