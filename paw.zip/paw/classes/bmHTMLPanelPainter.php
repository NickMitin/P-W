<?php
  
  class bmHTMLPanelPainter extends bmHTMLStandaloneControlPainter {
    
    function drawControl($control) {
      $result = '';

      foreach ($control->components as $component) {
        if ($component instanceof bmCustomControl) {
          $result .= $component->draw();
        }
      }

      return $result;
    }
    
  }
  
?>
