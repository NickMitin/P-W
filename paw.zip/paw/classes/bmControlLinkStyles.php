<?php

  class bmControlLinkStyles extends bmPersistentObject {

  }
  
?>