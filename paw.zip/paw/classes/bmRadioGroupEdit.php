<?php
  
  class bmRadioGroupEdit extends bmCustomRadioGroupEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
