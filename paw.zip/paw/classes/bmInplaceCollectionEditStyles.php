<?php
  
  class bmInplaceCollectionEditStyles extends bmCustomControlStyles {
    
      
    
  }
  
?>
