<?php
  
  class bmDataPanel extends bmCustomDataPanel {
    
    public $hasClientMirror = 1;
    
  }
  
?>
