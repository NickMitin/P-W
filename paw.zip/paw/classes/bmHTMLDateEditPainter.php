<?php
  
  class bmHTMLDateEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      $readOnly = ($control->readOnly) ? " readonly=\"readonly\"" : "";
      return "<input id=\"" . $control->name . "Edit\" type=\"text\" style=\"width: 100%;\" class=\"" . $control->styles->default . "\" name=\"" . $control->getComponentString() . ".value\" value=\"" . $this->application->validator->formatOutput($control->caption, true) . "\"" . $readOnly . "/>";
    }
  
  }
  
?>
