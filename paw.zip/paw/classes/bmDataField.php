<?php

  class bmDataField extends bmCollectionItem {

    public $fieldName = "";
    public $alias = "";
    public $type = "int";
    public $collectionClass = "bmFieldList";
    public $acceptFiles = false;
    public $fileTypes = "";

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("fieldName", pbValue);
      $this->serializeProperty("alias", pbValue);
      $this->serializeProperty("type", pbValue);
      $this->serializeProperty("acceptFiles", pbValue);
      $this->serializeProperty("fileTypes", pbValue);

    }

    function toSQL() {
      return "`" . $this->collectionOwner->tableName . "`.`$this->propertyName` as `$this->alias`";
    }

  }


?>