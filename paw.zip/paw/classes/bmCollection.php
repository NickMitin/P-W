<?php

  abstract class bmCollection extends bmPersistentObject {

    public $items = array();
    public $count = 0;
    public $collectionItemClass = "bmCollectionItem";
    public $keyPropertyName = "index";
    public $collectionOwner;
    

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      if ($this->fNode != null) { 
        $xPath = new DOMXPath($this->map);
        $collectionItems = $xPath->query("object", $this->node);
        foreach ($collectionItems as $collectionItem) {
          $object = $this->createOwnedObject($collectionItem->getAttribute("class"), array("name" => $collectionItem->getAttribute("name")), false);
        }
      }
    }
    
    public function exists($keyValue) {
      return array_key_exists((string)$keyValue, $this->items);
    }
    
    public function delete($keyValue) {
      if (array_key_exists((string)$keyValue, $this->items)) {
        $objectIndex = $this->items[$keyValue]->objectIndex;
        $item = $this->items[$keyValue];
        if ($this->fNode != null) {
          $this->fNode->removeChild($item->fNode);
          $item->fNode = null;
        }
        unset($this->items[$keyValue]);
        unset($this->objects[$objectIndex]);
        $this->count--;
      } 
    }
    
    public function add($keyValue, $collectionItemClass = null, $parameters = null) {
      if (!array_key_exists((string)$keyValue, $this->items)) {
        if ($collectionItemClass == null) {
          $collectionItemClass = $this->collectionItemClass;
        }
        $parameters["name"] = $keyValue;
        $item = new $collectionItemClass($this->application, $this, $parameters);
        $keyPropertyName = $this->keyPropertyName;
        $item->$keyPropertyName = $keyValue;
        return $item;
      }
    }

    public function clear() {
      $propertyName = $this->keyPropertyName;
      /*while ($this->count > 0) {
        $item = end($this->items);
        #print $item->$propertyName . '<br/>';
        $this->delete($item->$propertyName);
      }*/
      $arrayKeys = array_keys($this->items);
        
      foreach ($arrayKeys as $key) {
        $item = $this->items[$key];
        $objectIndex = $item->objectIndex;
        if ($this->fNode != null) {
          $this->fNode->removeChild($item->fNode);
          $item->fNode = null;
        }
        unset($this->items[$key]);
        unset($this->objects[$objectIndex]);
      } 
      $this->count = 0;
      
    }

    public function getComponentString() {
      return $this->owner->getComponentString() . "." . $this->name; 
    }

  }

?>
