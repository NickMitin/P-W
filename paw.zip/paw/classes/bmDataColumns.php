<?php

  class bmDataColumns extends bmCollection {

    public $visibleCount = 0;
    public $collectionItemClass = 'bmDataColumn';
    public $keyPropertyName = 'propertyName';

    function clear() {
      parent::clear();
      $this->visibleCount = 0;
    }

    function add($keyValue, $inplaceEditClass = 'bmInplaceTextEdit') {
      $this->visibleCount++;
      return parent::add($keyValue, null, array('inplaceEditClass' => $inplaceEditClass));
    }

  }

?>
