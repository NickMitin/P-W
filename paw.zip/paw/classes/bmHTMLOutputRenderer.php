<?php
  
  class bmHTMLOutputRenderer extends bmCustomOutputRenderer {
    
    private function getScriptPath($fileName) {
      $filePath = engineRoot . "scripts/" . $fileName;
      if (!file_exists($filePath)) {
        $filePath = "./forms/" . $fileName;
        if (!file_exists($filePath)) {
          $filePath = false;
        } else {
          $formName = $this->application->session->formName;
          $formFileName = 'bm' . $formName . '.js';
          if (($formFileName == $fileName) || ($fileName == 'bmfTemplateContainer.js')) {
            $filePath = $this->application->path . "forms/" . $fileName;
          } else {
            $filePath = false;
          }
        }
      } else {
        $filePath = $this->application->path . "scripts/" . $fileName;
      }
      return $filePath;
    }
    
    private function getCSSPath($fileName) {
      $filePath = engineRoot . 'css/' . $fileName;
      if (!file_exists($filePath)) {
        $filePath = './forms/' . $fileName;
        if (!file_exists($filePath)) {
          $filePath = false;
        } else {
          $formName = $this->application->session->formName;
          $containerFileName = 'bm' . $this->application->$formName->container . '.css';
          $formFileName = 'bm' . $formName . '.css';
          if (($containerFileName == $fileName) || ($formFileName == $fileName) || ($fileName == 'bmfTemplateContainer.css')) {
            $filePath = $this->application->path . 'forms/' . $fileName;
          } else {
            $filePath = false;
          }
        }
      } else {
        $filePath = $this->application->path . "css/" . $fileName;
      }
      return $filePath;
    }
    
    public function loadAuxilaryModules() {
      
      foreach ($GLOBALS["loadedClasses"] as $className) {
        $this->loadAuxilaryModulesForClass($className);
        switch ($className) {
          case "bmObject":
            $this->loadAuxilaryModulesForClass("bmHTTPRequest");
            $this->loadAuxilaryModulesForClass("bmCGI");
          break;
          case "bmComponent":
            $this->loadAuxilaryModulesForClass("bmUserInfo");
          break;
          case "bmApplication":
            $this->application->clientScripts->add($this->application->path . 'main.js');
          break;
          case "bmHTMLForm":
            $this->loadAuxilaryModulesForClass("bmfTemplateContainer");
          break;
        }
      }
      
    }
    
    private function loadAuxilaryModulesForClass($className) {
      
      if (($filePath = $this->getScriptPath($className . ".js")) !== false) {
        $this->application->clientScripts->add($filePath);
      }
      
      if (($filePath = $this->getCSSPath($className . ".css")) !== false) {
        $this->application->styleSheets->add($filePath);
      }
      
    }
    
  }
  
?>
