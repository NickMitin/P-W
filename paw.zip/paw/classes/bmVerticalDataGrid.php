<?php
  
  class bmVerticalDataGrid extends bmCustomVerticalDataGrid {
    
    public $hasClientMirror = 1;
  
  }
  
?>
