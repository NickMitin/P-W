<?php

  class bmCustomHyperLinkEdit extends bmCustomEdit {
    
    public function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("hyperLink", pbValue);
      $this->serializeProperty("onGetHyperLink", pbValue);
    }

  }

?>
