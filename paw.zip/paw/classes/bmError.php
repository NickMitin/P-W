<?php

  class bmError extends bmCollectionItem {

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('text', pbValue);
      $this->serializeProperty('code', pbValue);
      
    }
    
  }

?>
