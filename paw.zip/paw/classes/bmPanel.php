<?php

  class bmPanel extends bmCustomPanel {
    
    public $hasClientMirror = 1;
    
  }
  
?>
