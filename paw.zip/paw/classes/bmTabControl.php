<?php
  
  class bmTabControl extends bmCustomTabControl {
    
    public $hasClientMirror = 1;
    
  }
  
?>
