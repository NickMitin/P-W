<?php
  
  class bmImageStyles extends bmCustomControlStyles {
    
  }
  
?>