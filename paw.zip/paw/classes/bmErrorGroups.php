<?php
  
  class bmErrorGroups extends bmCollection {

    public $collectionItemClass = 'bmErrorGroup';
    public $keyPropertyName = 'groupName';

  }
  
?>
