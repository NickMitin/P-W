<?php
  
  class bmCheckBoxListEditStyles extends bmCustomControlStyles {
    
  }
  
?>
