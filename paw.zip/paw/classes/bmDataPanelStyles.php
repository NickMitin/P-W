<?php
  
  class bmDataPanelStyles extends bmCustomControlStyles {
    
    public $default = "default";
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("default", pbValue);

    }
    
  }
  
?>