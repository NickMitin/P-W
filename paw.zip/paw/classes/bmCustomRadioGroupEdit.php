<?php

  define('rgeoVertical', 1);
  define('rgeoHorizontal', 2);
  
  class bmCustomRadioGroupEdit extends bmCustomOptionEdit {
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('orientation', pbValue, rgeoVertical);
    
    }    
    
  }
  
?>
