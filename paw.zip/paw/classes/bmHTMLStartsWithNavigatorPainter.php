<?php

  class bmHTMLStartsWithNavigatorPainter extends bmHTMLMenuPainter {
  
  }

?>
