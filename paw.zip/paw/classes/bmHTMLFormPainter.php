<?php

  class bmHTMLFormPainter extends bmCustomControlPainter {
    
    function drawClientScripts($control) {
      $result = '';
      foreach ($this->application->clientScripts->items as $clientScript) {
        $result .= '<script type="text/' . $clientScript->language . '" src="' . $clientScript->fileName . '"></script>';
      }
      return $result;
    }
    
    function drawStyleSheets($control) {
      $result = '';
      foreach ($this->application->styleSheets->items as $styleSheet) {
        $result .= '<link rel="stylesheet" href="' . $styleSheet->fileName . '" type="text/css"/>';
      }
      return $result;
    }

    function draw($control) {
      header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // expires in the past
      header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
      header("Cache-Control: no-store, no-cache, must-revalidate");  // HTTP/1.1
      header("Cache-Control: post-check=0, pre-check=0", false);
      header("Pragma: no-cache");
      header('content-type: ' . $control->contentType . '; charset=' . $control->encoding, true);
      $this->application->renderer->loadAuxilaryModules();
      $result = "<?xml version=\"1.0\" encoding=\"" . $control->encoding . "\"?>" . $control->documentType . "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\"><head><meta http-equiv=\"content-type\" content=\"" . $control->contentType . "; charset=" . $control->encoding . '"/>'; #<base href="' . $this->application->path . '" />
      $result .= $this->drawClientScripts($control);
      $result .= $this->drawStyleSheets($control);
      $result .= $this->application->errorHandler->toHTML();
      $result .= "<title>" . $this->application->title . " :: " . $control->title . "</title></head><body id=\"" . $control->name . "\" class=\"". $control->styles->default ."\" style=\"padding: 0; margin: 0;\"><div style=\"display: none;\" id=\"" . $control->name . "ElementsBuffer\"></div>";
      $result .= '<div id="' . $control->name . 'WaitScreen" style="position: absolute; display: block; z-index: 99999; left: 0; top: 0; width: 600px; height: 10px;">
        <object data="/chat/userResources/loading.swf" style="width: 600px; height: 10px;" type="application/x-shockwave-flash">
        <param value="sameDomain" name="allowScriptAccess"/>
        <param value="/chat/userResources/loading.swf" name="movie"/>
        <param value="false" name="menu"/>
        <param value="high" name="quality"/>
        </object>
      </div>';
      #$result .= '<div id="' . $control->name . 'WaitScreen" style="position: absolute; display: block; background-color: #ff0000; color: #ffffff;"> Дождитесь конца загрузки страницы... </div>';
      foreach ($control->components as $component) {
        if ($component instanceof bmCustomControl) {
          $result .= $component->draw();
        }
      }
      $result .= "</body></html>";
      return $result;
    }

  }

?>
