<?php
  
  class bmCustomFlash extends bmCustomControl {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("movie", pbValue, "");

    }
    
  }
  
?>
