<?php

  class bmHTMLImagePainter extends bmHTMLStandaloneControlPainter {
  
    function drawControl($control) {
      
      $width = $control->width;
      $height = $control->height;
      
      
      if (strpos($control->picture, '/chat/') !== false) {
        $path = '..';
      } else {
        $path = '.';
      }
      if (file_exists($path . $control->picture) && (($width == 'auto') || ($height == 'auto'))) {;
        $size = @getimagesize($path . $control->picture);
        if ($width == 'auto') {
          $width = $size[0];  
        }
        if ($height == 'auto') {
          $height = $size[1];  
        }
      }
      
      if ($control->borderRadius > 0) {
        $image = '';
      } else {
        $image = '<img id="' . $control->name . 'Image" style="border-style: none;" width="' . intval($width) . '" height="' . intval($height) . '" src="' . $control->picture . '" alt="' . $control->alternativeText . '"/>';
      }
      
      $result = $image;
          
      return $result;
      
    }
  
  }

?>
