<?php
  
  class bmCustomCheckBoxListEdit extends bmCustomDataControl {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('boundData', pbReference);
      $this->serializeProperty('updatingObject', pbValue, null);
      $this->serializeProperty('displayPropertyName', pbValue, '');

    }
    
    public function loadData() {
      $this->boundData->flush();
      $this->boundData->loadObjects();
    }
    
  }
  
?>
