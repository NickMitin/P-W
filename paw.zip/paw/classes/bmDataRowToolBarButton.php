<?php

  define('drtbbDelete', 'Delete');
  define('drtbbEdit', 'Edit');
  define('drtbbCustom', '');

  class bmDataRowToolBarButton extends bmCollectionItem {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('caption', pbValue);
      $this->serializeProperty('type', pbValue, drtbbCustom);
      $this->serializeProperty('resource', pbValue);
      //$this->serializeProperty('action', pbReference);
      $this->serializeProperty('action', pbValue);
      $this->serializeProperty('visible', pbValue, true);

    }
    
  }
  
?>
