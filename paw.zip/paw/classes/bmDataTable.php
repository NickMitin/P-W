<?php

  class bmDataTable extends bmWebComponent {

      private $cursor = null;
      private $dataLink = null;

      public $fieldList = null;
      public $sortInfos = null;
      public $newValues = null;

      public $current = null;
      public $blockCount = 0;
      public $blockStart = 0;
      public $blockEnd = 0;

      public $dataBaseName = "database";
      public $tableName = "table";
      public $keyFieldName = "id";
      public $autoLoad = false;
      public $active = false;
      public $blockNumber = 1;
      public $recordsPerBlock = 10;

      public $onInsertRecord = null; #InsertRecord(&$dataSource, &newRecord)
      public $onBeforeDeleteRow = null; #BeforeDeleteRecord(&$dataSource, $recordId)
      public $onAfterDeleteRow = null; #AfterDeleteRecords(&$dataSource, $recordIds)

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->publishProperty("autoLoad", pbValue);
      $this->publishProperty("dataBaseName", pbValue);
      $this->publishProperty("tableName", pbValue);
      $this->publishProperty("keyFieldName", pbValue);
      $this->publishProperty("blockNumber", pbValue);
      $this->publishProperty("recordsPerBlock", pbValue);

      $this->publishProperty("onInsertRecord", pbValue);
      $this->publishProperty("onBeforeDeleteRow", pbValue);
      $this->publishProperty("onAfterDeleteRow", pbValue);

      $this->publishMethod("manageRows");
      $this->publishMethod("sortAscending");
      $this->publishMethod("sortDescending");
      $this->publishMethod("clearSorting");

      $this->filter = $this->createOwnedObject("bmDataFilter", $parameters);
      $this->fieldList = $this->createOwnedObject("bmFieldList", $parameters);
      $this->sortInfos = $this->createOwnedObject("bmSortInfos", $parameters);
      
      $this->newValues = $this->createOwnedObject("bmDataTableClientValues", array("name" => "newValues"));

    }

    function initialize() {
      $dataLinks = $this->application->dataLinks;
      $dataBaseName = $this->dataBaseName;
      if (array_key_exists($dataBaseName, $dataLink->items)) {
        $this->dataLink = $dataLink->items[$dataBaseName];
      }
      parent::initialize();
    }

    function prepare() {
      parent::prepare();
      if ($this->autoLoad) {
        $this->open();
      }
    }

    function manageRows($value) {
      switch($value) {
        case mrDelete:
          $this->deleteRows();
          break;
        case mrUpdate:
          $this->updateRows();
          break;
        case mrInsert:
          $this->insertRows();
          break;
        default:
          //TODO: ERROR HERE;
          break;
      }
    }

    function deleteRows() {
      if (isset($this->newValues->delete)) {
        $uploadedFiles = $this->application->cgi->uploadedFiles;
        foreach ($this->fieldList->items as $fieldInfo) {
          if ($fieldInfo->acceptFiles) {
            $alias = $fieldInfo->alias;
            $values = &$this->newValues->$alias;
            foreach (array_keys($this->newValues->delete) as $key) {
              $uploadedFiles->deleteFile($values[$key]);
            }
          }
        }
        $this->internalDeleteRows($this->newValues->delete);
      } else {
        //TODO: ERROR HERE;
      }
    }

    function updateRows() {
      $keys = array_keys($this->newValues->update);
      $componentString = $this->getComponentString();
      $uploadedFiles = $this->application->cgi->uploadedFiles;
      foreach ($keys as $key) {
        $query = "update " . $this->tableName . " set ";
        foreach ($this->fieldList->items as $fieldInfo) {
          $alias = $fieldInfo->alias;
          if ($fieldInfo->acceptFiles) {
            $file = $uploadedFiles->getFileByFieldKey($componentString . ".newValues." . $alias . ".file", $key);
            if (!is_null($file)) {
              $values = &$this->newValues->$alias;
              $uploadedFiles->deleteFile($values[$key]);
              $uploadedFiles->serializeFile($file->fileName);
              $values[$key] = $file->fileName;
            }
          }
          $query .= $this->prepareUpdateKeyValue($fieldInfo, $key);
          unset($fieldInfo);
        }
        $query = substr($query, 0, -2) . " where " . $this->keyFieldName . " = \"$key\";\n";
        #print $query . "<br/>";
        $this->dataLink->query($query);
      }
    }

    function prepareUpdateKeyValue($fieldInfo, $key) {
      $alias = $fieldInfo->alias;
      if (isset($this->newValues->$alias)) {
        $values = $this->newValues->$alias;
        if (array_key_exists($key, $values)) {
          return $this->tableName . "." . $fieldInfo->propertyName . " = \"" . $this->application->validator->formatInput($values[$key]) . "\", ";
        }
      }
    }

    function validateProperty($propertyName, $value, &$result) {
      switch ($propertyName) {
        case "blockNumber":
          if ($this->application->validator->validateNumber($value) && ($value >= 0)) {
            $result = $value;
            return true;
          } else {
            return false;
          }
        break;
        case "recordsPerBlock":
          if ($this->application->validator->validateNumber($value) && ($value >= 0)) {
            $result = $value;
            return true;
          } else {
            return false;
          }
        break;
        default:
          parent::validateProperty($propertyName, $value, $result);
          break;
      }
    }

    function sortField($alias, $sortOrder) {
      if (array_key_exists($alias, $this->sortInfos->items)) {
        $this->sortInfos->items[$alias]->sortOrder = $sortOrder;
      } else if (array_key_exists($alias, $this->fieldList->items)) {
        $sortInfo = new bmSortInfo($this->application, $this->sortInfos, null);
        $this->sortInfos->items[$alias] = $sortInfo;
        $sortInfo->alias = $alias;
        $sortInfo->sortOrder = $sortOrder;
      } else {
        $this->application->errorHandler->addError(0, "Undefined field \"'$alias\"!");
      }
    }

    function sortAscending($alias) {
      $this->sortField($alias, soAscending);
    }

    function sortDescending($alias) {
      $this->sortField($alias, soDescending);
    }

    function clearSorting($alias) {
      if (array_key_exists($alias, $this->fieldList->items)) {
        $this->sortInfos->delete($alias);
      } else {
        $this->application->errorHandler->addError(0, "Undefined field \"'$alias\"!");
      }
    }

    function open() {
      $this->active = false;
      if ($this->recordsPerBlock > 0) {
        $query = "select count(*) from `$this->tableName` " . $this->filter->toSQL() . ";";
        #print $query;
        if ($this->recordCount = $this->dataLink->getSingle($query)) {
          if ($this->blockNumber > 0) {
            $this->blockCount = intval($this->recordCount / $this->recordsPerBlock);
            if ($this->recordCount % $this->recordsPerBlock) {
              $this->blockCount++;
            }
            if ($this->blockNumber > $this->blockCount) {
              if ($this->persistentProperties["blockNumber"]->defaultValue > $this->blockCount) {
                $this->blockNumber = $this->blockCount;
                //TODO WARNING HERE
              } else {
                $this->application->errorHandler->addError(0, "Block No$this->blockNumber doesn't exist within the $this->name datasource object!");
                $this->blockNumber = $this->oldPropertyValues["blockNumber"];
              }
            }
            $this->blockStart = ($this->blockNumber - 1) * $this->recordsPerBlock;
            $this->blockEnd = $this->recordsPerBlock;
            #$this->blockEnd = $this->blockNumber * $this->recordsPerBlock;
            #if ($this->blockEnd > $this->recordCount) {
              #$this->blockEnd = $this->recordCount;
            #}
          } else {
            $this->blockStart = 0;
            $this->blockEnd = $this->recordCount;
          }
        }
        $limit = " limit $this->blockStart, $this->blockEnd;";
      } else {
        $limit = "";
      }
      $query = "select " . $this->fieldList->toSQL() . " from `$this->tableName` " . $this->filter->toSQL() . " " . $this->sortInfos->toSQL() . $limit;
      #print $query . "<br />";
      if ($this->cursor = $this->dataLink->query($query)) {
        $this->active = true;
      }
      return $this->active;
    }

    function insertRows() {
      $keys = array_keys($this->newValues->insert);
      $query = "insert into " . $this->tableName . " ";
      $columnNamesString = "";
      $valueString = "";
      $buildColumnNames = true;
      $componentString = $this->getComponentString();
      $uploadedFiles = $this->application->cgi->uploadedFiles;
      foreach ($keys as $key) {
        $valueStringPart = "";
        foreach ($this->fieldList->items as $fieldInfo) {
          $alias = $fieldInfo->alias;
          if ($fieldInfo->acceptFiles) {
            $file = $uploadedFiles->getFileByFieldKey($componentString . ".newValues." . $alias . ".file", $key);
            if (!is_null($file)) {
              $uploadedFiles->serializeFile($file->fileName);
              $values = &$this->newValues->$alias;
              $values[$key] = $file->fileName;
            }
          }
          if (isset($this->newValues->$alias)) {
            if ($buildColumnNames) {
              $columnNamesString .= $this->tableName . "." . $fieldInfo->propertyName . ", ";
            }
            $values = &$this->newValues->$alias;
            $valueStringPart .=  "\"" . $this->application->validator->formatInput($values[$key]) . "\", ";
          }
        }
        if ($buildColumnNames) {
          $columnNamesString = "(" . substr($columnNamesString, 0, -2) . ")";
          $buildColumnNames = false;
        }
        $valueStringPart = "(" . substr($valueStringPart, 0, -2) . "), ";
        $valueString .= $valueStringPart;
      }
      $query .= $columnNamesString . " values " . substr($valueString, 0, -2);
      #print $query . "<br/>";
      $this->dataLink->query($query);
    }

    function internalUpdateRows() {

    }

    function internalDeleteRows($recordIds) {
      foreach ($recordIds as $recordId) {
        $error = false;
        if (!$this->application->validator->validateNumber($recordId)) {
          $error = true;
        }
      }
      if (!$error) {
        if ($this->onBeforeDeleteRow) {
          $beforeDeleteRow = $this->onBeforeDeleteRow;
          foreach ($recordIds as $recordId) {
            $beforeDeleteRow($recordId);
          }
        }
        $query = "delete from " . $this->tableName . " where " . $this->keyFieldName . " in (" . join(", ", $recordIds) . ");";
        #print $query . "<br/>";
        $this->dataLink->query($query);
      }
      if ($this->onAfterDeleteRow) {
        $afterDeleteRow = $this->onAfterDeleteRow;
        $afterDeleteRow($this, $recordIds);
      }
    }

    function deleteRecord($recordid) {
      $sql->query("delete from " . $this->tableList->mainTableName . " where " . $this->fieldList->fields[$this->fieldList->keyFieldIndex]->toString() . " in (" . join(", ", $recordIds) . ");");
      $deleteRecord = $this->onDeleteRecord;
      if ($deleteRecord) {
        $deleteRecord($recordid);
      }
    }

    function addVariable($name, $value) {
      $this->variables[$name] = $value;
    }

    function getNodes() {
      $this->internalQuery = "select " . $this->fieldList . " from " . $this->tableList . $this->filter . " " . $this->groupBy . " ";
      if ($this->orderBy) {
        $this->internalQuery .= " " . $this->orderBy;
      }
      $this->internalQuery .= " " . $this->limit;
      #print $this->internalQuery;
      $result = ($this->cursor = $this->sql->query($this->internalQuery));
      return $result;
    }

    function next() {
      if ($this->cursor) {
        return ($this->current = mysql_fetch_array($this->cursor));
      } else {
        //TODO: ERROR HERE
        return false;
      }
    }

  }

?>
