<?php

  define('ncDigits', 1);
  define('ncUpperCaseEnUs', 2);
  define('ncLowerCaseEnUs', 3);
  define('ncUpperCaseRuRuFull', 4);
  define('ncLowerCaseRuRuFull', 5);
  define('ncUpperCaseRuRuShort', 6);
  define('ncLowerCaseRuRuShort', 7);
  define('cDigits', '0123456789');
  define('cUpperCaseEnUs', 'ABCDEFGHIJKLMNOPQRSTVUWXYZ');
  define('cLowerCaseEnUs', 'abcdefghijklmnopqrstvuwxyz');
  define('cUpperCaseRuRuFull', 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ');
  define('cLowerCaseRuRuFull', 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя');
  define('cUpperCaseRuRuShort', 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ');
  define('cLowerCaseRuRuShort', 'абвгдежзиклмнопрстуфхцчшщэюя');

  class bmStartsWithNavigator extends bmCustomMenu {
    
    private $markersString = '';
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('action', pbValue); 
      $this->serializeProperty('markers', pbSet, array(ncDigits, ncUpperCaseEnUs));
      $this->initializeMarkers();
      $length = mb_strlen($this->markersString);
      
      for ($i = 0; $i < $length; ++$i) {
        $item = $this->menuItems->add(mb_substr($this->markersString,$i, 1));
      }

    }
    
    public function initializeMarkers() {
      $markers = $this->markers;
      foreach ($markers as $marker) {
        
        switch ($marker) {
          case ncDigits: 
            $this->markersString .= cDigits;
          break;
          case ncUpperCaseEnUs: 
            $this->markersString .= cUpperCaseEnUs;
          break;
          case ncLowerCaseEnUs: 
            $this->markersString .= cLowerCaseEnUs;
          break;
          case ncUpperCaseRuRuFull: 
            $this->markersString .= cUpperCaseRuRuFull;
          break;
          case ncLowerCaseRuRuFull: 
            $this->markersString .= cLowerCaseRuRuFull;
          break;
          case ncUpperCaseRuRuShort: 
            $this->markersString .= cUpperCaseRuRuShort;
          break;
          case ncLowerCaseRuRuShort: 
            $this->markersString .= cLowerCaseRuRuShort;
          break;
        }
      }
    }
    
    public function setter($propertyName, $value) {
      switch ($propertyName) {
        case 'markers':
          $this->initializeMarkers();
        default: 
          parent::setter($propertyName, $value);
        break;
      }
    }

  }

?>
