<?php
  
  class bmDataObject extends bmCollectionItem {
  
    public $shouldSerialize = false;
    public $temporary = true;
    private $dataProperties = array();
    
    public function getter($propertyName) {
      if (!array_key_exists($propertyName, $this->dataProperties)) {
        $this->dataProperties[$propertyName] = null;
      }
      return $this->dataProperties[$propertyName];
    }
    
    public function setter($propertyName, $value) {
      $this->dataProperties[$propertyName] = $value;
    }
    
    public function hasFlag($value) {
      return (($this->mask & $value) > 0);
    }
    
    public function setFlag($value) {
      $this->mask = $this->mask | $value;
    }
    
    public function removeFlag($value) {
      $this->mask = $this->mask & ~$value;
    }
    
  }
  
?>
