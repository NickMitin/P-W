<?php

  class bmHTMLMenuPainter extends bmHTMLStandaloneControlPainter {
    
    private $counter = 0;

    function drawControl($control) {
      
      if ($control->styles->firstActiveMenuItem == 'default') {
        $control->styles->firstActiveMenuItem = $control->styles->activeMenuItem; 
      }
      
      if ($control->styles->lastActiveMenuItem == 'default') {
        $control->styles->lastActiveMenuItem = $control->styles->activeMenuItem; 
      }
      
      if ($control->styles->firstMenuItem == 'default') {
        $control->styles->firstMenuItem = $control->styles->menuItem; 
      }
      
      if ($control->styles->lastMenuItem == 'default') {
        $control->styles->lastMenuItem = $control->styles->menuItem; 
      }
      
      $result = $this->drawItems($control, $control->menuItems);
      return $result;
    }
    
    function drawVertical($control) {
      
    }

    function drawItems($control, $items) {
      
      if ($items->styles->firstActiveMenuItem == 'default') {
        $items->styles->firstActiveMenuItem = $items->styles->activeMenuItem; 
      }
      
      if ($items->styles->lastActiveMenuItem == 'default') {
        $items->styles->lastActiveMenuItem = $items->styles->activeMenuItem; 
      }
      
      if ($items->styles->firstMenuItem == 'default') {
        $items->styles->firstMenuItem = $items->styles->menuItem; 
      }
      
      if ($items->styles->lastMenuItem == 'default') {
        $items->styles->lastMenuItem = $items->styles->menuItem; 
      }
      
      $separatorStyle = ($items->inheritStyles) ? $control->styles->separator : $items->styles->separator;
      $menuItemStyle = ($items->inheritStyles) ? $control->styles->menuItem : $items->styles->menuItem;
      $activeMenuItemStyle = ($items->inheritStyles) ? $control->styles->activeMenuItem : $items->styles->activeMenuItem;
      $actionLinkStyle = ($items->inheritStyles) ? $control->styles->actionLink : $items->styles->actionLink;
      $lastMenuItemStyle = ($items->inheritStyles) ? $control->styles->lastMenuItem : $items->styles->lastMenuItem;
      $lastActiveMenuItemStyle = ($items->inheritStyles) ? $control->styles->lastActiveMenuItem : $items->styles->lastActiveMenuItem;
      $firstMenuItemStyle = ($items->inheritStyles) ? $control->styles->firstMenuItem : $items->styles->firstMenuItem;
      $firstActiveMenuItemStyle = ($items->inheritStyles) ? $control->styles->firstActiveMenuItem : $items->styles->firstActiveMenuItem;
      
      $i = 0;
      $validator = $this->application->validator;
      $alignment = ($items->orientation == mioHorizontal) ? $items->alignment . ' ' : '';
      $result = '<ul class="bmMenu" id="' . $control->name . 'Items' . $this->counter . '">';
      $separator = ($items->separator == '') ? $control->separator : $items->separator;
      $separator = ($separator == '') ? '' : '<li class="' . $alignment . $separatorStyle . '">' . $separator . '</li>';
      foreach ($items->items as $item) {
        if ($item->visible) {
          $hasChildren = ($item->menuItems->count > 0) ? ' hasChildren' : '';
          $isActiveItem = $item->caption == $control->activeItem;
          if ($alignment == '') {
            $lastItem = ($i == $items->count - 1);
          } else {
            switch ($items->alignment) {
              case miaLeft:
                $lastItem = ($i == $items->count - 1);
              break;
              case miaRight:
                $lastItem = ($i == 0);
              break;
            }
          }
          if (($style = $control->callEventHandler($control->onGetMenuItemStyle, array('item' => $item))) === false) {
            if ($i == 0) {
              $style = ($isActiveItem) ? $firstActiveMenuItemStyle : $firstMenuItemStyle;
            } elseif ($lastItem) {
              $style = ($isActiveItem) ? $lastActiveMenuItemStyle : $lastMenuItemStyle;
            } else {
              $style = ($isActiveItem) ? $activeMenuItemStyle : $menuItemStyle;
            }
          }
          $id = $control->name . 'Item' . $this->counter;
          $i++;
          $this->counter++;
          $itemString = '<li id="' . $id . '" class="bmMenuItem ' . $alignment . $hasChildren . ' ' . $style . '">';
          $linkOverride = false;
          if (($customDraw = $control->callEventHandler($control->onCustomDrawMenuItem, array('item' => $item))) === false) {
            if ($item->action != null) {
              if ($this->application->actions->exists($item->action)) {
                $query = $this->application->actions->items[$item->action]->toHTML();
              }  else {
                $linkOverride = true;
                $query = $item->action;
              }
            } elseif ($control->action) {
              $linkOverride = true; 
              $query = $this->application->path . $control->action . $validator->formatXMLValue($item->caption);
            } else {
              $query = 'application.' . $control->ownerForm->name . '.' . $control->name . '.activeItem=' . $validator->formatXMLValue($item->caption);
            }
            if (($customDraw = $control->callEventHandler($control->onCustomDrawItemCaption, array("item" => $item))) === false) {
              $caption = ($control->localeDependent) ? constant($item->caption) : $item->caption;
              $title = $caption;
            } else {
              $title = $customDraw;
            }
            
            $hint = ($item->hint == '') ? $item->caption : $item->hint;
            
            if ($isActiveItem) {
              if ($control->activeItemBehaviour == aibLink) {
                $itemString .= $this->drawLink($query, $hint, $title, $actionLinkStyle, $linkOverride, $control->IE7);
              } else {
                $itemString .= $item->caption;
              }
            } else {
              $itemString .= $this->drawLink($query, $item->caption, $title, $actionLinkStyle, $linkOverride, $control->IE7);
            }
          } else {
            $itemString .= $customDraw;
          }
          if ($hasChildren <> '') {
            $itemString .= $this->drawItems($control, $item->menuItems);
          }
          $itemString .= '</li>';
          if ($alignment == '') {
            $result .= $itemString;
            if (!$lastItem) {
              $result .= $separator;
            }
          } else {
            switch ($items->alignment) {
              case miaLeft:
                $result .= $itemString;
                if (!$lastItem) {
                  $result .= $separator;
                }
              break;
              case miaRight:
                if (!$lastItem) {
                  $result = $separator + $result;
                }
                $result = $itemString + $result;
              break;
            }
          }
        }
      }
      $result .= '</ul>';
      return $result;
    }

  }

?>
