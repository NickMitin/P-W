<?php

  class bmClassProperty extends bmCollectionItem {

    public $propertyName = "";
    public $value = "";
    public $inplaceEditClass = "bmEdit";
    public $inplaceEdit = null;
    public $collectionClass = "bmClassProperties";

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("value", pbValue);
      $this->serializeProperty("inplaceEditClass", pbValue);
      
    }

    #function createOwnedObjects() {
      //TODO COO;
      #$this->inplaceEdit = $this->createOwnedObject($this->inplaceEditClass, array("name" => "inplaceEdit"));
    #}

  }

?>