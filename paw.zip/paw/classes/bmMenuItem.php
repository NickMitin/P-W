<?php

  class bmMenuItem extends bmCollectionItem {

    public $menuItems = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('caption', pbValue, '');
      $this->serializeProperty('action', pbValue);
      $this->serializeProperty('data', pbValue);
      $this->serializeProperty('hint', pbValue, '');
      $this->serializeProperty('visible', pbValue, true);
      $this->menuItems = $this->createOwnedObject('bmMenuItems', array('name' => 'menuItems'));

    }

  }

?>
