<?php
  
  class bmFileSystem extends bmPersistentObject {
    
    private $files = null;
    private $fileProperties = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->files = $this->createOwnedObject("bmDataObjects", array("name" => "sessions"));
      $this->sessions->objectName = "mod_core_files";
      $this->fileProperties = $this->createOwnedObject("bmDataObjectProperties", array("name" => "fileProperties"));
      $this->fileProperties->add("fileName");
      $this->fileProperties->add("realName");
      $this->fileProperties->add("mimeType");
      $this->fileProperties->add("size");
    }
    
    /*public function deleteDirectory($path) {
      if (file_exists($path)) {
        if ($rootEntry = dir($path)) {
          $path = preg_replace("/^(.*?)\/?$/", "\\1/", $path);
          while (($entry = $rootEntry->read()) !== false) {
            $entryPath = $path . $entry;
            if (is_dir($entryPath) && (!preg_match("/^\.{1,2}$/", $entry))) {
              deleteDirectory($entryPath);
            } elseif (is_file($entryPath)) {
              unlink($entryPath);
            }
          }
          $rootEntry->close();
          rmdir($path);
        }
      }
    }*/
    
    public function deleteFile($fileName) {
      $link = $this->application->mainLink;
      $link->tryDeleteObject($this->files, $fileName);
      unlink("./files/" . $fileName);
    }
    
    public function saveToFile($fileName, $autoCreate, $contents, $mimeType = "text/plain") {
      $link = $this->application->mainLink;
      $internalName = $fileName;
      do {
        $fileName = md5($internalName);
        $internalName .= "_";
      } while (!$this->fileExists($fileName));
      $link->newObject($this->files, $fileName, $this->fileProperties);
      file_put_contents("./files/" . $fileName, $contents);
      return $internalName;
    }
    
    public function loadFromFile($fileName) {
      $link = $this->application->mainLink;
      if (($file = $link->loadObject($this->files, md5($fileName), $this->fileProperties)) !== false) {
        return file_get_contents("./files/" . $file->fileName);
      } else {
        return false;
      }
    }
    
    public function serailzeFile($fileName) {
      $link = $this->application->mainLink;
      $originalName = $fileName; 
      $internalName = basename($fileName);
      do {
        $fileName = md5($internalName);
        $internalName .= "_";
      } while (!$this->fileExists($fileName));
      $link->newObject($this->files, $fileName, $this->fileProperties);
      copy($originalName, "./files/" . $fileName);
      return $fileName;      
    }
    
    public function getFileName($fileName) {
      return "./files/" . md5($fileName);
    }    
    
    public function fileExists($fileName) {
      return file_exists("./files/" . md5($fileName));
    }
    
  }
  
?>