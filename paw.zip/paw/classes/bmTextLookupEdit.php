<?php

  class bmTextLookupEdit extends bmCustomTextLookupEdit {
    
    public $hasClientMirror = 1;
  
  }

?>
