<?php

  class bmCustomComboBoxEdit extends bmCustomOptionEdit {

  }

?>
