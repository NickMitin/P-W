<?php
  
  class bmInplaceDateEditStyles extends bmCustomControlStyles {
    
  }
  
?>
