<?php
  
  class bmHTMLLookupEditPainter extends bmHTMLStandaloneControlPainter {
    
    function drawControl($control) {         
      $result = '<select id="' . $control->name . 'Edit" class="' . $control->styles->default . '" style="width: 100%;" name="' . $control->getComponentString() . '.value">';
      foreach ($control->options->items as $item) {
        $result .= '<option value="' . $item->value . '"' . ($item->selected ? ' selected="selected"' : '') . '>' . $item->caption . '</option>';
      }
      $result .= '</select>';
      return $result;
      
    }
    
  }
  
?>
