<?php
  
  class bmFrame extends bmCustomFrame {
    
    public $hasClientMirror = 1;

  }
  
?>
