<?php

  class bmDataTableClientValues extends bmWebComponent {

    function customHandleRequest($elementName, $value) {

      $this->$elementName = $value;

      return true;

    }

  }

?>