<?php

  class bmHTMLFormPainter extends bmHTMLCustomControlPainter {

    function draw() {
      header("content-type: " . $this->control->contentType . "; charset=" . $this->control->encoding, true);
      $result = "<?xml version=\"1.0\" encoding=\"" . $this->control->encoding . "\"?>\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\">\n<head>\n<meta http-equiv=\"content-type\" content=\"" . $this->control->contentType . "; charset=" . $this->control->encoding . "\"/>\n";
      $result .= $this->control->styleManager->toCSS();
      $result .= $this->control->clientScripts->toHTML();
      $result .= $this->application->errorHandler->toHTML();
      $result .= "<title>" . $this->control->title . "</title>\n</head>\n<body style=\"padding: 0; margin: 0;\">\n";
      foreach ($this->control->components as $component) {
        if ($component instanceof bmWebCustomControl) {
          $result .= $component->painter->draw();
        }
        unset($component);
      }
      $result .= "</body>\n</html>";
      return $result;
    }

  }


?>