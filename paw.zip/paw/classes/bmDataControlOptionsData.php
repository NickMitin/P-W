<?php

  class bmDataControlOptionsData extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("toggleMode", pbValue, true);

    }

  }

?>