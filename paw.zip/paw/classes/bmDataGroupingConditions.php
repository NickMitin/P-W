<?php

  class bmDataGroupingConditions extends bmCollection {

    public $collectionItemClass = "bmDataGroupingCondition";
    public $keyPropertyName = "propertyName";

  }

?>