<?php

  class bmMenu extends bmCustomMenu {
    
    public $hasClientMirror = 1;

  }

?>
