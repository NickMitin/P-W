<?php

  class bmLabelStyles extends bmCustomControlStyles {

  }

?>