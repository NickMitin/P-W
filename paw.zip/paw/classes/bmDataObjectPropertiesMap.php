<?php
  
  class bmDataObjectPropertiesMap extends bmCollection {
    
    public $keyPropertyName = "propertyName";
    public $collectionItemClass = "bmDataObjectPropertyMap";
    
  }
  
?>