<?php
  
  class bmCustomImage extends bmCustomControl {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("picture", pbValue, "");
      $this->serializeProperty("alternativeText", pbValue, "");
      $this->serializeProperty("action", pbValue);

    }
    
  }
  
?>
