<?php

  class bmCompiler extends bmObject {
  
    private function makeFormFile($extension, $formName) {
      $buffer = file_get_contents(engineRoot . 'templates/bm%formName%.' . $extension);
      $buffer = preg_replace('/%formName%/s', $formName, $buffer);
      file_put_contents('./forms/bm' . $formName . "." . $extension, $buffer);
    }
    
    private function deleteFormFile($extension, $formName) {
      $fileName = './forms/bm' . $formName . '.' . $extension;
      if (file_exists($fileName)) {
        unlink($fileName);
      }
    }
    
    public function deleteForm($formName) {
      $this->deleteFormFile('xml', $formName);  
      $this->deleteFormFile('php', $formName);
      $this->deleteFormFile('css', $formName);
      $this->deleteFormFile('js', $formName);
    }
    
    public function createForm($formName, $showMessages = true) {
      if ($this->application->mode == amDebug) {
        if (!preg_match('/^f[A-Za-z0-9]+$/', $formName)) {  
          if ($showMessages) {
            $this->application->errorHandler->addError(0, 'Form name must begin with the letter \'f\' and contain only letters and digits.');
          }
          return false;
        }
        if ($this->application->formInfo->loadObject($formName) !== null) {
          if ($showMessages) {
            $this->application->errorHandler->addError(0, 'The "' . $formName . '" form alerady exists!');
          }
          return false;
        }
        
        $this->makeFormFile('xml', $formName);
        $this->makeFormFile('php', $formName);
        $this->makeFormFile('css', $formName);
        
        
        $this->application->formInfo->newObject($formName);
        $this->application->formInfo->saveObject($formName);
        
        $this->buildJSFile($formName);
        
        if ($showMessages) {
          $this->application->errorHandler->addError(0, 'Form "' . $formName . '" sucessfully created.');
        }
        
        return true;
        
      } else {
        if ($showMessages) {
          $this->application->errorHandler->addError(0, 'The "createForm" operation can only be done in debug mode!');
        }
        return false;
      }
    }
    
    public function compileForm($formName) {
      if ($this->application->mode == amDebug) {
        $this->$formName->shouldCompile = true;
      } else {
        $this->application->errorHandler->addError(0, 'The "compileForm" operation can only be done in debug mode!');
      }
    }
    
    private function processComponent($component, &$buffer) {
      if ($component->hasClientMirror) {
        $name = $component->name;
        $formName = $component->ownerForm->name;
        $ownerString = $component->owner->getComponentString();
        $className = get_class($component);
        $buffer[] = '  ' . $ownerString . '.' . $name . ' = new ' . $className . '(application, ' . $ownerString . ", {'name': '" . $name . "'});";
        $buffer[] = '  application.' . $formName . '.' . $name . ' = ' . $ownerString . '.' . $name . ';';
        if (($node = $component->clientEvents->fNode) != null) {
          $xPath = new DOMXPath($component->map);
          $nodes = $xPath->query('property', $node);
          foreach ($nodes as $child) {              
            $eventName = (string)$child->getAttribute('name');
            $eventHandler = (string)$child->nodeValue;
            if (strpos($eventHandler, '.') === false) {
              $eventHandler = $formName . '.' . $eventHandler;
            }
            $buffer[] = '  application.' . $formName . '.' . $name . ".attachEvent('" . $eventName . "', application." . $eventHandler . ');';
          }
        }
      }
      foreach ($component->components as $child) {
        $this->processComponent($child, $buffer);
      }
    }
    
    public function buildJSFile($formName) {
      if ($this->application->mode == amDebug) {                                              
        $jsFile = './forms/bm' . $formName . '.js';
        $implementation = '';
        if (file_exists($jsFile)) {
          $content = preg_split('/\/\* IMPLEMENTATION (BEGIN|END) \(DO NOT REMOVE THIS LINE\) \*\//s', file_get_contents($jsFile));
          $implementation = trim($content[1]);
        }
        $form = $this->application->$formName;
        $interface = array();
        if ($formName != 'fTemplateContainer') {
          $this->processComponent($form, $interface);  
        }
        
        $form = trim(preg_replace('/\.' . $formName . '\./', '.', array_shift($interface)));
        array_shift($interface);
        
        $interface = join("\n", $interface);
        
        preg_match_all('/[.\w]+.attachEvent\([^,]+, application\.' . $formName . '\.(\w+)\);/s', $interface, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
          $testString = '/bm' .$formName . '.prototype.' . $match[1] . '\s*=\s*function\s*\(/is';
          if (!preg_match($testString, $implementation)) {
            $implementation .= "\n\nbm" .$formName . '.prototype.' . $match[1] . " = function(event) {\n\n}";
          }
        }
        $implementation = trim($implementation);
        
        $content = '/* INTERFACE BEGIN (GENERATED AUTOMATICALLY, DO NOT MODIFY) */

function bm' . $formName . '(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bm' . $formName . '.inherit(bmHTMLForm);
  
bm' . $formName . '.prototype.create = function(application, owner, parameters) {
  bmHTMLForm.prototype.create.call(this, application, owner, parameters); 
}

bm' . $formName . '.prototype.load = function(event) {
  
  application.' . $formName . '.initialize();
' . $interface . '
  if (application.fTemplateContainer.genericInitialize) {
    application.fTemplateContainer.genericInitialize();
  }
}

/* INTERFACE END (GENERATED AUTOMATICALLY, DO NOT MODIFY) */

/* IMPLEMENTATION BEGIN (DO NOT REMOVE THIS LINE) */

' . $implementation . '

/* IMPLEMENTATION END (DO NOT REMOVE THIS LINE) */

' . $form;
        
        file_put_contents($jsFile, $content);
      } else {
        $this->application->errorHandler->addError(0, 'The "buildJSFile" operation can only be done in debug mode!');
      }
    }
    
  }
  
?>
