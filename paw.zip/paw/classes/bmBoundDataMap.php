<?php
  
  class bmBoundDataMap extends bmPersistentObject {
    
    public $dataObjectMaps = null;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("objectName", pbValue);
      $this->serializeProperty("linkName", pbValue);
      $this->dataObjectMaps = $this->createOwnedObject("bmDataObjectMaps", array("name" => "dataObjectMaps"));
    }
    
  }
  
?>