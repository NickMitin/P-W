<?php

  require_once('./editor_files/config.php');
  require_once('./editor_files/editor_class.php');

  class bmCustomRichEdit extends bmCustomEdit {
    
    public $content = null;
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('dataAware', pbValue, false);
      $this->publishProperty('contentName', pbValue);
      $this->serializeProperty('boundData', pbReference);
      $this->publishProperty('mode', pbValue, emView);
      $this->publishMethod('save');
      $this->load(); 
    }
    
    public function modeSetter($value) {
      if ($value == emView || $value == emEdit) {
        $this->mode = $value;
        return true;
      }
      return false;
    }
    
    public function contentNameSetter($value) {
      if ($value != '') {
        $this->contentName = $value;
        $this->load();
        return true;
      }
    }
    
    public function load() {
      if ($this->dataAware) {
        $this->boundData->filter->conditions->items['locale']->value = $this->application->locale;
        $this->boundData->filter->conditions->items['contentName']->value = $this->contentName;
        $this->boundData->loadObjects();
        $this->value = '';
        if ($this->boundData->dataObjects->count == 0) {
          if ($this->mode == emEdit) {
            $this->content = $this->boundData->newObject();
            $this->content->locale = $this->application->locale;
            $this->content->contentName = $this->contentName;
          }
        } else {
          $this->content = current($this->boundData->dataObjects->items);
          
          $this->value = $this->content->content;
        }
      }
    }
    
    public function save() {
      $this->content->content = $this->value;
      $this->boundData->saveObject($this->content->id);
      $this->mode = emView;
    }
    
  }
  
?>