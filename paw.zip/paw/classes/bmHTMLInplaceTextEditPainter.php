<?php

  class bmHTMLInplaceTextEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    public function draw($control, $dataControl, $dataCollection, $style) {
      $result = '';
      if ($control->owner->readOnly) {
        $result = $control->value;
      } else {
        switch ($dataControl->mode) {
          case dcmView:
            $result = $control->value;
          break;
          case dcmEdit:
            $result = '<input type="text" style="width: 100%;" class="' . $style . '" name="' . $dataControl->boundData->getComponentString() . '.' . $dataCollection . '.' . $control->owner->propertyName . '[' . $control->keyValue . ']" value="' . $this->application->validator->formatXMLValue($control->value) . '"/>';
          break;
        }
      }
      return $result; 
    }

  }

?>
