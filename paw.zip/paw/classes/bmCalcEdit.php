<?php

  class bmCalcEdit extends bmCustomCalcEdit {
    
    public $hasClientMirror = 1;

  }

?>
