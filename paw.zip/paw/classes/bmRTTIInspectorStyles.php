<?php
  
  class bmRTTIInspectorStyles extends bmCustomControlStyles {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("oddRow", pbValue);
      $this->serializeProperty("evenRow", pbValue);
      $this->serializeProperty("footer", pbValue);
      $this->serializeProperty("newRow", pbValue);
      $this->serializeProperty("columnHeader", pbValue);

    }    

  }
  
?>
