<?php

  class bmMenuStyles extends bmCustomControlStyles {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('separator', pbValue, 'default');
      $this->serializeProperty('menuItem', pbValue, 'default');
      $this->serializeProperty('activeMenuItem', pbValue, 'default');
      $this->serializeProperty('actionLink', pbValue, 'default');
      $this->serializeProperty('actionLinkHovered', pbValue, 'default');
      $this->serializeProperty('lastMenuItem', pbValue, 'default');
      $this->serializeProperty('lastActiveMenuItem', pbValue, 'default');
      $this->serializeProperty('firstMenuItem', pbValue, 'default');
      $this->serializeProperty('firstActiveMenuItem', pbValue, 'default');

    }

  }

?>
