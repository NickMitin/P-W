<?php
  
  class bmHTMLDataPanelPainter extends bmHTMLStandaloneControlPainter {
  
    function drawControl($control) {  
      $result = '<form style="margin: 0; padding: 0;" id="' .$control->name . 'Panel" enctype="multipart/form-data" method="' . $control->sendMethod . '" action="' . $this->application->path . 'main.php">';
      foreach ($control->components as $component) {
        if ($component instanceof bmCustomControl) {
          $result .= $component->draw();
        }
        unset($component);
      }
      $result .= '<div>';
      foreach ($control->parameters->items as $parameter) {
        $result .= '<input type="hidden" name="' . $parameter->parameterName . '" value="' . $parameter->value . '"/>';
      }
      $result .= '</div></form>';
      return $result;
    }
    
  }
  
?>
