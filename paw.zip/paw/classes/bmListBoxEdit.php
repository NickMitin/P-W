<?php

  class bmListBoxEdit extends bmCustomListBox {
    
    public $hasClientMirror = 1;
    
  }
  
?>
