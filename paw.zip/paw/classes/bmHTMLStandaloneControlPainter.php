<?php
  
  abstract class bmHTMLStandaloneControlPainter extends bmHTMLCustomControlPainter {
    
    private function createCorner($control, $cornerType, $size) {
      if (preg_match('/#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})/i', $control->backgroundColor, $matches)) {
        list(, $bcRed, $bcGreen, $bcBlue) = $matches;
      }
      if (preg_match('/#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})/i', $control->transparentColor, $matches)) {
        list(, $tcRed, $tcGreen, $tcBlue) = $matches;
      }
      $initialWidth = $initialHeight = $size;
      $width = $initialWidth * 2;
      $height = $initialHeight * 2;
      
      $image = imagecreatetruecolor($width, $height);
      $backgroundColor = imagecolorallocate($image, hexdec($bcRed), hexdec($bcGreen), hexdec($bcBlue));
      $transparentColor = imagecolorallocate($image, hexdec($tcRed), hexdec($tcGreen), hexdec($tcBlue));
      
      switch($cornerType) {
        case 'tl':
          $x = $width;
          $y = $height;
          $angleStart = 180;
          $angleEnd = 270;
        break;
        case 'tr':
          $x = -2;
          $y = $height;
          $angleStart = 270;
          $angleEnd = 360;
        break;
        case 'bl':
          $x = $width;
          $y = -1;
          $angleStart = 90;
          $angleEnd = 180;
        break;
        case 'br':
          $x = -2;
          $y = -1 ;
          $angleStart = 0;
          $angleEnd = 90;
        break;
      }  
      imagefill($image, 0, 0, $transparentColor);
      imagefilledarc($image, $x, $y, $width * 2, $height * 2, $angleStart, $angleEnd, $backgroundColor, IMG_ARC_PIE);
      
      $result = imagecreatetruecolor($initialWidth, $initialHeight);
      imagecopyresampled($result, $image, 0, 0, 0, 0, $initialWidth, $initialHeight, $width - 1, $height - 1);
      
      imagepng($result, './userResources/' . $control->resourceName . '/' . $cornerType . '.png');
      imagedestroy($image);
      imagedestroy($result);
    }
    
    private function boundsToString($control) {
      $result = 'position: ' . $control->position . '; z-index: ' . $control->creationOrder . ';';
      $result .= ($control->left == 'auto' ? '' : ' left: ' . $control->left . ';');
      $result .= ($control->top == 'auto' ? '' : ' top: ' . $control->top . ';');
      $result .= ($control->right == 'auto' ? '' : ' right: ' . $control->right . ';');
      $result .= ($control->bottom == 'auto' ? '' : ' bottom: ' . $control->bottom . ';');
      $result .= ($control->width == 'auto' ? '' : ' width: ' . $control->width . ';');
      $result .= ($control->height == 'auto' ? '' : ' height: ' . $control->height . ';');
      return $result;
    }
    
    public function draw($control) { 
      
      $visible = '';
      if (!$control->visible) {
        $visible = ' display: none;';
      }
      
      $result = '';
      
      $hint = ($control->hint != '') ? ' title="' . $control->hint . '"' : '';
      
      $result .= '<div' . $hint . ' id="' . $control->name . '" style="' . $this->boundsToString($control) . $visible . " overflow: " . $control->childrenOverflow . ";\" class=\"" . $control->styles->container . "\">";
      $result .= '<div style="display: none;" id="' . $control->name . 'Initialization">' . $control->getClientPropertyValues() . '</div>';
      
      $borderRadius = intval($control->borderRadius);
    
      if ($borderRadius > 0) {
        $resourcePath = './userResources/' . $control->resourceName . '/';
        $redraw = $control->completeRedraw;
        if (!file_exists($resourcePath)) {
          mkdir($resourcePath, 0755, true);
          $redraw = (!file_exists($resourcePath . 'tl.png')) || $redraw;
        }
        if ($redraw) {
          $this->createCorner($control, 'tl', $borderRadius);  
          $this->createCorner($control, 'tr', $borderRadius);
          $this->createCorner($control, 'bl', $borderRadius);
          $this->createCorner($control, 'br', $borderRadius);
        }
        
        $result .= (($control->roundBorders & rbTopLeft) > 0) ? '<div style="width: 100%; height: 100%; background: url(' . $this->application->path . 'userResources/' . $control->resourceName . '/tl.png) top left no-repeat;">' : '';
        $result .= (($control->roundBorders & rbTopRight) > 0) ? '<div style="width: 100%; height: 100%; background: url(' . $this->application->path . 'userResources/' . $control->resourceName . '/tr.png) top right no-repeat;">' : '';
        $result .= (($control->roundBorders & rbBottomLeft) > 0) ? '<div style="width: 100%; height: 100%; background: url(' . $this->application->path . 'userResources/' . $control->resourceName . '/bl.png) bottom left no-repeat;">' : '';
        $result .= (($control->roundBorders & rbBottomRight) > 0) ? '<div style="width: 100%; height: 100%; background: url(' . $this->application->path . 'userResources/' . $control->resourceName . '/br.png) bottom right no-repeat;">' : '';
        $result .= '<div class="' . $control->styles->content . '">';
      }
      
      $result .= $this->drawControl($control);
      
      
      if ($borderRadius > 0) {
        $result .= '</div>';
        $result .= (($control->roundBorders & rbTopLeft) > 0) ? '</div>' : '';
        $result .= (($control->roundBorders & rbTopRight) > 0) ? '</div>' : '';
        $result .= (($control->roundBorders & rbBottomLeft) > 0) ? '</div>' : '';
        $result .= (($control->roundBorders & rbBottomRight) > 0) ? '</div>' : '';
      }
      
      $result .= "</div>"; 
      
      return $result;
    }
    
    abstract function drawControl($control);
      
  }

?>
