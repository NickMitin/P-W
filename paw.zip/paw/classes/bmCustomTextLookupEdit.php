<?php

  class bmCustomTextLookupEdit extends bmCustomEdit {
    
    public $keyValue = null;
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('boundData', pbReference);
      $this->serializeProperty('keyPropertyName', pbValue, 'id'); 
      $this->serializeProperty('displayPropertyName', pbValue);
      $this->serializeProperty('onSerializeValue', pbValue);
      $this->serializeProperty('onValueExists', pbValue);
      $this->publishMethod('getDropDownValueList');
      $this->publishMethod('serializeValue');

    }
    
    public function getDropDownValueList() {
      
     
      if (mb_strlen($this->value) > 2) {
        $condition = $this->boundData->filter->conditions->items[$this->displayPropertyName]->value = '%' . $this->value . '%';
        $this->boundData->loadObjects();
      } else {
        $this->boundData->flush();
      }
      
      header('content-type: text/plain; charset=utf-8', true);
      print $this->painter->drawDropDownValueList($this);
      exit();
      
    }
    
    public function serializeValue($realSerialize = true) {
      $condition = $this->boundData->filter->conditions->items[$this->displayPropertyName]->value = $this->value;
      $this->boundData->loadObjects();
      $keyPropertyName = $this->keyPropertyName;
      if ($this->boundData->dataObjects->count == 0) {
        $id = $this->callEventHandler($this->onGetNewId, null);
        if ($this->keyPropertyName == $this->displayPropertyName) {
          $id = $this->value;
        }
        if ($realSerialize) {
          $object = $this->boundData->newObject($id);
          $propertyName = $this->displayPropertyName;
          $object->$propertyName = $this->value;
        }
        $this->callEventHandler($this->onSerializeValue, array('dataObject' => $object));
        if ($realSerialize) {
          $this->boundData->saveObject($object->id);
        }
        $this->keyValue = $object->$keyPropertyName;
      } else {
        $object = current($this->boundData->dataObjects->items);
        $this->callEventHandler($this->onValueExists, array('dataObject' => $object));
        $this->keyValue = $object->$keyPropertyName;
      }
    }

  }

?>
