<?php

  define('mcEqual', '=');
  define('mcNotEqual', '<>');

  class bmDataFilterMaskCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('mask', pbValue, 1);
      $this->serializeProperty('flag', pbValue, 0);
      $this->serializeProperty('operation', pbValue, mcNotEqual);

    }

  }

?>
