<?php
  
  class bmRichEditStyles extends bmCustomControlStyles {
    
  }
  
?>