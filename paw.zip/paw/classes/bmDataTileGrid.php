<?php

  class bmDataTileGrid extends bmCustomDataTileGrid {
    
    public $hasClientMirror = 1;

  }

?>
