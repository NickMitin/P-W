<?php

  define('fdAuto', 1);
  define('fdWidth', 2);
  define('fdHeight', 3);

  class bmFileStorage extends bmComponent {
    
    public $uploadedFiles = null;
    public $boundData = null;
    
    function constructor($application, $owner, $parameters) {
      

      parent::constructor($application, $owner, $parameters);
      $this->uploadedFiles = $this->createOwnedObject("bmUploadedFiles", array("name" => "uploadedFiles"));
      if (count($_FILES) > 0) {
        $this->getUploadedFiles();
      }
      
      $this->boundData = $this->createOwnedObject("bmDataSource", array("name" => "boundData"));
      $this->boundData->boundDataMap->objectName = "file";
      $object = $this->boundData->boundDataMap->dataObjectMaps->add("file");
      $propertyMap = $object->propertiesMap->add("realName");
      $propertyMap->fieldName = "realName";
      $propertyMap = $object->propertiesMap->add("mimeType");
      $propertyMap->fieldName = "mimeType";
      $propertyMap = $object->propertiesMap->add("size");
      $propertyMap->fieldName = "size";
      $propertyMap = $object->propertiesMap->add("accessCount");
      $propertyMap->fieldName = "accessCount";
      $propertyMap = $object->propertiesMap->add("preview");
      $propertyMap->fieldName = "preview";
      $propertyMap = $object->propertiesMap->add("keywords");
      $propertyMap->fieldName = "keywords";

    }

    private function getFileName($name) {
      do {
        $realName = md5($name);
        $name .= "_";
      } while (file_exists("./files/" . $realName));
      return $realName;
    }

    private function getUploadedFiles() {
      $fieldKeys = array_keys($_FILES);
      foreach($fieldKeys as $fieldKey) {
        $fileInfo = $_FILES[$fieldKey];
        if (is_array($fileInfo["error"])) {
          $fileKeys = array_keys($fileInfo["error"]);
          foreach($fileKeys as $key) {
            if (!$fileInfo["error"][$key] && !($fileInfo["error"][$key] == UPLOAD_ERR_NO_FILE)) {
              $fileName = $this->getFileName($fileInfo["name"][$key]);
              $this->addFile($fieldKey, $key, $fileInfo["name"][$key], $fileName, $fileInfo["tmp_name"][$key], $fileInfo["size"][$key], $fileInfo["type"][$key]);
            }
          }
        } else {
          if ($fileInfo["error"] == UPLOAD_ERR_OK) {
            $fileName = $this->getFileName($fileInfo["name"]);
            $this->addFile($fieldKey, 0, $fileInfo["name"], $fileName, $fileInfo["tmp_name"], $fileInfo["size"], $fileInfo["type"]);
          }
        }
      }
    }

    private function addFile($propertyName, $key, $realName, $fileName, $tempName, $size, $type) {
      $file = $this->uploadedFiles->add($fileName);
      $file->propertyName = preg_replace("/_/", ".", $propertyName);
      $file->key = $key;
      $file->tempName = $tempName;
      $file->realName = $realName;
      $file->size = $size;
      $file->mimeType = $type;
    }

    private function fileError($errorNumber) {
      switch ($errorNumber) {
        case UPLOAD_ERR_INI_SIZE:
          $this->application->errorHandler->addError(UPLOAD_ERR_INI_SIZE, "The uploaded file exceeds the upload_max_filesize directive in php.ini.");
        break;
        case UPLOAD_ERR_FORM_SIZE:
          $this->application->errorHandler->addError(UPLOAD_ERR_FORM_SIZE, "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.");
        break;
        case UPLOAD_ERR_PARTIAL:
          $this->application->errorHandler->addError(UPLOAD_ERR_PARTIAL, "The uploaded file was only partially uploaded.");
        break;
        case UPLOAD_ERR_NO_TMP_DIR:
          $this->application->errorHandler->addError(UPLOAD_ERR_NO_TMP_DIR, "Missing a temporary folder.");
        break;
      }
    }
    
    public function serializeFile($uploadedFile, $preview = "", $keywords = "") {
      move_uploaded_file($uploadedFile->tempName, "./files/" . $uploadedFile->fileName);
      $file = $this->boundData->newObject($uploadedFile->fileName);
      $file->realName = $uploadedFile->realName;
      $file->mimeType = $uploadedFile->mimeType;
      $file->size = $uploadedFile->size;
      $file->preview = $preview;
      $file->keywords = $keywords;
      $file->accessCount = 0;
      $this->boundData->saveObject($uploadedFile->fileName);
    }
    
    public function deleteFile($id) {
      unlink('./files/' . $id);
      $this->boundData->deleteObject($id);
    }
                       
    public function getFile($id) {
      
      $file = $this->boundData->loadObject($id);
      
      if ($file != null) {
        header("content-type: " . $file->mimeType, true);
        header("cache-control: no-cache", true);
        header("pragma: no-cache", true);
        header("expires: " . gmdate(DATE_RFC822), true);
        header("content-disposition: inline; filename=\"" . $file->realName . "\"", true);
        $size = filesize("./files/" . $file->id);
        header("content-length: " . $size, true);
        
        if (($filePointer = fopen("./files/" . $file->id, "r")) !== false) {
          $file->accessCount = $file->accessCount + 1;
          $this->boundData->saveObject($file->id);
          while(!feof($filePointer)) {
            print fread($filePointer, 4096);
          }
          fclose($filePointer);
        }
        exit;
        
      }
      
    }
    
    public function createImagePreview($fileName, $size = 200, $fixedDimension = fdAuto) {
      
      $resource = file_get_contents($fileName);
      
      $source = imagecreatefromstring($resource);
      $resource = null;
      list($width, $height) = getimagesize($fileName); 
      switch ($fixedDimension) {
        case fdWidth:
          $newWidth = $size;
          $newHeight = floor($height * ($newWidth / $width));
        break;
        case fdHeight:
          $newHeight = $size;
          $newWidth = floor($width * ($newHeight / $height));
        break;
        case fdAuto:
          if ($width > $height) {
            $newWidth = $size;
            $newHeight = floor($height * ($newWidth / $width));
          } else {
            $newHeight = $size;
            $newWidth = floor($width * ($newHeight / $height));
          }
        break;
      }
      $thumb = imagecreatetruecolor($newWidth, $newHeight);

      imagecopyresampled($thumb, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
      
      $fileName = $this->getFileName($fileName);
      $fullFileName = "./files/" . $fileName;
      imagepng($thumb, $fullFileName);
      return $fileName;
    }

  }

?>
