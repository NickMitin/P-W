<?php
  
  abstract class bmCustomOutputRenderer extends bmObject {
    
    public $mainPrefix = "HTML";
    public $stylePrefix = "CSS";
    
    abstract function loadAuxilaryModules();
    
  }
  
?>
