<?php

  class bmMemoEditStyles extends bmCustomControlStyles {

  }

?>