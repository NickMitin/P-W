<?php

  abstract class bmCustomStyle extends bmCollectionItem {

    public $font = null;
    public $backgroundImage = null;
    
    public $fontClass = "bmCustomFont";
    public $backgroundImageClass = "bmCustomBackgroundImage"; 

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("styleName", pbValue, "default");
      $this->serializeProperty("foreColor", pbValue, "#000000");
      $this->serializeProperty("backColor", pbValue, "#ffffff");
      $this->serializeProperty("horizontalAlign", pbValue, haLeft);
      $this->serializeProperty("verticalAlign", pbValue, vaTop);
      $this->serializeProperty("borderStyle", pbValue, bsNone);
      $this->serializeProperty("borderColor", pbValue, "#000000");
      $this->serializeProperty("borderWidth", pbValue, "1px");

      $this->font = $this->createOwnedObject($this->fontClass, array("name" => "font"));
      $this->backgroundImage = $this->createOwnedObject($this->backgroundImageClass, array("name" => "backgroundImage"));

    }

  }

?>
