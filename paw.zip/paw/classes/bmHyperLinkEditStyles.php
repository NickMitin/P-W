<?php

  class bmHyperLinkEditStyles extends bmCustomControlStyles {

  }

?>
