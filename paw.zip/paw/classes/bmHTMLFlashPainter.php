<?php

  class bmHTMLFlashPainter extends bmHTMLStandaloneControlPainter {
  
    function drawControl($control) {
      
      $result = "<object id=\"" . $control->name . "Movie\" type=\"application/x-shockwave-flash\" style=\"width: " . $control->width . "; height: " . $control->height . ";\" data=\"" . $control->movie . "\">";
      $result .= "<param name=\"allowScriptAccess\" value=\"sameDomain\" />";
      $result .= "<param name=\"movie\" value=\"" . $control->movie . "\" />";
      $result .= "<param name=\"menu\" value=\"false\" />";
      $result .= "<param name=\"quality\" value=\"high\" />";
      $result .= "</object>";
      
      return $result;
      
    }
  
  }

?>
