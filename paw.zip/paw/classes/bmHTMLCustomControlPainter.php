<?php

  abstract class bmHTMLCustomControlPainter extends bmCustomControlPainter {
    
    public function drawLink($query, $title, $caption, $style = 'default', $override = false, $onClick = false) {
      
      $prefix = $override ? '' : $this->application->path . 'main.php?';
      
      if ($onClick) {
        $onClick = ' onclick="javascript:window.location=\'' . $prefix . $query . '\';"'; 
      } else {
        $onClick = ' ';
      }
      
      return '<a' . $onClick . ' href="' . $prefix . $query . '" title="' . $title . '" class="' . $style . '">' . $caption . '</a>';
      
    }

  }

?>
