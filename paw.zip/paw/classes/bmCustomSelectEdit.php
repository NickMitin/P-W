<?php

  class bmCustomSelectEdit extends bmCustomOptionEdit {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("size", pbValue, 8);

    }

  }

?>
