<?php
  
  class bmChat extends bmCustomChat {
    
    public $hasClientMirror = 1;
    
  }
  
?>
