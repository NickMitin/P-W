<?php

  define('rOdd', 1);
  define('rEven', 2);
  define('rmView', 1);
  define('rmEdit', 2);

  class bmCustomDataGrid extends bmCustomDataControl {

    public $columns = null;
    public $rowToolBarButtons = null;
    public $optionsView = null;
    public $optionsBehaviour = null;
    public $captionLabel = null;
    public $pageCount = 0;
    public $actions = null; 

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('onCustomDrawDataRow', pbValue);
      $this->serializeProperty('onCustomDrawDataCell', pbValue);
      $this->serializeProperty('onCustomDrawNavigator', pbValue);
      $this->serializeProperty('onCustomDrawColumnHeader', pbValue);
      $this->serializeProperty('onCustomDrawGroupingRow', pbValue);
      
      $this->serializeProperty('onDeleteRow', pbValue);
      $this->serializeProperty('onEditRow', pbValue);
      
      $this->serializeProperty('inplaceRowEditing', pbValue, true);
      $this->serializeProperty('autoFit', pbValue, true);
      $this->serializeProperty('editModeRecordList', pbSet, array());
      
      $this->publishProperty('currentPage', pbValue, 1);
      $this->publishProperty('objectsPerPage', pbValue, 10);
      
      $this->publishMethod('editRow');
      $this->publishMethod('deleteRow');

      $this->optionsView = $this->createOwnedObject('bmDataGridOptionsView', array('name' => 'optionsView'));
      $this->optionsBehaviour = $this->createOwnedObject('bmDataGridOptionsBehaviour', array('name' => 'optionsBehaviour'));
      $this->actions = $this->createOwnedObject('bmPagedControlActions', array('name' => 'actions'));
      $this->rowToolBarButtons = $this->createOwnedObject('bmDataRowToolBarButtons', array('name' => 'rowToolBarButtons'));
      $this->columns = $this->createOwnedObject('bmDataColumns', array('name' => 'columns'));
      
      if (($this->columns->count == 0) && ($this->boundData != null)) {
        foreach ($this->boundData->boundDataMap->dataObjectMaps->items as $objectMap) {
          foreach ($objectMap->propertiesMap->items as $propertyMap) {
            $column = $this->columns->add($propertyMap->propertyName);
            $column->caption = $propertyMap->propertyName;
          }
        }
      }
      
      if ($this->optionsView->rowToolBar) {
        if (!$this->columns->exists('toolBar')) {
          $column = $this->columns->add('toolBar', 'bmInplaceToolBar'); 
          $column->shouldSerialize = false;
          $column->caption = 'Операции';
        }
        $buttons = $this->rowToolBarButtons;
        if (!$buttons->exists('delete')) {
          $button = $buttons->add('delete');
        } else {
          $button = $buttons->items['delete'];
        }
        if (!$button->valueFromXML('resource')) {
          $button->resource = 'bDelete';
        }
        if (!$button->valueFromXML('type')) {
          $button->type = drtbbDelete;
        }
        if ($buttons->exists('edit')) {
          if (!$this->boundData->optionsData->save) {
            $buttons->delete('edit');
          }
        } else {
          if ($this->boundData->optionsData->save) {
            $button = $buttons->add('edit');
            $button->resource = 'bEdit';
            $button->type = drtbbEdit;
          }
        }
      }
      
      if ($this->mode == dcmEdit) {
        $column = $this->columns->add('delete', 'bmInplaceCheckBoxEdit');
        $column->shouldSerialize = false;
        $column->caption = 'Удалить';
      }

    }
    
    public function deleteRow($dataObjectId) {
      if (($result = $this->callEventHandler($this->onDeleteRow, array('dataObjectId' => $dataObjectId))) === false) { 
        $this->boundData->deleteObject($dataObjectId);
      }
    }
    
    public function editRow($dataObjectId) {
      
      $array = $this->editModeRecordList;
      
      if (($key = array_search($dataObjectId, $array)) === false) {
        $array[] = $dataObjectId;
      } else {
        unset($array[$key]);
      } 
      
      $this->editModeRecordList = $array; 
      
      //if (($result = $this->callEventHandler($this->onEditRow, array('dataObject' => $dataObjectId))) === false) {
        //$this->boundData->deleteObject($dataObjectId);
      //}
      
    }
    
    public function currentPageSetter($value) {
      if ($value > 0) {
        $this->currentPage = $value;
        return true;
      } else {
        return false;
      }
    }
    
    public function loadData() {
      $this->boundData->flush();
      $objectCount = $this->boundData->totalObjectCount;
      if ($objectCount > 0) {
        $objectsPerPage = $this->objectsPerPage; 
        if ($objectsPerPage > 0) {
          $this->pageCount = ceil($objectCount / $objectsPerPage);
          if ($this->currentPage > $this->pageCount) {
            $this->restoreValue('currentPage');
          }
          $this->boundData->range->start = ($this->currentPage - 1) * $objectsPerPage;
          $this->boundData->range->length = $objectsPerPage;
        } else {
          $this->boundData->range->start = 0;
          $this->boundData->range->length = $objectCount;
        }
      }
      $this->boundData->loadObjects();
    }
    
    public function getClientPropertyValues() {
      $result = parent::getClientPropertyValues();
      if ($this->optionsBehaviour->hotTrack) {
        $result .= ' this.optionsBehaviour.hotTrack = true;';
      }
      $result .= ' this.styles.hotTrackRow = "' . $this->styles->hotTrackRow . '";';
      $result .= ' this.styles.selectedRow = "' . $this->styles->selectedRow . '";';
      $result .= ' this.styles.oddRow = "' . $this->styles->oddRow . '";';
      $result .= ' this.styles.evenRow = "' . $this->styles->evenRow . '";';
      return $result;
    }
    

  }

?>
