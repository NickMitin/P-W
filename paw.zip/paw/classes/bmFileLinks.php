<?php

  class bmFileLinks extends bmCollection {

    public $collectionItemClass = "bmFileLink";
    public $keyPropertyName = "fileName";

    function toHTML() {
      $result = "";
      foreach ($this->items as $item) {
        $result .= $item->toHTML();
        unset($item);
      }
      return $result;
    }

  }

?>