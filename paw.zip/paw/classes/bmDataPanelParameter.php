<?php
  
  class bmDataPanelParameter extends bmCollectionItem {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("parameterName", pbValue, "");
      $this->serializeProperty("value", pbValue, "");

    }
    
  }
  
?>