<?php
  
  class bmHTMLVerticalDataGridPainter extends bmHTMLCustomDataControlPainter {
    
    function drawColumnHeader($control, $column) {
      
      $styles = $control->styles;
      
      $result = "<td class=\"$styles->columnHeader\">" . $column->caption . "</td>\n";
      
      return $result;
      
    }
    
    function drawControl($control) {
      
      $dataObjects = $control->boundData->dataObjects;
      
      $result = "";
      $result .= "<table style=\"width: 100%;\" cellpadding=\"0\" cellspacing=\"0\">";
      
      foreach ($control->columns->items as $column) {
        $result .= "<tr>";
        $result .= $this->drawColumnHeader($control, $column);
        foreach ($dataObjects->items as $object) {
          $propertyName = $column->propertyName;
          $column->inplaceEdit->keyValue = $object->id;
          $column->inplaceEdit->value = $object->$propertyName;
          $result .= "<td>" . $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default") . "</td>";
        }
        $result .= "</tr>";
      }
      if ($control->mode == dcmEdit) {
        $result .= "<tr><td colspan=\"2\">";
        $result .= "<input type=\"hidden\" name=\"" . $control->boundData->getComponentString() . ".update\" value=\"1\" />\n<button type=\"submit\">Update</button>";
        $result .= "</td></tr>";
      }
      $result .= "</table>";
      return $result;
    }
    
  }
  
?>
