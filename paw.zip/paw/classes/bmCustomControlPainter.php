<?php

  abstract class bmCustomControlPainter extends bmCollectionItem {
    
    public $className = 'bmCustomControlPainter';
    
    abstract function draw($control);

  }

?>
