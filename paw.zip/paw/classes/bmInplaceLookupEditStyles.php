<?php
  
  class bmInplaceLookupEditStyles extends bmCustomControlStyles {
    
      
    
  }
  
?>