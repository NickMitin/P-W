<?php

  class bmPasswordEdit extends bmCustomPasswordEdit {
    
    public $hasClientMirror = 1;
  
  }

?>
