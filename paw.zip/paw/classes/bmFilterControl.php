<?php

  class bmFilterControl extends bmWebCustomControl {

    public $dataControl = null;
    public $dataSource = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->publishProperty("dataControl", pbReference);

    }

    function initalize() {

      parent::initialize();
      $this->dataSource = $this->dataControl->dataSource;

    }

  }

?>