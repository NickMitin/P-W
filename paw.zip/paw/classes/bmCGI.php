<?php

  class bmCGI extends bmComponent {

    public $request = array();
    public $cookies = array();

    private function getRequest() {
      
      $request = array();
      if ($_POST) {
        $request = array_merge($request, $_POST);
      }
      if ($_GET) {
        $request = array_merge($request, $_GET);
      }
      return $request;
    }

    private function getCookies() {
      return $_COOKIE;
    }

    public function addCookie($name, $value, $time = 0, $path = '/') {
      $this->cookies[$name] = $value;
      setcookie($name, $value, $time, $path);
    }

    public function deleteCookie($name, $path = '/') {
      unset($this->cookies[$name]);
      setcookie($name, 'none', time() - 1000, $path);
    }
    
    public function cookieExists($name) {
      return (array_key_exists($name, $this->cookies));
    }

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->request = $this->getRequest();
      $this->cookies = $this->getCookies();
      $this->application->clientRequest = $this->request;

    }
    
    public function getIP() {
      $result = (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : 'N/A';
      if ($result == 'N/A') {
        $result = (array_key_exists('REMOTE_ADDR', $_SERVER)) ? $_SERVER['REMOTE_ADDR'] : 'N/A';
      }
      return $result;
    }
    
    public function getReferer() {
      return (array_key_exists('HTTP_REFERER', $_SERVER)) ? $_SERVER['HTTP_REFERER'] : 'N/A';
    }
    
    public function getURI() {
      return (array_key_exists('REQUEST_URI', $_SERVER)) ? $_SERVER['REQUEST_URI'] : 'N/A';
    }
    
    public function getQueryString() {
      return (array_key_exists('QUERY_STRING', $_SERVER)) ? $_SERVER['QUERY_STRING'] : 'N/A';
    }
    
    public function getUserAgent() {
      return (array_key_exists('HTTP_USER_AGENT', $_SERVER)) ? $_SERVER['HTTP_USER_AGENT'] : 'N/A';
    }
    
    public function httpRequest($url = '/', $method = 'GET') {
      
      $response = file_get_contents($url);

      
      
      //$request = $method . " " . $url . " HTTP/1.1\r\nHost: webson.ru\r\nUser-Agent: WEBSON\r\nAccept: */*\r\n\r\n";
      /*if (($socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
        return false;
      }
      $error = false;
      if (socket_connect($socket, '85.21.147.66', 80) < 0) {
        $error = true;
      }
      if (!$error) {
        socket_write($socket, $request, strlen($request));
        $response = '';
        while ($token = socket_read($socket, 2048)) {
          $response .= $token;
        }
        socket_close($socket);
      }
      
      list(,$response) = explode("\r\n\r\n", $response);
      */
      
      return $response;
      
    }
    
  }

?>
