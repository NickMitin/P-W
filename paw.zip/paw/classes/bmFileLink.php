<?php



  class bmFileLink extends bmCollectionItem {

    function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("fileName", pbValue, "");
      $this->serializeProperty("type", pbValue, flCSS);

    }

    function toHTML() {
      switch ($this->type) {
        case flCSS:
          $rel = "stylesheet";
          $type = "text/css";
        break;
        default:
          $rel = "none";
          $type = "text/plain";
      }
      return "<link rel=\"$rel\" href=\"$this->fileName\" type=\"$type\"/>\n";
    }

  }

?>