<?php

  class bmCustomImageEdit extends bmCustomEdit {

    public $acceptFiles = true;
    public $fileTypes = array('image/jpeg', 'image/jpeg', 'image/gif', 'image/png');

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('preview', pbValue);
      $this->serializeProperty('alternativeText', pbValue);
      $this->serializeProperty('allowUpload', pbValue, true);
      $this->serializeProperty('boundImage', pbReference);
      $this->serializeProperty('clientName', pbValue, '');

    }

  }

?>
