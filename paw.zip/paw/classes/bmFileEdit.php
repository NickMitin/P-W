<?php

  class bmFileEdit extends bmCustomFileEdit {
    
    public $file = null;
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $propertyName = $this->getComponentString() . ".value";
      $this->file = $application->fileStorage->uploadedFiles->getFileByPropertyNameKey($propertyName, 0);
      if ($this->file != null) {
        if ($this->acceptMimeTypes != "*/*") {
          if (strpos($this->acceptMimeTypes, $this->file->mimeType) === false) {
            $this->file = null;
            //TODO Error
          }
        } 
        if ($this->maximumSize > 0) {
          if (($this->file != null) && ($this->file->size > $this->maximumSize)) {
            $this->file = null;
            //TODO Error
          }
        }
      }
    }

  }
  
?>
