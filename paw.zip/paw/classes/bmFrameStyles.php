<?php
  
  class bmFrameStyles extends bmCustomControlStyles {
    
  }
  
?>
