<?php

  class bmHTMLInplaceHyperLinkEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    public function draw($control, $dataControl, $dataCollection, $style) {
      $result = '';
      if (($hyperLink = $control->callEventHandler($control->onGetHyperLink, array('sender' => $this))) === false) {
        $dataObject = $dataControl->boundData->dataObjects->items[$control->keyValue];
        $propertyName = $control->hyperLink;
        //$hyperLink = $dataObject->$propertyName;
      }
      if ($control->owner->readOnly) {
        $result = '<a href="' . $hyperLink . '">' . $control->value . '</a>';
      } else {
        switch ($dataControl->mode) {
          case dcmView:
            $result = '<a href="' . $hyperLink . '">' . $control->value . '</a>';
          break;
          case dcmEdit:
            $result = "<input type=\"text\" style=\"width: 100%;\" class=\"$style\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[$control->keyValue]\" value=\"" . $this->application->validator->formatXMLValue($control->value) . "\"/>";
          break;
        }
      }
      return $result;
    }

  }

?>
