<?php
  
  class bmCoolBarButton extends bmCustomCoolBarButton {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("caption", pbValue, "");
      $this->serializeProperty("left", pbValue, 0);
      $this->serializeProperty("top", pbValue, 0);
      $this->serializeProperty("right", pbValue, 0);
      $this->serializeProperty("bottom", pbValue, 0);
      $this->serializeProperty("action", pbValue);
    }
  }
  
?>
