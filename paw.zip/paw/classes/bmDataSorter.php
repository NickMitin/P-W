<?php

  define("soAscending", 1);
  define("soDescending", 2);
  
  class bmDataSorter extends bmPersistentObject {
    
    public $conditions = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("randomize", pbValue, false);
      
      $this->conditions = $this->createOwnedObject("bmDataSortingConditions", array("name" => "conditions"));
      $this->publishMethod("sortAscending");
      $this->publishMethod("sortDescending");
      $this->publishMethod("clearSorting");

    }
    
    private function sortField($fieldName, $sortOrder) {
      switch($sortOrder) {
        case (soAscending || soDescending):
          if ($this->conditions->exists($fieldName)) {
            $condition = $this->conditions->items[$fieldName];
            if ($condition->sortOrder == $sortOrder) {
              return;
            }
          } else {
            $condition = $this->conditions->add($fieldName);
          }
          $condition->sortOrder = $sortOrder;
        break;
        default:
          $this->conditions->delete($fieldName);
        break;
      }
    }
    
    public function sortAscending($fieldName) {
      $this->sortField($fieldName, soAscending);
    }
    
    public function sortDescending($fieldName) {
      $this->sortField($fieldName, soDescending);
    }
    
    public function clearSorting($fieldName) {
      $this->sortField($fieldName, 0);
    }
    
  }
  
?>
