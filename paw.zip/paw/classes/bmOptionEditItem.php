<?php

  class bmOptionEditItem extends bmCollectionItem {

    public $selected = false;

    function constructor($collection, $owner, $parameters) {

      parent::constructor($collection, $owner, $parameters);
      $this->serializeProperty("caption", pbValue);
      $this->serializeProperty("value", pbValue);

    }

  }

?>