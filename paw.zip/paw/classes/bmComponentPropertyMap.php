<?php

  define ("ptInteger", 1);
  define ("ptFloat", 2);
  define ("ptString", 3);
  define ("ptBoolean", 4);
  define ("ptReference", 5);
  define ("ptObject", 6);

  class bmComponentPropertyMap extends bmCollectionItem {

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("type", pbValue, ptString);
      $this->serializeProperty("defaultValue", pbValue);
      $this->serializeProperty("editClass", pbValue, "bmInplaceTextEdit");

    }
    
  }

?>
