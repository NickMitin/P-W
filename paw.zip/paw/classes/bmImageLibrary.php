<?php

  class bmImageLibrary extends bmWebObject {

    static function resizeImage($imageFile) {

    }

  }

?>