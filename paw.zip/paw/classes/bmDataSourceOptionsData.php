<?php
  
  class bmDataSourceOptionsData extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("new", pbValue, true);
      $this->serializeProperty("save", pbValue, true);
      $this->serializeProperty("delete", pbValue, true);

    }
    
  }
  
?>