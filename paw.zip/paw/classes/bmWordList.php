<?php

  class bmWordList extends bmCustomWordList {
    
    public $hasClientMirror = 1;

  }

?>
