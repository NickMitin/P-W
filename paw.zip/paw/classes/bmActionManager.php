<?php
  
  class bmActionManager extends bmCollection {
      
    
  }
  
?>