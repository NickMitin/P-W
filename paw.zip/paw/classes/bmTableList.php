<?php

  class bmTableList extends bmWebPersistentObject {

    public $mainTableName = "";
    public $tableList = "";

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("mainTableName", pbValue);
      $this->serializeProperty("tableList", pbValue);

    }

    function toSQL() {
      return $this->tableList;
    }

  }

?>