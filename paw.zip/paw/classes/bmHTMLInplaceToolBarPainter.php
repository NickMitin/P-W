<?php

  class bmHTMLInplaceToolBarPainter extends bmHTMLInplaceCustomEditPainter {
    
    public function draw($control, $dataControl, $dataCollection, $style) {
      $result = '<div style="white-space: nowrap; float: left;" class="' . $style . '">';
      foreach ($dataControl->rowToolBarButtons->items as $button) {
        if ($button->visible) {
          $result .= $this->drawButton($button, $control, $dataControl, $dataCollection, $style);
        }
        
        if ($dataControl->editModeRecordList != null) {
          if (in_array($control->keyValue, $dataControl->editModeRecordList)) {
          }
        }
      }
      $result .= '</div>';
      return $result;
    }

    private function drawButton($button, $control, $dataControl, $dataCollection, $style) {
      
      if ($dataControl->name == 'dgBlogPopular') {

      }
      
      $resource = $this->application->getResource($button, $button->resource, rtGraphic);
      
      $action = null;
      
      $result = ''; 
      if ($dataControl->inplaceRowEditing) {
        $formName = $dataControl->ownerForm->name;
        if ($button->action == null) {
          $action = $this->application->path . 'main.php?application.switchForm=' . $formName . '&amp;application.' . $formName . '.' . $dataControl->name . '.';
          switch ($button->type) {
            case drtbbDelete:
              $action .= 'boundData.deleteObject=' . $control->keyValue;
            break;
            case drtbbEdit:
              $action = 'boundData.editObject=' . $control->keyValue;
            break;
            default:
              $action = $this->application->path;
            break;
          }
        } elseif ($this->application->actions->exists($button->action)) {
          $action = $this->application->actions->items[$button->action];
          $action->value = $control->keyValue;
          $action = $action->toHTML();
        } else {
          $action = $this->application->path . $button->action . $control->keyValue;
        }
        
        if ($action != null) {
          $id = $this->application->textUtils->textToId($control->keyValue);
          $result .= '<a id="' . $control->name . 'ToolBarButton' . $button->type . $id . '" title="' . $control->keyValue . '" href="' . $action . '">';
        }
        $result .= '<img style="border-style: none;" src="' . $resource . '" alt="' . $button->caption . '"/>';
        if ($action != null) {
          $result .= '</a>';
        }
      }
      
      return $result;
      
    }
    
  }

?>
