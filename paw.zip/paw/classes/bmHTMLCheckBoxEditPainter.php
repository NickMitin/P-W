<?php
  
  class bmHTMLCheckBoxEditPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      $checked = ($control->value == 1) ? ' checked="checked"' : '';
      return '<input type="hidden" id="' . $control->name . 'Edit" name="' . $control->getComponentString() . '.value" value="' . $control->value . '" /><input id="' . $control->name . 'Trigger" type="checkbox" class="' . $control->styles->default . '"' . $checked . '/>' . $control->caption;
    }
  
  }
  
?>
