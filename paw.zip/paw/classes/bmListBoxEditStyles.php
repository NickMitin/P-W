<?php
  
  class bmListBoxEditStyles extends bmCustomControlStyles {
    
  }
  
?>