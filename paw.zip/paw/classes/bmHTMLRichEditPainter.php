<?php
  
  class bmHTMLRichEditPainter extends bmHTMLStandaloneControlPainter {
    
    function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
    }
    
    function drawControl($control) {
      switch ($control->mode) {
        case emEdit:
          $editor = new wysiwygPro();
          $editor->set_name('application.' . $control->ownerForm->name . '.' . $control->name . '.value');
          $editor->set_code($control->value);          
          $editor->usexhtml(true, 'utf-8');
          $width = (is_int($control->width)) ? $control->width : 600;
          $height = (is_int($control->height)) ? $control->height : 400;
          $result = $editor->return_editor($width, $height);
          $result .= '<div><a href="' . $this->application->path . 'main.php?application.' . $control->ownerForm->name . '.' . $control->name . '.mode=1">View</a></div>';
          return $result;
        break;
        case emView:
          $result = $control->value;
          if ($this->application->session->persistent) {
          $result .= '<div><a href="' . $this->application->path . 'main.php?application.' . $control->ownerForm->name . '.' . $control->name . '.mode=2">Edit</a></div>';
          }
          return $result;
        break;
      }
    }
    
  }
  
?>
