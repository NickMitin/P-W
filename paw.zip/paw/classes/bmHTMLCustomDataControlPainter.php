<?php

  abstract class bmHTMLCustomDataControlPainter extends bmHTMLStandaloneControlPainter {
    
    function draw($control) { 
      $result = "";
      
      if ($control->mode == dcmEdit) {
        $result .= '<form style="margin: 0; padding: 0;" id="' . $control->name . 'Form" enctype="multipart/form-data" action="' . $this->application->path . 'main.php" method="post">';
      }
      $result .= parent::draw($control);
      if ($control->mode == dcmEdit) {
        $result .= '</form>';
      }
      return $result;
    }
    
  }
  
?>
