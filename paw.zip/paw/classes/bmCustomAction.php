<?php
  
  abstract class bmCustomAction extends bmCollectionItem {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("actionName", pbValue);

    }
    
    abstract function execute($sender, $arguments);
    
  }
  
?>
