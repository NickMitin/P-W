<?php
  
  class bmCustomOptionEdit extends bmCustomEdit {
    
    public $options = null;
  
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('keyPropertyName', pbValue, 'id');
      $this->serializeProperty('displayPropertyName', pbValue);
      $this->serializeProperty('onChange', pbValue);
      $this->serializeProperty('onOptionsLoading', pbValue);

      $this->options = $this->createOwnedObject('bmOptionEditList', array('name' => 'options'));
      
      $this->update();

    }
    
    public function setter($propertyName, $value) {
      switch($propertyName) {
        case 'value':
          parent::setter($propertyName, $value);
          $this->update();
        break;
        default:
          parent::setter($propertyName, $value);
        break;
      }
    }
    
    private function loadOptions() {
      return $this->callEventHandler($this->onOptionsLoading, null);
    }
    
    private function update() {
      $set = true;
      if ($this->options->count == 0) {
        $load = $this->loadOptions();
      }
      if ($set) {
        foreach($this->options->items as $option) {
          if ($option->value == $this->value) {
            $option->selected = true;
          } else {
            $option->selected = false;
          }
        }
      }
    }
    
  }
  
?>
