<?php

  define("bmValidatorBase", 1000);

  define("bmValidatorURL", bmValidatorBase + 1);
  define("bmValidatorEMail", bmValidatorBase + 2);
  define("bmValidatorICQ", bmValidatorBase + 3);
  define("bmValidatorIdentifier", bmValidatorBase + 4);
  define("bmValidatorNonZero", bmValidatorBase + 5);
  define("bmValidatorNumber", bmValidatorBase + 6);
  define("bmValidatorCreditCardNumber", bmValidatorBase + 7);
  define("bmValidatorText", bmValidatorBase + 8);
  define("bmValidatorEmptyValue", bmValidatorBase + 9);

  class bmValidator extends bmComponent {

    private $errorDescriptions = array();
    private $patterns = array();

    public $onError = null;

    function bmValidator($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->errorDescriptions[bmValidatorURL] = "Invalid URL specified.";
      $this->errorDescriptions[bmValidatorEMail] = "Invalid e-mail address specified.";
      $this->errorDescriptions[bmValidatorICQ] = "Invalid ICQ number specified.";
      $this->errorDescriptions[bmValidatorIdentifier] = "Invalid identifier specified.";
      $this->errorDescriptions[bmValidatorNonZero] = "The value should be a number greader than zero.";
      $this->errorDescriptions[bmValidatorNumber] = "The value specified in not a valid number.";
      $this->errorDescriptions[bmValidatorCreditCardNumber] = "Invalid credit card number specified.";
      $this->errorDescriptions[bmValidatorText] = "The text is not valid.";
      $this->errorDescriptions[bmValidatorEmptyValue] = "The value cannot be empty.";

      $this->patterns[bmValidatorURL] = "/^(https?|ftp):\/\/([\w\-]+(\.[\w\-]+)*(\.[a-z]{2,4})?)(:(\d{1,5}))?(\/(.*))?$/i";
      $this->patterns[bmValidatorEMail] = "/^([\w\-\.]+)@([\w\-]+(\.[\w\-]+)*(\.[a-z]{2,4})?)$/i";
      $this->patterns[bmValidatorICQ] = "/^\d{5,10}$/i";
      $this->patterns[bmValidatorIdentifier] = "/^[A-Za-z_][A-Za-z0-9_]*$/";
      $this->patterns[bmValidatorNonZero] = "/^[^0][0-9]*$/";
      $this->patterns[bmValidatorNumber] = "/^[0-9]+$/";
      $this->patterns[bmValidatorCreditCardNumber] = "/^[0-9]{16}$/";
      $this->patterns[bmValidatorText] = "/[^\s]+/u";
    }

    function doError($errorCode, $errorDescription) {
      $callback = $this->onError;
      if ($callback) {
        $callback($errorCode, $errorDescription);
      } else {
        $this->application->errorHandler->addError($errorCode, $errorDescription);
      }
    }

    function validate($value, $patternId, $strict, $doError) {
      if (($strict) && (!$value)) {
        if ($doError) {
          $this->doError(bmValidatorEmptyValue, $this->errorDescriptions[bmValidatorEmptyValue]);
        }
        return false;
      } elseif ($value) {
        if (!preg_match($this->patterns[$patternId], $value)) {
          if ($doError) {
            $this->doError($patternId, $this->errorDescriptions[$patternId]);
          }
          return false;
        }
      }
      return true;
    }

    function validateURL($url, $strict = false, $doError = true) {
      if ((!$strict) && (!$url)) {
        return true;
      }
      return preg_match($this->url, $url);
    }

    function validateEMail($email, $strict = false, $doError = true) { 
      if ($result = $this->validate($email, bmValidatorEMail, $strict, $doError)) {
        list(,$domain) = split('@', $email);
        if (!($result = (gethostbyname($domain) != $domain))) {
          $this->doError(bmValidatorEMail, $this->errorDescriptions[bmValidatorEMail]);  
        }
      }
      return $result;
    }

    function validateICQ($icq, $strict = false, $doError = true) {
      if ((!$strict) && (!$icq)) {
        return true;
      }
      return preg_match($this->icq, $icq);
    }

    function validateIdentifier($identifier, $strict = false, $doError = true) {
      return $this->validate($identifier, bmValidatorIdentifier, $strict, $doError);
    }

    function validateNumber($number, $strict = false, $doError = true) {
      return $this->validate($number, bmValidatorNumber, $strict, $doError);
    }

    function validateCreditCardNumber($creditCardNumber, $strict = false) {
      return $this->validate($creditCardNumber, bmValidatorCreditCardNumber, $strict, $doError);
    }

    function validateText($text, $strict = false, $doError = true) {
      return $this->validate($text, bmValidatorText, $strict, $doError);
    }

    function validateNonZero($number, $strict = false, $doError = true) {
      return $this->validate($number, bmValidatorNonZero, $strict, $doError);
    }

    function validateFileName($fileName, $strict = false, $doError = true) {
      return $this->validate($fileName, bmValidatorFileName, $strict, $doError);
    }

    function formatOutput($output, $stripSlashes = false, $literizeHTML = true) {
      if ($stripSlashes) {
        $output = stripslashes($output);
      }
      if ($literizeHTML) {
        $output = $this->formatXMLValue($output);
      }
      return $output;
    }
    
    public function formatXMLValue($value) {
      return htmlspecialchars($value, ENT_QUOTES);
    }
    
    public function fixEncoding($value) {
      if (mb_detect_encoding($value, 'utf-8, windows-1251') != 'UTF-8') {
        return mb_convert_encoding($value, 'utf-8', 'windows-1251');
      } else {
        return $value;
      }
      
    }
    
    public function formatDataObjectValue($dataLink, $value) {
      return $dataLink->formatValue($value);
    }
    
    
  }

?>
