<?php

  class bmDataTileGridOptionsView extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty('topNavigator', pbValue, false);
      $this->serializeProperty('bottomNavigator', pbValue, true);
      $this->serializeProperty('rowToolBar', pbValue, true);
      
    }

  }

?>
