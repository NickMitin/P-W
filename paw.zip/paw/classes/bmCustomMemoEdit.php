<?php

  define("wwPhysical", "soft");
  define("wwVirtual", "hard");
  define("wwNone", "off");

  class bmCustomMemoEdit extends bmCustomEdit {

    function constructor($application, $owner, $parameters) {
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("wordWrap", pbValue, wwVirtual);
    }

  }

?>