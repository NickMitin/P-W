<?php

  class bmDataFilterInRangeCondition extends bmCustomDataFilterCondition {
    
    public $values = null;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->values = $this->createOwnedObject("bmDataFilterConditionValues", array("name" => "values")); 

    }

  }

?>
