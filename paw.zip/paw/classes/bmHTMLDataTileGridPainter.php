<?php

  class bmHTMLDataTileGridPainter extends bmHTMLCustomDataControlPainter {
    
    private $groupingRowValues = array(); 
    private $switchForm = '';
    
    function drawControl($control) {
      
      $this->switchForm = 'application.switchForm=' . $control->ownerForm->name . '&amp;';
      
      foreach ($control->columns->items as $column) {
        if ($column->type == ctGrouping) {
          $this->groupingRowValues[$column->propertyName] = '';
        }
      }
      
      switch ($control->layout) {
        case dtglFixed:
      
          $result = '<table style="width: 100%; height: 100%" cellpadding="0" cellspacing="0"><tbody>';
          
          $result .= $this->drawDataTiles($control);
          if ($control->optionsView->bottomNavigator) {
            $result .= $this->drawNavigator($control);
          }
          $result .= '</tbody></table>';
          
        break;
        case dtglDynamic:
          $result = '<div style="clear: both; position: relative; width: 100%; height: 100%">';
          
          $result .= $this->drawDataTilesDynamic($control);
          if ($control->optionsView->bottomNavigator) {
            $result .= $this->drawNavigatorDynamic($control);
          }
          $result .= '</div>';
        break;
      }
      return $result;
                                             
    }
    
    function drawNavigator($control) {
      $result = '<tr><td colspan="' . $control->tilesPerRow . '">';
      $action = ($control->actions->pageChange) ? $control->actions->pageChange :  $this->application->path . 'main.php?' . $this->switchForm . 'application.' . $control->ownerForm->name . '.' . $control->name . '.currentPage=';
      for ($i = 1; $i <= $control->pageCount; ++$i) {
        if (($item = $control->callEventHandler($control->onCustomDrawNavigatorItem, array('sender' => $this, 'pageNumber' => $i))) !== false) {
          $result .= $item;
        } else {
          $style = ($i == $control->currentPage) ? $control->styles->currentPageNumber : $control->styles->pageNumber;
          $result .= '<a class="' . $style . '" href="' . $action . $i . '">' . $i . '</a> ';  
        }        
      }
      $result .= '</td></tr>';
      
      return $result;
    }
    
    function drawDataTiles($control) {
      
      $i = 1;
      $result = "";
      $tileCount = $control->boundData->dataObjects->count;
      if ($tileCount > 0) {
        $height = ($tileCount / $control->tilesPerRow);
        $width = $control->tilesPerRow;
        $evenWidth = ($width % 2 == 0);
        $tileWidth = floor(100 / $width);
        $x = 0;
        $y = 0;
        $currentTile = 0;
        $dataObjects = &$control->boundData->dataObjects->items;
        reset($dataObjects);
        $object = current($dataObjects);
        for ($y = 0; $y < $height; ++$y) {
          $row = '<tr>';
          for ($x = 0; $x < $width; ++$x) {
            if ($object !== false) {
              foreach ($control->columns->items as $column) {
                $fieldName = $column->propertyName; 
                if ($column->type == ctGrouping) {
                  if ($this->groupingRowValues[$fieldName] != $object->$fieldName) {
                    $result .= $this->drawGroupingRow($control, $object, $object->$fieldName, $column); 
                    $this->groupingRowValues[$fieldName] = $object->$fieldName;
                  }
                }
              }
            }
            $row .= $this->drawDataTile($control, $object, $tileWidth, $currentTile);
            $currentTile = 1 - $currentTile;
            $object = next($dataObjects);
          }
          if ($evenWidth) {
            $currentTile = 1 - $currentTile;
          }
          $row .= '</tr>';
          $result .= $row;
        }
        /*foreach ($control->boundData->dataObjects->items as $object) {
          if ($x == $width) {
            $result .= "</tr>"; 
            $x = 0;
          }
          foreach ($control->columns->items as $column) {
            $fieldName = $column->propertyName; 
            if ($column->type == ctGrouping) {
              if ($this->groupingRowValues[$fieldName] != $object->$fieldName) {
                $result .= $this->drawGroupingRow($control, $object, $object->$fieldName, $column); 
                $this->groupingRowValues[$fieldName] = $object->$fieldName;
                $x = 0;
              }
            }
          }
          if ($x == 0) {
            $result .= "<tr>";
            if ($evenWidth) {
              $currentTile = 1 - $currentTile;
            }
          }
          $result .= $this->drawDataTile($control, $object, $tileWidth, $currentTile);
          $currentTile = 1 - $currentTile;
          $x++;
        }
        if ($x > 0) {
          $result .= "</tr>";
        }*/
      }
      return $result;
    }
    
    function drawDataTile($control, $dataObject, $width, $tileOrder) {
      if (($result = $control->callEventHandler($control->onCustomDrawDataTile, array("dataObject" => $dataObject))) === false) {
        $result = "&nbsp;";
      }
      $style = ($tileOrder == 0) ? $control->styles->evenDataTile : $control->styles->oddDataTile;
      $result = '<td class="' . $style . '" style="width: ' . $width . '%;">' .  $result . '</td>';
      return $result;
    }
    
    function drawGroupingRow($control, $dataObject, $value, $column) {
      if (($result = $control->callEventHandler($control->onCustomDrawGroupingRow, array("dataObject" => $dataObject))) === false) {
        $column->inplaceEdit->keyValue = $dataObject->id;
        $column->inplaceEdit->value = $value;
        $result = $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default");
        $result = "<tr class=\"" . $control->styles->groupingRow . "\"><td class=\"" . $control->styles->groupingRow . "\" colspan=\"" . $control->tilesPerRow . "\">" . $result . "</td></tr>";
      }
      return $result;
    }
    
    function drawNavigatorDynamic($control) {
      $result = '<div style="clear: both;">';
      $action = ($control->actions->pageChange) ? $control->actions->pageChange : $this->application->path . 'main.php?' . $this->switchForm . 'application.' . $control->ownerForm->name . '.' . $control->name . '.currentPage=';
      for ($i = 1; $i <= $control->pageCount; ++$i) {
        if (($item = $control->callEventHandler($control->onCustomDrawNavigatorItem, array('sender' => $this, 'pageNumber' => $i))) !== false) {
          $result .= $item;
        } else {
          $style = ($i == $control->currentPage) ? $control->styles->currentPageNumber : $control->styles->pageNumber;
          $result .= '<a class="' . $style . '" href="' . $action . $i . '">' . $i . '</a> ';  
        }        
      }
      $result .= '</div>';
      
      return $result;
    }
    
    function drawDataTilesDynamic($control) {
      
      $i = 1;
      $result = "";
      $tileCount = $control->boundData->dataObjects->count;
      if ($tileCount > 0) {
        $currentTile = 0;
        foreach ($control->boundData->dataObjects->items as $object) {
          $row = '';
          foreach ($control->columns->items as $column) {
            $fieldName = $column->propertyName; 
            if ($column->type == ctGrouping) {
              if ($this->groupingRowValues[$fieldName] != $object->$fieldName) {
                $result .= $this->drawGroupingRowDynamicDynamic($control, $object, $object->$fieldName, $column); 
                $this->groupingRowValues[$fieldName] = $object->$fieldName;
              }
            }
          }
          $row .= $this->drawDataTileDynamic($control, $object, $currentTile);
          $result .= $row;
        }
      }
      $result .= '<div style="height: 1px; clear: both; float: none; width: 400px;">&nbsp;</div>';
      return $result;
    }
    
    function drawDataTileDynamic($control, $dataObject, $tileOrder) {
      if (($result = $control->callEventHandler($control->onCustomDrawDataTile, array("dataObject" => $dataObject))) === false) {
        $result = "&nbsp;";
      }
      $style = ($tileOrder == 0) ? $control->styles->evenDataTile : $control->styles->oddDataTile;
      $result = '<div class="' . $style . '" style="float: left;">' .  $result . '</div>';
      return $result;
    }
    
    function drawGroupingRowDynamic($control, $dataObject, $value, $column) {
      if (($result = $control->callEventHandler($control->onCustomDrawGroupingRow, array("dataObject" => $dataObject))) === false) {
        $column->inplaceEdit->keyValue = $dataObject->id;
        $column->inplaceEdit->value = $value;
        $result = $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default");
        $result = '<div style="clear: both; float: none;" class="' . $control->styles->groupingRow . '">' . $result . '</div>';
      }
      return $result;
    }

  }

?>
