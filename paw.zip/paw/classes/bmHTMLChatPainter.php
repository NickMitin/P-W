<?php
  
  class bmHTMLChatPainter extends bmHTMLStandaloneControlPainter {

    public function drawControl($control) {
      
      $result = '<table id="' . $control->name . 'RepliesContainer" style="width: 100%; height: 100%;" cellpadding="0" cellspacing="0"><tbody id="' . $control->name . 'Replies">';
      $result .= $this->drawReplies($control);
      $result .= '<tr style="display: none;" id="' . $control->name . 'Anchor"><td></td></tr></tbody></table>'; 
      return $result;
      
    }
    
    function drawReplies($control) {
      
      $i = 1;
      
      $result = "";
      
      if ($control->boundData->dataObjects->count) {
        foreach ($control->boundData->dataObjects->items as $object) {
          $rowOrder = ($i % 2 == 0) ? crEven : crOdd;
          $result .= $this->drawReply($control, $object, $rowOrder, $control->boundData->range->start + $i);
          ++$i;     
        }
      }
      return $result;
      
    }
    
    public function drawReply($control, $dataObject, $rowOrder, $rowNumber) {
      if ($control->mode == dcmEdit) {
        $dataObject->delete = false;
      }
      
      switch ($rowOrder) {
        case crOdd:
          $styleName = $control->styles->oddReply;
        break;
        case crEven:
          $styleName = $control->styles->evenReply;
        break;
      }
      $result = '';
      $customDrawReply = $control->callEventHandler($control->onCustomDrawReply, array("dataObject" => $dataObject, "rowOrder" => $rowOrder, "rowNumber" => $rowNumber));
      $result .= '<tr id="' . $control->name . 'Reply' . $dataObject->id . '">';
      if ($customDrawReply !== false) {
        $result .= $customDrawReply;
      } else {                                              
        $result .= '<td class="' . $styleName . '"><div class="' . $control->styles->userName . '">' . $dataObject->userName . '</div><div class="' . $control->styles->replyTime . '">' . date($control->timestampFormat, $dataObject->timestamp) . '</div></td>';
        $result .= '<td class="' . $styleName . '"><div class="' . $control->styles->replyText . '">' . $dataObject->replyText . '</div></td>';
      }
      $result .= '</tr>';
      return $result;
    }
  
  }
  
?>
