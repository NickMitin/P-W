<?php
  class bmTextUtils extends bmObject {
    
    public function textToHex($text) {
      return bin2hex($text);
    }
    
    public function hexToText($value) {
      return pack('H*', $value);
    }
    
    public function limitText($text, $symbolCount = 200, $addEndEllipcis = false, $offset = 50, $force = false) {
      if (mb_strlen($text) > $symbolCount) {
        if ($force) {
          $text = mb_substr($text, 0, $symbolCount) . ($addEndEllipcis ? '...' : '');
        } else {
          $text = mb_substr($text, 0, $symbolCount + $offset);
          $spacePosition = mb_strrpos($text, ' ');
          $text = mb_substr($text, 0, $spacePosition) . ($addEndEllipcis ? '...' : '');
        }
      }
      return $text;
    }
    
    public function parseBBCode($message) {
      $message = htmlspecialchars($message, ENT_QUOTES);
      $pattern = "/\[\s*(\w+)(\s*=\s*('([^']+)'\s*|(.+?))\s*)?\]([^\[]+)\[\/\\1\]/se";
      while (preg_match($pattern, $message)) {
        $message = preg_replace($pattern, '$this->processToken(\$post, "\1", "\4", "\5", "\6")', $message);
      }
      $message = nl2br($message);
      return $message;
    }
    
    private function processToken($nodeName, $attribute, $attributeQuoted, $nodeValue) {

      $attribute = ($attribute != '') ? $attribute : $attributeQuoted;

      $nodeName = strtolower($nodeName);

      switch ($nodeName) {
        case 'b':
          $result = fontBold($nodeValue);
        break;
        case 'i':
          $result = fontItalic($nodeValue);
        break;
        case 'u':
          $result = fontUnderline($nodeValue);
        break;
        case 'size':
          $result = fontSize($nodeValue, $attribute);
        break;
        case 'color':
          $result = fontColor($nodeValue, $attribute);
        break;
        case 'list':
          $result = makeList($nodeValue, $attribute);
        break;
        case 'li':
          $result = makeListItem($nodeValue);
        break;
        case 'url':
          $result = makeURL($nodeValue, $attribute);
        break;
        case 'email':
          $result = makeEMail($nodeValue, $attribute);
        break;
        case 'img':
          $result = makeImage($nodeValue);
        break;
        case 'hide':
          $result = makeHide($nodeValue, $attribute, $post['id']);
        break;
        case 'photo':
          $result = makePhoto($nodeValue);
        break;
        case 'table':
          $result = makeTable($nodeValue);
        break;
        case 'code':
          $result = makeCode($nodeValue);
        break;
        default:
          $result = $nodeValue;
        break;
      }

      return $result;

      }

      private function fontBold($value) {
        return '<span style="font-weight: bold;">' . $value . '</span>';
      }

      private function fontItalic($value) {
        return '<span style="font-style: italic;">' . $value . '</span>';
      }

      private function fontUnderline($value) {
        return '<span style="text-decoration: underline;">' . $value . '</span>';
      }

      private function fontSize($value, $parameter) {
        $size = intval($parameter) + 8 . 'pt';
        return '<span style="font-size: ' . $size . ';">' . $value . '</span>';
      }

      private function fontColor($value, $parameter) {
        return '<span style="color: ' . $parameter . ';">' . $value . '</span>';
      }

      private function makeList($value, $parameter) {
        switch ($parameter) {
          case '*':
            $parameter = 'ul';
          break;
          case '1':
            $parameter = 'ol';
          break;
          default:
            $parameter = 'ul';
          break;
        }
        return '<' . $parameter . '>' . $value . '</' . $parameter . '>';
      }

      private function makeListItem($value) {
        return '<li>' . $value . '</li>';
      }

      private function makeURL($value, $parameter) {
        $parameter = ($parameter == '') ? $value : $parameter;
        return '<a href="' . $parameter . '>' . $value . '</a>';
      }

      private function makeEMail($value, $parameter) {
        $parameter = ($parameter == '') ? $value : $parameter;
        return '<a href="mailto:' . $parameter . '>' . $value . '</a>';
      }

      private function makeImage($value) {
        return '<img scr="' . $value . '" alt="" />';
      }

      private function makeHide($value, $parameter) {
        //if (($bbuserinfo['showhideblocks']) && ($bbuserinfo['userid'] > 0)) {
        //  return '<table border="0" cellspacing="2"><tbody><tr><td colspan="2" style="width: 70%; border-top-style: solid; border-bottom-style: solid;  border-width: 2px; border-color: #009900; color: #009900; font-size: 10pt;">' . $value . '<p style="padding: 2px; color: #cc0000; font-size: 8pt;"><b>Внимание!</b> Публикация информации из хайд-блоков на других ресурсах без согласия администрации FoBo.ru ЗАПРЕЩЕНА! Нарушители будут немедленно забанены!</p></td></tr></tbody></table>';
        //} else {
          //return '<p style="width: 600px; border-top-style: solid; border-bottom-style: solid; border-width: 1px; border-color: #009900;"><table border="0" cellspacing="2" width="600"><tr><td colspan=\"2\" style=\"color: #009900; font-size: 10pt;"><b>Хайд-блок</b> - сектор закрытой информации, который может быть открыт за ' . $parameter . ' фобриков.<p style="padding: 2px; color: #cc0000; font-size: 8pt;"><b>Внимание!</b> Публикация информации из хайд-блоков на других ресурсах без согласия администрации FoBo.ru ЗАПРЕЩЕНА! Нарушители будут немедленно забанены!</p></td><td style="text-align: center"><button onclick="javascript:showHiddenText($count, $postid)">Открыть<br />(-' .$count . ' фобриков)</button></td></tr></tbody></table></p>';
        //}
        return '';
      }

      private function makePhoto($value) {
        return '<a target="_blank" onmouseout="togglePhotoPreview(event, \'\');" onmouseover="togglePhotoPreview(event, \'' . $value . '\');" href="' . $value . '"><img style="border-style: none;" src="/images/camera.jpg" alt="Посмотреть фотографию" /></a>';
      }

      private function makeTable($value) {
        $value = preg_replace("/^\s*(.*?)\s*\s*$/im", "\\1", $value);
        $value = preg_replace("/\|\|\s*\|\|/", "|| &nbsp; ||", $value);
        $value = preg_replace("/\n\s*\|\|/", "\n&nbsp; ||", $value);
        $value = preg_replace("/\|\|\s*\n/", "|| &nbsp;\n", $value);
        return '<table border="1" cellpadding="3" cellspacing="1"><tbody><tr><td><normalfont>' . preg_replace(array("/\n/", "/ \|\| /"), array('</normalfont></td></tr><tr><td><normalfont>', '</normalfont></td><td><normalfont>'), $value) . '</normalfont></td></tr></tbody></table>';
      }

      private function makeCode($value) {
        $value = '<pre>' . wordwrap($value) . '</pre>';
      }
      
      public function textToId($value) {
        return bin2hex($value);
      }
    
  }
?>
