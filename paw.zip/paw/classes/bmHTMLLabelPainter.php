<?php

  class bmHTMLLabelPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      if (($result = $control->callEventHandler($control->onCustomDrawCaption, array("caption" => $control->caption))) === false) {
        $result = $control->caption;
      }
      return $result;
      
    }

  }

?>
