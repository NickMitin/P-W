<?php
  
  class bmCoolBarStyles extends bmCustomControlStyles {
    
  }
  
?>