<?php

  abstract class bmHTMLInplaceCustomEditPainter extends bmCollectionItem {
    
    public $className = "bmHTMLCustomControlPainter";
    
    abstract function draw($control, $dataControl, $dataCollection, $style);
    
  }

?>
