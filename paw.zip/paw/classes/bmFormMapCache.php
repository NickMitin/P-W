<?php
  
  class bmFormMapCache extends bmCollection {
    
    public $collectionItemClass = "bmFormMap";
    public $keyPropertyName = "formName";
    public $shouldSerialize = false;
    
    function getMapFileByName($formName) {
      $fileSystem = $this->application->fileSystem;
      if ($fileSystem->fileExists($this->application->userInfo->id . $this->application->session->hash . $formName)) {
        return $fileSystem->getFileName($this->application->userInfo->id . $this->application->session->hash . $formName);  
      } else {
        return "./forms/bm" . $formName . ".xml";
      }
      return false;
    }
    
    function mapExists($formName) {
      return (boolean)$this->getMapByName($formName);
    }
    
    function add($keyValue) {
      if (($fileName = $this->getMapByName($keyValue)) !== false) {
        $formMap = parent::add($keyValue);
        $formMap->loadXML($fileName);
        return $formMap;
      } else {
        return false;
      }
    }
    
    function getFormMap($formName) {
      if ($this->exists($formName)) {
        return $this->items[$formName];
      } elseif (($formMap = $this->add($formName)) !== false) {
        return $formMap;
      }
      return false;
    }
    
  }
  
?>