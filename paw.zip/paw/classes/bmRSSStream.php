<?php
  
  class bmRSSStream extends bmCustomForm {

    public $boundData = null;
    public $content = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("encoding", pbValue, "utf-8");
      $this->serializeProperty("contentType", pbValue, "application/rss+xml");
      
      $this->serializeProperty("title", pbValue, "RSS");
      $this->serializeProperty("link", pbValue);
      $this->serializeProperty("description", pbValue);
      $this->serializeProperty("author", pbValue);
      
      $this->serializeProperty("onChannelItemLoading", pbValue);
      
      $this->boundData = $this->createOwnedObject("bmDataSource", array("name" => "boundData"));
      $this->content = new DOMDocument("1.0", $this->encoding);

    }
    
    public function load() {
      
      $this->boundData->loadObjects();
      $content = $this->content;
      $rss = $content->createElement("rss");
      $rss->setAttribute("version", "2.0");
      $content->appendChild($rss);
      $channel = $content->createElement("channel");
      $rss->appendChild($channel);
      $channelItem = $content->createElement("title", $this->title);
      $channel->appendChild($channelItem);
      $channelItem = $content->createElement("link", $this->link);
      $channel->appendChild($channelItem);
      $channelItem = $content->createElement("description", $this->description);
      $channel->appendChild($channelItem);
      $channelItem = $content->createElement("generator", "p@w-engine 0.0.0.1 RC1");
      $channel->appendChild($channelItem);
      foreach ($this->boundData->dataObjects->items as $object) {
        if (($this->callEventHandler($this->onChannelItemLoading, array("channel" => $channel, "dataObject" => $object)) === false)) {
          $this->addChannelItem($channel, $object->title, $object->link, $object->description);
        }
      }
      
    }
    
    public function addChannelItem($channel, $title, $link, $description, $author = "", $pubDate = "", $guid = "") {
      $content = $this->content;
      $channelItem = $content->createElement("item");
      $channel->appendChild($channelItem);
      $channelItemItem = $content->createElement("title", $title);
      $channelItem->appendChild($channelItemItem);
      $channelItemItem = $content->createElement("link", $link);
      $channelItem->appendChild($channelItemItem);
      $channelItemItem = $content->createElement("description", $description);
      $channelItem->appendChild($channelItemItem);
      if ($author) {
        $channelItemItem = $content->createElement("author", $author);
        $channelItem->appendChild($channelItemItem);
      }
      if ($pubDate) {
        $channelItemItem = $content->createElement("pubDate", $pubDate);
        $channelItem->appendChild($channelItemItem);
      }
      if ($guid) {
        $channelItemItem = $content->createElement("guid", $guid);
        $channelItem->appendChild($channelItemItem);
      }
    }
    
    public function draw() {
      
      return parent::draw();
      
    }

  }

?>