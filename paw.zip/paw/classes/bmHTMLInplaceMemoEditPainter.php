<?php

  class bmHTMLInplaceMemoEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    public function draw($control, $dataControl, $dataCollection, $style) {
      $result = "";
      switch ($dataControl->mode) {
        case dcmView:
          $result = $control->value;
        break;
        case dcmEdit:
          //$result = "<textarea cols=\"1\" rows=\"1\" style=\"width: 100%; height: 100%;\">~</textarea>";
          $result = "<textarea cols=\"1\" rows=\"1\" style=\"width: 98%; height: 98%;\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[" . $control->keyValue . "]\">" . $this->application->validator->formatXMLValue($control->value) . "</textarea>";
        break;
      }
      return $result;
    }

  }

?>
