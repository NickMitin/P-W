<?php
  
  class bmInplaceCheckBoxEditStyles extends bmCustomControlStyles {
    
  }
  
?>