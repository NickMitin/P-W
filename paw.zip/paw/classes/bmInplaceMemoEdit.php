<?php

  class bmInplaceMemoEdit extends bmCustomMemoEdit {

  }

?>