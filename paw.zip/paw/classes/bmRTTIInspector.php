<?php

  define('rttiMode', 2);
  
  class bmRTTIInspector extends bmCustomControl {
    
    public $columns = null;
    public $boundData = null;
    public $mode = rttiMode;

    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->boundData = $this->createOwnedObject("bmComponentMap", array("name" => "boundData"));
      $this->columns = $this->createOwnedObject("bmDataColumns", array("name" => "columns"));

    }
    
    public function loadProperties() {
      $this->columns->clear();
      foreach ($this->boundData->propertyMaps->items as $propertyMap) {
        $column = $this->columns->add($propertyMap->propertyName, $propertyMap->editClass);
        $column->caption = $propertyMap->propertyName;
      }
    }
    
  }
  
?>
