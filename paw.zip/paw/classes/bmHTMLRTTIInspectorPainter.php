<?php
  
  class bmHTMLRTTIInspectorPainter extends bmHTMLCustomDataControlPainter {
    
    function drawColumnHeader($control, $column) {
      
      $styles = $control->styles;
      
      $caption = (mb_strlen($column->caption) > 10) ? mb_substr($column->caption, 0, 7) . "..." : $column->caption; 
      $result = "<td title=\"$column->caption\" style=\"cursor: default;\" class=\"$styles->columnHeader\">" . $caption . "</td>\n";
                                                                              
      return $result;
      
    }                                                                   
    
    function drawControl($control) {
      
      $propertyMaps = $control->boundData->propertyMaps;
      
      $result = "";
      $result .= "<table style=\"width: 100%;\" cellpadding=\"0\" cellspacing=\"0\">";
      foreach ($control->columns->items as $column) {
        $result .= "<tr>";
        $result .= $this->drawColumnHeader($control, $column);
        $propertyName = $column->propertyName;
        $column->inplaceEdit->keyValue = "1";
        $column->inplaceEdit->value = $control->boundData->component->$propertyName;
        $inplaceEdit = $column->inplaceEdit;
        $editClass = get_class($inplaceEdit);
        switch ($editClass) {
          case "bmInplaceLookupEdit":
            $inplaceEdit->boundData = $this->application->getSystemData($propertyName);
            $inplaceEdit->keyPropertyName = "id";
            $inplaceEdit->displayPropertyName = "valueName";
            $inplaceEdit->loadData();
          break;
        }
        $result .= "<td>" . $column->inplaceEdit->painter->draw($column->inplaceEdit, $control, "updatedValues", "default") . "</td>";
        $result .= "</tr>";
      }
      if ($control->mode == dcmEdit) {
        $result .= "<tr><td colspan=\"2\">";
        $result .= "<input type=\"hidden\" name=\"application.switchForm\" value=\"" . $control->ownerForm->name . "\" />";
        $result .= "<input type=\"hidden\" name=\"" . $control->boundData->getComponentString() . ".update\" value=\"1\" /><button type=\"submit\">Update</button>";
        $result .= "</td></tr>";
      }
      $result .= "</table>";
      return $result;
    }
    
  }
  
?>
