<?php

  class bmHTMLClassInspectorPainter extends bmHTMLStandaloneControlPainter {

    function drawProperties() {

      $result = "";

      foreach ($this->control->activeProto->properties->items as $property) {
        $result .= $this->drawProperty($property);
      }

      return $result;

    }

    function drawProperty($property) {

      $result = "<tr><td>" . $property->propertyName . "</td>";



    }

    function drawControl() {
      $result = "<table>";
      $this->drawProperties();
      $result .= "</table>\n";
      return $result;
    }

  }

?>