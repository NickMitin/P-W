<?php
  
  class bmInplaceHyperLinkEditStyles extends bmCustomControlStyles {
    
  }
  
?>
