<?php
  
  class bmFlashMovie extends bmCustomFlashMovie {
    
  }
  
?>