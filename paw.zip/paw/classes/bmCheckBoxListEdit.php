<?php

  class bmCheckBoxListEdit extends bmCustomCheckBoxListEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
