<?php

  define("coAuto", "auto");
  define("coHidden", "hidden");
  define("coScroll", "scroll");
  define("coVisible", "visible");
  
  define("cpAbsolute", "absolute");
  define("cpFixed", "fixed");
  define("cpRelative", "relative");
  
  define('rbTopLeft', 1);
  define('rbTopRight', 2);
  define('rbBottomLeft', 4);
  define('rbBottomRight', 8);
  define('rbAll', 15);
  
  define('btContainer', 1);
  define('btContent', 1);

  abstract class bmCustomControl extends bmComponent {
    public $isControl = true;
    
    public $styles = null;
    public $painter = null;
    public $clientEvents = null;

    function constructor($application, $owner, $parameters) {
      
      $rt = microtime(true);

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("tabOrder", pbValue, 0);
      $this->serializeProperty("localeDependent", pbValue, false);
      $this->serializeProperty("left", pbValue, "auto");
      $this->serializeProperty("top", pbValue, "auto");
      $this->serializeProperty("right", pbValue, "auto");
      $this->serializeProperty("bottom", pbValue, "auto");
      $this->serializeProperty("width", pbValue, "auto");
      $this->serializeProperty("minWidth", pbValue, 0);
      $this->serializeProperty("height", pbValue, "auto");
      $this->serializeProperty("position", pbValue, cpAbsolute);
      $this->serializeProperty("visible", pbValue, true);
      $this->serializeProperty('data', pbValue);
      $this->serializeProperty('hint', pbValue, '');
      $this->serializeProperty("childrenOverflow", pbValue, coVisible);
      
      $this->serializeProperty('borderRadius', pbValue, 0);
      $this->serializeProperty('borderWidth', pbValue, 0);
      $this->serializeProperty('borderType', pbValue, btContainer);
      $this->serializeProperty('roundBorders', pbValue, rbAll);
    
      $this->serializeProperty('resourceName', pbValue, $this->name);
      $this->serializeProperty('backgroundColor', pbValue);
      $this->serializeProperty('transparentColor', pbValue);
      $this->serializeProperty('completeRedraw', pbValue, false);

      $className = get_class($this); 
      $stylesClass = $className . "Styles";
      $painterClass = preg_replace("/^(bm)(.+)$/", "\\1" . $this->application->renderer->mainPrefix . "\\2Painter", $className);
      $this->styles = $this->createOwnedObject($stylesClass, array("name" => "styles"));
    
      if (array_key_exists($painterClass, $this->application->painterCache->items)) {
        $this->painter = $this->application->painterCache->items[$painterClass];
      } else {
        $this->application->painterCache->collectionItemClass = $painterClass;
        $this->painter = $this->application->painterCache->add($painterClass);
      }
      
      $this->clientEvents = $this->createOwnedObject("bmClientEvents", array("name" => "clientEvents"));
      
      $rt = microtime(true) - $rt;
      #print $this->name . ',' . $rt . '<br/>';

    }

    public function draw() {
      return $this->painter->draw($this);
    }
    
    public function getClientPropertyValues() {
      return 'this.data = "' . addslashes($this->data) . '";';
    }

  }

?>
