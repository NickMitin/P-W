<?php

  class bmTextEdit extends bmCustomTextEdit {
    
    public $hasClientMirror = 1;
  
  }

?>
