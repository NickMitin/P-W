<?php

  class bmCustomFileEdit extends bmCustomEdit {
    
    //public $fileEdit = true;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("acceptMimeTypes", pbValue, "*/*");
      $this->serializeProperty("maximumSize", pbValue, 0);
      
    }
    
    public function valueSetter($value) {
      //TODO Error ReadOnly
      return true;
    } 

  }

?>
