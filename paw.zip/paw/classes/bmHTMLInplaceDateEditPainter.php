<?php

  class bmHTMLInplaceDateEditPainter extends bmHTMLInplaceCustomEditPainter {
    
    function draw($control, $dataControl, $dataCollection, $style) {
      $result = "";
      switch ($dataControl->mode) {
        case dcmView:
          $result = date($control->format, $control->value);
          //$result = $control->value;
        break;
        case dcmEdit:
          $result = "<input type=\"text\" style=\"width: 100%;\" class=\"$style\" name=\"" . $dataControl->boundData->getComponentString() . ".$dataCollection." . $control->owner->propertyName . "[$control->keyValue]\" value=\"" . $this->application->validator->formatOutput($control->value, true) . "\"/>";
        break;
      }
      return $result;
    }

  }

?>
