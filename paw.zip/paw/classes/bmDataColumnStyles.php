<?php
  
  class bmDataColumnStyles extends bmCustomControlStyles {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('cell', pbValue, 'default');
      $this->serializeProperty('firstCell', pbValue, 'default');
      $this->serializeProperty('lastCell', pbValue, 'default');

    }
    
  }
  
?>
