<?php

  class bmFlash extends bmCustomFlash {
    
    public $hasClientMirror = 1;

  }

?>
