<?php

  class bmCustomForm extends bmCustomControl {
    
    public $shouldCompile = false;
    public $allComponents = array();
    public $originalName = '';
    public $resetProperties = array(); 
    
    public function constructor($application, $owner, $parameters) {
      
      $this->map = new DOMDocument();
      do {
        $result = $this->map->load($parameters['fileName']);
      } while ($result === false);
      
      $this->node = $this->map->documentElement;
      parent::constructor($application, $owner, $parameters);   
      
      $this->serializeProperty('onDrawing', pbValue);
      $this->serializeProperty('onInitialize', pbValue);
      $this->serializeProperty('container', pbValue);
      
      if (array_key_exists('container', $parameters)) {
        if ($parameters['container']) {
          $this->container = $parameters['container'];
        }
      }
      
      foreach($this->resetProperties as $propertyName => $value) {
        $this->$propertyName = $value;
      }
      
    }
    
    public function getter($propertyName) {
      if (array_key_exists($propertyName, $this->allComponents)) {
        return $this->allComponents[$propertyName];
      } else {
        return parent::getter($propertyName);
      }
    }
    
    public function serialize($compile = false) {
      
      if ($compile) {
        $this->map->save('./forms/bm' . $this->name . '.xml');
      }
      $userId = $this->application->textUtils->textToHex($this->application->userInfo->id);
      $fileName = './sessions/' . $userId . '-' . $this->application->session->id . '-' . 'bm' . $this->name; 
      do {
        $result = $this->map->save($fileName . '.xml'); 
      } while ($result === false);
      
    }
    
    public function draw() {
      
      $this->callEventHandler($this->onDrawing, null);
      
      return parent::draw();
      
    }

  }


?>
