<?php
  
  class bmPainterCache extends bmCollection {
  
    public $collectionItemClass = "bmCustomControlPainter";
    public $keyPropertyName = "className";
    
  }
  
?>