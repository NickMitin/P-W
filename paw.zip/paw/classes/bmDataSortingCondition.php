<?php

  class bmDataSortingCondition extends bmCollectionItem {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("propertyName", pbValue);
      $this->serializeProperty("sortOrder", pbValue, soAscending);

    }

  }

?>
