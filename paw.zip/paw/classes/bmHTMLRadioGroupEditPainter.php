<?php
  
  class bmHTMLRadioGroupEditPainter extends bmHTMLStandaloneControlPainter {
      
    public function drawControl($control) {
      
      $result = '';
      
      $result = $this->drawRadioButtons($control);
      
      
      foreach ($control->components as $component) {
        if ($component instanceof bmCustomControl) {
          $result .= $component->draw();
        }
      }
      return $result;
      
    }
    
    public function drawRadioButtons($control) {
      $orientationStyle = 'bmRadioGroupEditHorizontal';
      switch ($control->orientation) {
        case rgeoVertical:
          $orientationStyle = 'bmRadioGroupEditVertical';
        break;
        case rgeoHorizontal:
          $orientationStyle = 'bmRadioGroupEditHorizontal';
        break;
      }
      $result = '<ul class="bmRadioGroupEditButtons">';
      foreach($control->options->items as $item) {
        $result .= '<li class="' . $orientationStyle . ' ' . $control->styles->item . '"><input type="radio" name="' . $control->getComponentString() . '.value" value="' . $item->value . '"' . ($item->selected ? ' checked="checked"' : '') . '/>' . $item->caption . '</li>';
      }
      $result .= '</ul>';
      return $result;
    }
    
  }
  
?>
