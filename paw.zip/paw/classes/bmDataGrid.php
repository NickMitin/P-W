<?php

  class bmDataGrid extends bmCustomDataGrid {
    
    public $hasClientMirror = 1;

  }

?>
