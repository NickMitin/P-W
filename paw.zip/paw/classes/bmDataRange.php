<?php
  
  class bmDataRange extends bmComponent {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("start", pbValue, 0); 
      $this->serializeProperty("length", pbValue, 0); 

    }
    
  }
  
?>