<?php

  class bmMemoEdit extends bmCustomMemoEdit {
    
    public $hasClientMirror = 1;

  }

?>
