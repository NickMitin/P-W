<?php
  
  class bmInplaceTextEditStyles extends bmCustomControlStyles {
    
  }
  
?>