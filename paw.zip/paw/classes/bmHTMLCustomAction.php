<?php
  
  abstract class bmHTMLCustomAction extends bmCustomAction {
    
    abstract function toHTML();
    
  }
  
?>
