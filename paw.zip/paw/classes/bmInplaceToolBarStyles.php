<?php
  
  class bmInplaceToolBarStyles extends bmCustomControlStyles {
    
  }
  
?>
