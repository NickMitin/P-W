<?php

  define("psPublic", 1);
  
  class bmPersistentProperty extends bmObject {
    
    public $scope = psPublic;
    public $fNode = null;
    private $propertyName = '';
    private $type = pbValue;
    private $fValue = null;
    private $fDefaultValue = null;
    private $fInitialValue = null;
    public $fromXML = false;
    
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->propertyName = $parameters['name'];
      if ($owner->fNode != null) {
        $xPath = new DOMXPath($this->owner->map);                      
        $propertyMaps = $xPath->query('property[@name="' . $parameters['name'] . '"]', $owner->node);
        if ($propertyMaps->length) {
          $this->node = $propertyMaps->item(0);
          $this->type = $this->fNode->getAttribute('type');
          if ($this->type == pbSet) { 
            $this->applySetValue(); 
          } else {
            $this->value = $this->fNode->nodeValue;
          }
          $this->fInitialValue = $this->value;
          $this->fromXML = true;
        }
      }
      if (!$this->fromXML) {
        $this->type = $parameters["type"];
        $this->fDefaultValue = $parameters["defaultValue"];
        $this->fValue = $this->fDefaultValue;
        $this->fInitialValue = $this->fDefaultValue;
      }
      $this->initialValue = $this->value;
    }
    
    private function applySetValue() {
      if ($this->fNode->childNodes->length > 0) {
        foreach ($this->fNode->childNodes as $node) {
          $this->fValue[$node->getAttribute('key')] = $node->nodeValue;
        }
      } else {
        $this->fValue = array();
      }
    }
    
    public function getter($propertyName) {
      switch($propertyName) {
        case "value":
          return $this->fValue;
        break;
        case "defaultValue":
          return $this->fDefaultValue;
        break;
        case "initialValue":                   
          return $this->fInitialValue;
        break;
        case "node":
          if ($this->fNode == null) {
            $this->fNode = $this->owner->map->createElement("property");          
            $this->fNode->setAttribute("name", $this->propertyName);
            $this->fNode->setAttribute("type", $this->type);
            $this->owner->node->appendChild($this->fNode);            
          } 
          return $this->fNode;
        break;
      }
    }
    
    public function setter($propertyName, $value) {
      $validator = $this->application->validator;
      switch($propertyName) {
        case "value":
          if ($value != $this->fDefaultValue) {
            switch ($this->type) {
              case pbValue:
                $this->node->nodeValue = $validator->formatXMLValue($value);
                $this->fValue = $value;
              break;
              case pbReference:
                if (is_object($value)) {
                  $this->node->nodeValue = $value->getComponentString();
                  $this->fValue = $value;
                } else {
                  $currentObject = $this->application;
                  $this->node->nodeValue = $validator->formatXMLValue($value); 
                  $value = substr($value, 12);
                  while (preg_match("/^(\w+)\.(.*)$/", $value, $matches)) {
                    if (($currentObject instanceof bmCustomForm) && array_key_exists($matches[1], $currentObject->allComponents)) {
                      $currentObject = $currentObject->allComponents[$matches[1]];
                    } elseif (array_key_exists($matches[1], $currentObject->components)) {
                      $currentObject = $currentObject->components[$matches[1]];
                    } elseif ($currentObject->$matches[1]) {
                      $currentObject = $currentObject->$matches[1];
                    }
                    $value = $matches[2];
                  }
                  if ($currentObject instanceof bmCollection) {
                    $this->fValue = $currentObject->items[$value];
                  } elseif (($currentObject instanceof bmCustomForm) && array_key_exists($value, $currentObject->allComponents)) {
                    $this->fValue = $currentObject->allComponents[$value];
                  } elseif (array_key_exists($value, $currentObject->components)) {
                    $this->fValue = $currentObject->components[$value];
                  } elseif (($this->fValue = $this->application->getForm($value)) === false) {
                    $this->fValue = null;
                  }
                }
              break;
              case pbSet:
                $node = $this->node;
                while ($node->childNodes->length > 0) {
                  $node->removeChild($node->firstChild);
                }
                if (is_array($value)) {
                  $this->fValue = $value;
                } else {
                  $this->fValue = split(',', $value);
                }
                $map = $this->owner->map;
                foreach ($this->fValue as $key => $value) {
                  $item = $map->createElement('item');
                  $item->setAttribute('key', $key);
                  $item->nodeValue = $validator->formatXMLValue($value);
                  $node->appendChild($item);
                }    
              break;
            }
          } else {
            $this->fValue = $value;
            if ($this->fNode != null) {
              $this->owner->fNode->removeChild($this->fNode);
              $this->fNode = null;
            }
          }
        break;
        case "node":
          $this->fNode = $value;
        break;
      }
    }         
    
  }
  
?>
