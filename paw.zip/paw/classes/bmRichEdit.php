<?php

  class bmRichEdit extends bmCustomRichEdit {
    
    public $hasClientMirror = 1;
    
  }
  
?>
