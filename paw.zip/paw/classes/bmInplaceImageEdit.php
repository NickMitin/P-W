<?php

  class bmInplaceImageEdit extends bmCustomImageEdit {
    
    public $value = null;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('width', pbValue);
      $this->serializeProperty('height', pbValue);
      $this->deletePersistentProperty('value');

    }
    
  }

?>
