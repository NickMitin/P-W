<?php
  
  class bmTabControlStyles extends bmCustomControlStyles {
    
  }
    
  
?>
