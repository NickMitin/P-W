<?php

  class bmHTMLErrorHandler extends bmCustomErrorHandler {

    function toHTML() {
      $result = '<script type="text/javascript">';
      $errorStrings = array();
      foreach($this->errorGroups->items as $errorGroup) {
        foreach ($errorGroup->errors->items as $error) {
          $errorCode = ($error->code) ? ' (Error code: ' . $error->code . ')' : '';
          if ($errorGroup->groupName == 'default') {
            $result .= 'alert("' . addslashes($error->text) . $errorCode . '");';
          } else {
            $errorText = addslashes($error->text) . $errorCode . '\n';
            if (array_key_exists($errorGroup->groupName, $errorStrings)) {
              $errorStrings[$errorGroup->groupName] .= $errorText;
            } else {
              $errorStrings[$errorGroup->groupName] = $errorText;
            }
          }
        }
        
        
      }
      foreach ($errorStrings as $key => $errorString) {
        $description = $this->errorGroups->items[$key]->description;
        $result .= 'alert("' . $description . '\n' . $errorString . '");';
      }
      $result .= '</script>';
      return $result;
    }
    
    
    
  }

?>
