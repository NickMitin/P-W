<?php
  
  class bmDataRowToolBarButtons extends bmCollection {
    
    public $collectionItemClass = "bmDataRowToolBarButton";
    public $keyPropertyName = "caption";
    
  }
  
?>
