<?php
  
  class bmCustomCalendar extends bmCustomControl {
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $time = gmmktime();
      $time = $time - $time % 86400; 

      $this->publishProperty('date', pbValue, $time);
      $this->publishProperty('action', pbValue);

    }
    
    function dateSetter($value) {                                                  
      
      $value = intval($value);
      
      if ($value >= 0) {
        
        $this->date = $value;
        return true;
          
      }
      
      return false;
      
    }
    
    
  }
  
?>
