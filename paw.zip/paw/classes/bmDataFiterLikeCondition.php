<?php

  class bmDataFilterLikeCondition extends bmCustomDataFilterCondition {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

    }

  }

?>
