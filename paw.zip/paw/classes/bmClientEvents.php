<?php
  
  class bmClientEvents extends bmPersistentObject {
    
    public $events = array();
    
    function serializeProperty($name, $passBy, $defaultValue = null) {
      parent::serializeProperty($name, $passBy, $defaultValue);
      $this->events[$name] = $name;
    }
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('click', pbValue);
      $this->serializeProperty('keypress', pbValue);
      $this->serializeProperty('mouseover', pbValue);
      $this->serializeProperty('mouseout', pbValue);
      $this->serializeProperty('mousemove', pbValue);
      $this->serializeProperty('change', pbValue);
    }
    
  }
  
?>
