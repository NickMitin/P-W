<?php
  
  class bmDataObjectMap extends bmCollectionItem {
    
    public $propertiesMap = null;
    
    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      
      $this->serializeProperty("alias", pbValue);
      $this->serializeProperty("objectName", pbValue);
      $this->propertiesMap = $this->createOwnedObject("bmDataObjectPropertiesMap", array("name" => "propertiesMap"));
      
    }
    
  }
  
?>
