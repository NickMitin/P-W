<?php


  header('Cache-Control: no-cache', true);
  header('Pragma: no-cache', true);
  header('Expires: Mon, 26 Jul 1997 05:00:00 GMT', true);

  define('amRelease', 1);
  define('amDebug', 2);
  
   define('rtGraphic', 1);
   
   define('aaAllowAll', 1);
   define('aaAllowRegistered', 2);
  
  class bmApplication extends bmComponent {
    
    public $createTime = 0;
    public $processRequestTime = 0;
    public $output = '';
                                              
    private $xmlFile = 'config.xml';
    private $nextId = null;
    private $debugString = null; 
    private $surfTracker = null;
    private $forms = array(); 
    private $controlInstance = null;

    private $fErrorHandler = null;
    private $myFormInfo = null;
    private $fMailer = null;
    private $fFormCompiler = null;
    private $fDateUtils = null;
    private $fTextUtils = null;
    private $fActions = null;
    private $fValidator = null;
    private $fCGI = null;
    private $fPainterCache = null;
    private $fFileStorage = null;
    private $fFileSystem = null;
    private $fSession = null;
    private $fDataLinks = null;
    private $fMainLink = null;
    private $fUserInfo = null;
    private $fClientScripts = null;
    private $fStyleSheets = null;
    private $systemDataCache = array();
    
    public $renderer = null;
    public $preventDraw = false;

    public function constructor($application, $owner, $parameters) {

      $this->map = new DOMDocument();
      $this->map->load('./' . $this->xmlFile);
      $this->node = $this->map->documentElement;
      
      mb_internal_encoding('utf-8');
      mb_regex_encoding('utf-8');

      parent::constructor($this, $owner, array('name' => 'application'));
      
      $this->serializeProperty('locales', pbSet);
      $this->serializeProperty('locale', pbValue, 'en-us');
      $this->serializeProperty('autoLocale', pbValue, false);
      $this->serializeProperty('defaultForm', pbValue, 'fIndex');
      $this->serializeProperty('loginForm', pbValue, 'fLogin');
      $this->serializeProperty('access', pbValue, aaAllowAll);
      
      if ($this->autoLocale) {
        $locale = $this->locale;
        if (array_key_exists('HTTP_ACCEPT_LANGUAGE', $_SERVER)) {
          $language = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
          $languages = split(',', preg_replace('/;q=\d\.\d/', '', $language));
          foreach ($languages as $language) {
            if (in_array($language, $this->locales)) {
              $locale = $language;
              break;
            }
          }
        }
        $this->locale = $this->fixLocale($locale);
      }
      
      $GLOBALS['application'] = $this;
      
      $this->serializeProperty('rendererClass', pbValue, 'bmHTMLOutputRenderer');  
      $this->renderer = $this->createOwnedObject($this->rendererClass, array('name' => 'renderer'));
      
      $this->publishMethod('switchForm');
      $this->publishMethod('executeAction');
      $this->publishMethod('createForm');
      $this->publishMethod('getFile');
      $this->publishMethod('flushSessions');
      $this->publishMethod('getUserInfo');
      
      $this->serializeProperty('title', pbValue, 'P@W-Engine');
      $this->serializeProperty('mainDataBase', pbValue, 'database');
      $this->serializeProperty('mode', pbValue, amRelease);
      $this->serializeProperty('path', pbValue, '/'); 

      $this->nextId = $this->createOwnedObject('bmDataSource', array('name' => 'nextId'));
      $this->nextId->boundDataMap->objectName = 'nextId';
      $object = $this->nextId->boundDataMap->dataObjectMaps->add('nextId');
      $propertyMap = $object->propertiesMap->add('currentId');
      $propertyMap->fieldName = 'currentId';
      
      $this->surfTracker = $this->createOwnedObject('bmDataSource', array('name' => 'surfTracker'));
      $this->surfTracker->boundDataMap->objectName = 'surfTracker';
      $object = $this->surfTracker->boundDataMap->dataObjectMaps->add('surfTracker');
      $propertyMap = $object->propertiesMap->add('ip');
      $propertyMap->fieldName = 'ip';
      $propertyMap = $object->propertiesMap->add('referer');
      $propertyMap->fieldName = 'referer';
      $propertyMap = $object->propertiesMap->add('uri');
      $propertyMap->fieldName = 'uri';
      $propertyMap = $object->propertiesMap->add('queryString');
      $propertyMap->fieldName = 'queryString';
      $propertyMap = $object->propertiesMap->add('userAgent');
      $propertyMap->fieldName = 'userAgent';
      $propertyMap = $object->propertiesMap->add('time');
      $propertyMap->fieldName = 'time';
      
      $currentTrace = $this->surfTracker->newObject();
      $currentTrace->ip = $this->cgi->getIP();
      $currentTrace->referer = $this->cgi->getReferer();
      $currentTrace->uri = $this->cgi->getURI();
      $currentTrace->queryString = $this->cgi->getQueryString();
      $currentTrace->userAgent = $this->cgi->getUserAgent();
      $currentTrace->time = time();
      $this->surfTracker->saveObject($currentTrace->id);
      
      if ($this->mode == amDebug) {
        $this->debugString = $this->createOwnedObject('bmDataSource', array('name' => 'debugString'));
        $this->debugString->boundDataMap->objectName = 'debugString';
        $object = $this->debugString->boundDataMap->dataObjectMaps->add('debugString');
        $propertyMap = $object->propertiesMap->add('string');
        $propertyMap->fieldName = 'string';
        $propertyMap = $object->propertiesMap->add('date');
        $propertyMap->fieldName = 'date';
      }
      
      $this->processRequest();
      
      $this->initialize();
      
      $this->serialize();
      
      if ($this->preventDraw) {
        print $this->output;
      } else {
        $this->draw();
      } 

    }
    
    private function initialize() {
      
      $this->application->getForm('fTemplateContainer');
      $formName = $this->session->formName;
      if (true) {
      }
      
      $this->application->getForm($formName);
      
      foreach($this->forms as $form) {
        $form->callEventHandler($form->onInitialize, null);
      }
       
      if ($formName != $this->session->formName) {
        $form = $this->application->getForm($this->session->formName);
        $form->callEventHandler($form->onInitialize, null);
      }
      
      if (method_exists($this->fTemplateContainer, 'genericInitialize')) {
        $this->fTemplateContainer->genericInitialize();
      }
      
    }
    
    private function fixLocale($locale) {
      $result = $locale;
      switch ($locale) {
        case 'ru':
        case 'ru-RU':
          $result = 'ru-ru';
        break;
        case 'en':
        case 'en-en':
        case 'en-US':
        case 'en-EN':
          $result = 'en-us';
        break;
      }
      return $result;
    }
    
    public function getSystemData($dataSourceName) {
      if (!array_key_exists($dataSourceName, $this->systemDataCache)) {
        $dataSource = $this->createOwnedObject('bmDataSource', array('name' => $dataSourceName));
        $dataSource->dataStorage = engineRoot . 'data/';
        $dataSource->boundDataMap->objectName = $dataSourceName;
        $object = $dataSource->boundDataMap->dataObjectMaps->add($dataSourceName);
        $propertyMap = $object->propertiesMap->add('valueName');
        $this->systemDataCache[$dataSourceName] = $dataSource;
      }
      return $this->systemDataCache[$dataSourceName];
    }
    
    public function addDebugString($string, $filename = 'debug', $filemode = 'a+') {
      /*if ($this->mode == amDebug) {
        $debugString = $this->debugString->newObject($this->getNextId());
        $debugString->string = $string;
        $debugString->date = time();
        $this->debugString->saveObject($debugString->id);
        
      } else {
        $this->errorHandler->addError(0, 'The "addDebugString" operation can only be done in debug mode!');
      }*/
      $file = fopen('./' . $filename . '.txt', $filemode);
      fwrite($file, $string . "\n");
      fclose($file);
      
    }
    
    public function getResource($object, $resourceName, $type) {
      
      $className = get_class($object);
      
      $result = null;
      $extension = '';
      
      switch ($type) {
        case rtGraphic:
          $extension = '.png';
        break;
      }
      if (file_exists(engineRoot . 'resources/' . $className . '/' . $resourceName . $extension)) {
        $result = $this->path . 'resources/' . $className . '/' . $resourceName . $extension;
      } elseif (file_exists('./userResources/' . $resourceName . $extension)) {
        $result = $this->path . 'userResources/' . $resourceName . $extension;
      }
      
      return $result;
      
    }
    
    private function preventCaching() {
      header('pragma: no-cache', true);
      header('cache-control: no-cache, must-revalidate', true);
      header('expires: Mon, 26 Jul 1997 05:00:00 GMT', true);
    }
    
    public function getUserInfo() {
      $this->preventCaching();
      print 'this.id = \'' . $this->userInfo->id . '\';';
      exit();
    }

    public function getNextId() {
      $idObject = $this->nextId->loadObject(1);
      $result = $idObject->currentId;
      $idObject->currentId += 1;
      $this->nextId->saveObject(1);
      return $result;
    }

    function processRequest() {
      $clientRequest = $this->cgi->request;
      foreach ($clientRequest as $key => $value) {
        //$key = preg_replace('/^[_\s]+(\w)/is', '\\1', $key); //BROWSER FIX: OPERA 9b1;
        if (strpos($key, 'application_') !== false) {
          $key = substr($key, 12);
          parent::handleRequest($key, $value);
        }
        unset($clientRequest[$key]);
      }
    }
    
    function getComponent($componentName) {
      if (($result = $this->getForm($componentName)) === false) {
        $result = parent::getComponent($componentName);
      }
      return $result;
    }

    public function serialize() {
      foreach($this->forms as $form) {
        $compile = (($this->mode == amDebug) && ($form->shouldCompile));
        $form->serialize($compile);
      }
      $this->userInfo->save();
      $this->session->save();
    }
    
    public function flushSessions() {
      $sessionIterator = new DirectoryIterator('./sessions/');
      foreach($sessionIterator as $file) { 
        if (!$file->isDot()) { 
          unlink($file->getPathname());
        }
      }
      
    }
    
    public function switchForm($formName) {
      if ($this->getFormMapFile($formName, $container) !== false) {
        $this->session->formName = $formName;
        return true;
      }
      $this->errorHandler->addError(0, 'The "' . $formName . '" does not exist!');
      return false;
    }

    public function getter($propertyName) {
      switch ($propertyName) {
        case 'mailer':
          if ($this->fMailer == null) {
            $this->fMailer = $this->createOwnedObject('bmMailer', array('name' => 'mailer'));
          }
          return $this->fMailer;
        break;
        case 'actions':
          if ($this->fActions == null) {
            $this->fActions = $this->createOwnedObject('bmActions', array('name' => 'actions'));
          }
          return $this->fActions;
        break;
        case 'clientScripts':
          if ($this->fClientScripts == null) {
            $this->fClientScripts = $this->createOwnedObject('bmClientScripts', array('name' => 'clientScripts'));
          }
          return $this->fClientScripts;
        break;
        case 'compiler':
          if ($this->fFormCompiler == null) {
            $this->fFormCompiler = $this->createOwnedObject('bmCompiler', array('name' => 'compiler'));
          }
          return $this->fFormCompiler;
        break;
        case 'styleSheets':
          if ($this->fStyleSheets == null) {
            $this->fStyleSheets = $this->createOwnedObject('bm' . $this->renderer->stylePrefix . 'StyleSheets', array('name' => 'styleSheets'));
          }
          return $this->fStyleSheets;
        break;
        case 'userInfo':
          if ($this->fUserInfo == null) {
            $this->fUserInfo = $this->createOwnedObject('bmUserInfo', array('name' => 'userInfo', 'userId' => $this->session->userId));
          }
          return $this->fUserInfo;
        break;
        case 'errorHandler':
          if ($this->fErrorHandler == null) {
            $this->fErrorHandler = $this->createOwnedObject('bmHTMLErrorHandler', array('name' => 'errorHandler'));
          }
          return $this->fErrorHandler;
        break;
        case 'validator':
          if ($this->fValidator == null) {
            $this->fValidator = $this->createOwnedObject('bmValidator', array('name' => 'validator'));
          }
          return $this->fValidator;
        break;
        case 'cgi':
          if ($this->fCGI == null) {
            $this->fCGI = $this->createOwnedObject('bmCGI', array('name' => 'cgi'));
          }
          return $this->fCGI;
        break;
        case 'painterCache':
          if ($this->fPainterCache == null) {
            $this->fPainterCache = $this->createOwnedObject('bmPainterCache', array('name' => 'painterCache'));
          }
          return $this->fPainterCache;
        break;
        case 'fileStorage':
          if ($this->fFileStorage == null) {
            $this->fFileStorage = $this->createOwnedObject('bmFileStorage', array('name' => 'fileStorage'));
          }
          return $this->fFileStorage;
        break;
        case 'fileSystem':
          if ($this->fFileSystem == null) {
            $this->fFileSystem = $this->createOwnedObject('bmFileSystem', array('name' => 'fileSystem'));
          }
          return $this->fFileSystem;
        break;
        case 'dataLinks':
          if ($this->fDataLinks == null) {
            $this->fDataLinks = $this->createOwnedObject('bmDataLinks', array('name' => 'dataLinks'));
          }
          return $this->fDataLinks;
        break;
        case 'dateUtils':
          if ($this->fDateUtils == null) {
            $this->fDateUtils = $this->createOwnedObject('bmDateUtils', array('name' => 'dateUtils'));
          }
          return $this->fDateUtils;
        break;
        case 'textUtils':
          if ($this->fTextUtils == null) {
            $this->fTextUtils = $this->createOwnedObject('bmTextUtils', array('name' => 'textUtils'));
          }
          return $this->fTextUtils;
        break;
        case 'session':
          if ($this->fSession == null) {
            $this->fSession = $this->createOwnedObject('bmSession', array('name' => 'session'));
          }
          return $this->fSession;
        break; 
        case 'mainLink':
          if ($this->fMainLink == null) {
            $this->fMainLink = $this->dataLinks->items[$this->mainDataBase];
          }
          return $this->fMainLink;
        break;
        case 'formInfo':
          if ($this->myFormInfo == null) {
            $this->myFormInfo = $this->createOwnedObject('bmDataSource', array('name' => 'formInfo'));
            $this->myFormInfo->boundDataMap->objectName = 'form';
            $object = $this->myFormInfo->boundDataMap->dataObjectMaps->add('form');
            $propertyMap = $object->propertiesMap->add('alias');
            $propertyMap->fieldName = 'alias';
            $propertyMap = $object->propertiesMap->add('container');
            $propertyMap->fieldName = 'container'; 
          }
          return $this->myFormInfo;
        break;
        default:
          $result = parent::getter($propertyName);
          if (!isset($result)) {
            if (($form = $this->getForm($propertyName)) !== false) {
              return $form;
            }
          }
          return $result;
        break;
      }
    }

    private function getFormMapFile($formName, &$container = null) {
      $userId = $this->application->textUtils->textToHex($this->application->userInfo->id);
      $result = './sessions/' . $userId . '-' . $this->application->session->id . '-' . 'bm' . $formName . '.xml';
      if (!file_exists($result)) {
        if (($formInfo = $this->formInfo->loadObject($formName)) != null) {
          $container = $formInfo->container;
          if ($container != '') {
            $result = './forms/bm' . $container . '.xml';
            $GLOBALS['loadedClasses'][] = 'bm' . $container . '.xml';
          } else {
            $result = './forms/bm' . $formName . '.xml';
          }
        } else {
          return false;
        }
      }
      return $result;
    }

    public function getForm($formName) {
      if (!array_key_exists($formName, $this->forms)) {
        if (($mapFile = $this->getFormMapFile($formName, $container)) !== false) {
          require_once('./forms/bm' . $formName . '.php');
          if (file_exists('./userLocales/' . $this->locale . '/bm' . $formName . '.php')) {
            require_once('./userLocales/' . $this->locale . '/bm' . $formName . '.php');
          }
          $GLOBALS['loadedClasses'][] = 'bm' . $formName;
          $form = $this->createOwnedObject('bm' . $formName, array('name' => $formName, 'fileName' => $mapFile, 'container' => $container));
          $this->forms[$formName] = $form;
          return $form;
        } else {
          return false;
        }
      } else {
        return $this->forms[$formName];
      }
    }

    private function draw() {
      $formName = $this->session->formName;
      $result = $this->$formName->draw();
      print $result;
    }
    
    public function getFile($id) {
      $this->fileStorage->getFile($id);
      exit;
    }
    
    private function getComponentByName($value) {
      $currentObject = $this;
      $value = substr($value, 12);
      while (preg_match('/^(\w+)\.(.*)$/', $value, $matches)) {
        if (array_key_exists($matches[1], $currentObject->components)) {
        $currentObject = $currentObject->components[$matches[1]];
        } elseif ($currentObject->$matches[1]) {
          $currentObject = $currentObject->$matches[1];
        }
        $value = $matches[2];
      }
      if (array_key_exists($value, $currentObject->components)) {
        $value = $currentObject->components[$value];
      }
      return $value;
    }
    
    public function executeAction($actionName) {
      list($sender, $actionName) = split(',', $actionName);
      $sender = $this->getComponentByName($sender);
      $this->actions->execute($actionName, $sender, null);
    }
    
    public function goToURL($url) {
      
      header('location: ' . $url, true);
      exit;
      
    }

  }

?>
