<?php

  class bmCustomFrame extends bmCustomControl {
    
    function constructor($session, $owner, $parameters) {

      parent::constructor($session, $owner, $parameters);
      $this->serializeProperty("formName", pbValue, "fIndex");
      

    }
        
  }

?>
