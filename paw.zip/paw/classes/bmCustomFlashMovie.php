<?php
  
  class bmCustomFlashMovie extends bmCustomControl {
    
    function constructor($application, $owner, $parameters) {
      
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("movie", pbValue, "");
      $this->serializeProperty("quality", pbValue, "");

    }
    
  }
  
?>