<?php

  class bmCustomPanel extends bmCustomControl {
    
  }
  
?>
