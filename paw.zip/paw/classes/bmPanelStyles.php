<?php
  
  class bmPanelStyles extends bmCustomControlStyles {
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
    
    }
    
  }
  
?>
