<?php

  define('bbSubmit', 'submit');
  define('bbReset', 'reset');
  define('bbCustom', 'button');
  
  class bmCustomButton extends bmCustomControl {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

      $this->serializeProperty("caption", pbValue, 'Click Me!');
      $this->serializeProperty("behaviour", pbValue, bbCustom);

    }
    
  }
  
?>
