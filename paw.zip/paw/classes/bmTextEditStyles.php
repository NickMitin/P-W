<?php

  class bmTextEditStyles extends bmCustomControlStyles {

  }

?>