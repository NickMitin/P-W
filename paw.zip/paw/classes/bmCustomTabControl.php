<?php
  
  class bmCustomTabControl extends bmCustomControl {
    
    public $tabs = null;
    
    public function constructor($application, $owner, $parameters) {
    
      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('tabHeight', pbValue, 25);
      
      $this->tabs = $this->createOwnedObject('bmTabControlTabs', array('name' => 'tabs'));
    
    }
    
  }
  
?>
