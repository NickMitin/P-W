<?php
  
  class bmHTMLCalendarPainter extends bmHTMLStandaloneControlPainter {

    function drawControl($control) {
      
      $dateInfo = getdate($control->date + $this->application->userInfo->timeOffset);
      
      $year = $dateInfo["year"];
      $month = $dateInfo["mon"];
      
      $startMonthWeekDay = gmdate("N", gmmktime(0, 0, 0, $month, 1, $year));
      $daysInMonth = gmdate("t", gmmktime(0, 0, 0, $month, 1, $year));
      $endMonthWeekDay = $daysInMonth + $startMonthWeekDay - 1;
      
      $cells = ceil(($daysInMonth + $startMonthWeekDay - 1) / 7) * 7;
      
      $date = gmmktime(0, 0, 0, $month, 1, $year);
      
      $weekDay = 1;
      
      $switchForm = "application.switchForm=" . $control->ownerForm->name;
      $componentDate = 'application.' . $control->ownerForm->name . '.' . $control->name . ".date=";
      
      $result = '<table class="' . $control->styles->default . '" cellpadding="0" cellspacing="0"><tbody>';
      
      $result .= '<tr><td class="' . $control->styles->header . '" colspan="7" style="text-align: center;">'; 
      $result .=  $control->application->dateUtils->dateToString($control->date);
      $result .= '</td></tr><tr>';
      
      for ($i = 1; $i < 8; ++$i) {
        
        $result .= '<td class="' . $control->styles->weekDay . '">' . $control->application->dateUtils->weekDayToString($i, wdnfShort) . '</td>';
          
      }
      
      $result .= '</tr><tr>';
        
      for ($i = 1; $i <= $cells; ++$i) {
        
        $cellClass = $control->styles->day;
        $linkClass = $control->styles->dayLink;
        if (($i >= $startMonthWeekDay) && ($i <= $endMonthWeekDay)) {
          $day = $i - $startMonthWeekDay + 1;
          if ($day == $dateInfo['mday']) {
            $cellClass = $control->styles->activeDay;
            $linkClass = $control->styles->activeDayLink;
          }
          $marker = $date + (($day - 1) * 86400);
          $link = $this->application->path;
          if ($control->action) {
            $link .= $control->action . $marker;
          } else {
            $link .= 'main.php?' . $switchForm . '&amp;' . $componentDate . $marker;
          }
          $cellValue = '<a class="' . $linkClass . '" href="' . $link . '">' . $day . '</a>';
        } else {
          $cellValue = '&nbsp;';
        }
        $result .= '<td class="' . $cellClass . '">' . $cellValue . '</td>';
    
        if (($i % 7) == 0) {
          if ($i == $cells) {
            $result .= "</tr>";
          } else {
            $result .= "</tr><tr>";
          }
        }
        
      }
        
      $result .= "<tr><td colspan=\"7\" style=\"text-align: center;\">"; 
      $result .= $this->drawLink($switchForm . "&amp;" . $componentDate . gmmktime(0, 0, 0, $month, $dateInfo["mday"], $year - 1), cYearBack, "&lt;&lt;", $control->styles->navigatorLink) . " ";
      $result .= $this->drawLink($switchForm . "&amp;" . $componentDate . gmmktime(0, 0, 0, $month - 1, $dateInfo["mday"], $year), cMonthBack, "&lt;", $control->styles->navigatorLink) . " ";
      $result .= $this->drawLink($switchForm . "&amp;" . $componentDate . gmmktime(0, 0, 0, $month + 1, $dateInfo["mday"], $year), cMonthForward, "&gt;", $control->styles->navigatorLink) . " ";
      $result .= $this->drawLink($switchForm . "&amp;" . $componentDate . gmmktime(0, 0, 0, $month, $dateInfo["mday"], $year + 1), cYearForward, "&gt;&gt;", $control->styles->navigatorLink);
      $result .= "</td></tr>";
      
      $result .= "</tbody></table>";
      return $result;
    }
  
  }
  
?>
