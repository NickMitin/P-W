<?php
  
  class bmTabControlTabs extends bmCollection {
    
    public $keyPropertyName = 'caption';
    public $collectionItemClass = 'bmTabControlTab';
    
  }
  
?>
