<?php

  define("hlemView", 1);
  define("hlemEdit", 2);

  class bmHyperLinkEdit extends bmCustomHyperLinkEdit {
    
    public $hasClientMirror = 1;
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("caption", pbValue);
      $this->serializeProperty("mode", pbValue, hlemView);
      
    }
  
  }

?>
