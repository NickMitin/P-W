<?php

  class bmDataFilterFullTextCondition extends bmCustomDataFilterCondition {
    
    public $fields = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty("value", pbValue, "1");
      $this->fields = $this->createOwnedObject("bmDataFilterConditionFields", array("name" => "fields"));

    }

  }

?>