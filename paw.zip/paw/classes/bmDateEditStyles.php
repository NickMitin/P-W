<?php

  class bmDateEditStyles extends bmCustomControlStyles {

  }

?>
