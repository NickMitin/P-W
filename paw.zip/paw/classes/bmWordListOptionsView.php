<?php

  class bmWordListOptionsView extends bmPersistentObject {

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      $this->serializeProperty('rowToolBar', pbValue, true);

    }

  }

?>
