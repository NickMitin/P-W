<?php

  class bmCustomListBoxEdit extends bmCustomOptionEdit {
    
    //public $ownerObjectName = null;

    function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);
      //$this->serializeProperty("propertyName", passBy (pbValue/pbReference), "propertyValue");
      //$this->publishProperty("propertyName", passBy (pbValue/pbReference), "propertyValue");
      //$this->ownerObjectName = $this->createOwnedObject("ownerObjectClass", array("name" => "ownerObjectName"));
    }
    
  }
  
?>