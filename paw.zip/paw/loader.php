<?php
  
                               
  ini_set('memory_limit', '-1');
  ini_set('error_reporting', E_ALL);
  error_reporting(E_ALL);
  //ini_set('error_reporting', E_NONE);
  //error_reporting(E_NONE);

  function __autoload($class) {
    $filename = $class . ".php";
    if (file_exists(engineRoot . "classes/" . $filename)) {
      require_once(engineRoot . "classes/" . $filename);
    } elseif (file_exists("./userClasses/" . $filename)) {
      require_once("./userClasses/" . $filename);
    }
    if (array_key_exists("application", $GLOBALS)) {
      $locale = $GLOBALS["application"]->locale;
      if (file_exists(engineRoot . "locales/" . $locale . "/" . $filename)) {
        require_once(engineRoot . "locales/" . $locale . "/" . $filename);
      } elseif (file_exists("./userLocales/" . $locale . "/" . $filename)) {
        require_once("./userLocales/" . $locale . "/" . $filename);
      }
    }
    if (!array_key_exists("loadedClasses", $GLOBALS)) {
      $GLOBALS["loadedClasses"] = array();
      $GLOBALS["loadedClasses"][] = $class;
    } else {            
      $count = count($GLOBALS["loadedClasses"]);
      for ($i = 0; $i < $count; ++$i) {
        $parentClass = $GLOBALS["loadedClasses"][$i];
      }
      if ($i == $count) {
        $GLOBALS["loadedClasses"][] = $class;
      } else {
        array_splice($GLOBALS["loadedClasses"], $i, 0, array($class));
        
      }
    }
  }

?>
