<?php
  
  define("cYearBack", "На год назад");
  define("cYearForward", "На год вперед");
  define("cMonthBack", "На месяц назад");
  define("cMonthForward", "На месяц вперед");
  
?>
