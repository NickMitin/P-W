<?php
  
  define('dtDD', 'ДД');
  define('dtMM', 'ММ');
  define('dtYYYY', 'ГГГГ');
  define('deErrorInvalidDateValue', 'Неверное значение даты.');
  
?>
