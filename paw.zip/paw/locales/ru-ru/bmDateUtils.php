<?php

  define ("ducTextualFormat", "d F Y");
  
  define("ducJanuary", "Январь");
  define("ducFebruary", "Февраль");
  define("ducMarch", "Март");
  define("ducApril", "Апрель");
  define("ducMay", "Май");
  define("ducJune", "Июнь");
  define("ducJuly", "Июль");
  define("ducAugust", "Август");
  define("ducSeptember", "Сентябрь");
  define("ducOctober", "Октябрь");
  define("ducNovember", "Ноябрь");
  define("ducDecember", "Декабрь");
  
  define("ducInPlaceJanuary", "Января");
  define("ducInPlaceFebruary", "Февраля");
  define("ducInPlaceMarch", "Марта");
  define("ducInPlaceApril", "Апреля");
  define("ducInPlaceMay", "Мая");
  define("ducInPlaceJune", "Июня");
  define("ducInPlaceJuly", "Июля");
  define("ducInPlaceAugust", "Августа");
  define("ducInPlaceSeptember", "Сентября");
  define("ducInPlaceOctober", "Октября");
  define("ducInPlaceNovember", "Ноября");
  define("ducInPlaceDecember", "Декабря");
  
  define("ducMonday", "Понедельник");
  define("ducTuesday", "Вторник");
  define("ducWednsday", "Среда");
  define("ducThursday", "Четверг");
  define("ducFriday", "Пятница");
  define("ducSaturday", "Суббота");
  define("ducSunday", "Воскресенье");
  
  define("ducMondayShort", "Пн");
  define("ducTuesdayShort", "Вт");
  define("ducWednsdayShort", "Ср");
  define("ducThursdayShort", "Чт");
  define("ducFridayShort", "Пт");
  define("ducSaturdayShort", "Сб");
  define("ducSundayShort", "Вс");
  
?>
