<?php
  
  define("cYearBack", "One year back");
  define("cYearForward", "One year forward");
  define("cMonthBack", "One month back");
  define("cMonthForward", "One month forward");
  
?>
