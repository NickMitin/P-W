<?php
  
  define('dtDD', 'dd');
  define('dtMM', 'mm');
  define('dtYYYY', 'yyyy');
  
?>
