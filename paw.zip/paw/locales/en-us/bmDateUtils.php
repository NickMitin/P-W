<?php

  define ("ducTextualFormat", "F d, Y");
  
  define("ducJanuary", "January");
  define("ducFebruary", "February");
  define("ducMarch", "March");
  define("ducApril", "April");
  define("ducMay", "May");
  define("ducJune", "June");
  define("ducJuly", "July");
  define("ducAugust", "August");
  define("ducSeptember", "September");
  define("ducOctober", "October");
  define("ducNovember", "November");
  define("ducDecember", "December");
  
  define("ducInPlaceJanuary", "January");
  define("ducInPlaceFebruary", "February");
  define("ducInPlaceMarch", "March");
  define("ducInPlaceApril", "April");
  define("ducInPlaceMay", "May");
  define("ducInPlaceJune", "June");
  define("ducInPlaceJuly", "July");
  define("ducInPlaceAugust", "August");
  define("ducInPlaceSeptember", "September");
  define("ducInPlaceOctober", "October");
  define("ducInPlaceNovember", "November");
  define("ducInPlaceDecember", "December");
  
  define("ducMonday", "Monday");
  define("ducTuesday", "Tuesday");
  define("ducWednsday", "Wednsday");
  define("ducThursday", "Thursday");
  define("ducFriday", "Friday");
  define("ducSaturday", "Saturday");
  define("ducSunday", "Sunday");
  
  define("ducMondayShort", "Mon");
  define("ducTuesdayShort", "Tue");
  define("ducWednsdayShort", "Wed");
  define("ducThursdayShort", "Thu");
  define("ducFridayShort", "Fri");
  define("ducSaturdayShort", "Sat");
  define("ducSundayShort", "Sun");
  
?>
