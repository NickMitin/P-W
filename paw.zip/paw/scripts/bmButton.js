function bmButton(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmButton.inherit(bmCustomControl);

bmButton.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Button');
  
}

