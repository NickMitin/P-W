function bmCGI(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCGI.inherit(bmObject);


bmCGI.prototype.addCookie = function(name, value, time, path) {

  if (time != null) {
    var today = new Date();
    today.setTime(today.getTime());
    time = time * 1000;
    time = new Date(today.getTime() + (expires));
  }
  value = '=' + ((value != null) ? escape(value) : '');
  time = (time != null) ? ';expires=' + time.toGMTString() : '';
  path = (path != null) ? ';path=' + escape(path) : '/';
  var cookie = name + value + time + path;
  document.cookie = cookie;
  
}

bmCGI.prototype.deleteCookie = function(name) {

}