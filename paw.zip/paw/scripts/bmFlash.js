
function bmFlash(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmFlash.inherit(bmCustomControl);

bmFlash.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Movie');
  
}

bmFlash.prototype.play = function() {
  this.control.Play();
}

bmFlash.prototype.stop = function() {
  this.control.StopPlay();
}

