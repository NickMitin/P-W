  function bmPasswordEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmPasswordEdit.inherit(bmCustomEdit);

bmPasswordEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + 'Edit');

}
