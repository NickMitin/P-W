function bmTextLookupEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  } 

}

bmTextLookupEdit.inherit(bmCustomEdit);

bmTextLookupEdit.prototype.ownInitialize = function() {
  
  var instance = this.instance;
  
  this.dropDown = document.createElement('div');
  this.dropDown.id = this.name + 'DropDown';
  this.dropDown.style.position = 'absolute';
  this.dropDown.style.display = 'none';
  this.dropDown.style.zIndex = '9999';
  this.dropDown = this.ownerForm.instance.appendChild(this.dropDown);
  this.control = document.getElementById(this.name + 'Edit');
  this.dropDown.style.left = application.getElementOffsetLeft(this.control) + 'px';
  this.dropDown.style.top = (application.getElementOffsetTop(this.control) + this.control.offsetHeight) + 'px';
  
  application.attachEvent(this.control, 'keyup', this.valueChangeHandler); 
  this.attachOwnEvents(this.dropDown);
  
}

bmTextLookupEdit.prototype.attachOwnEvents = function(node) {
  var childNode = null;
  var i;
  for (i = 0; i < node.childNodes.length; ++i) {
    childNode = node.childNodes.item(i);
    if (childNode.nodeType == 1) {
      if (childNode.nodeName == 'A') {
        application.attachEvent(childNode, 'click', this.searchResultHandler);
        application.attachEvent(childNode, 'keypress', this.searchResultHandler);  
      }
      this.attachOwnEvents(childNode);
    }
  }
}

bmTextLookupEdit.prototype.dropDown = null;

bmTextLookupEdit.prototype.create = function(application, owner, parameters) {

  var sender = this;
    
  this.searchResultHandler = function(event) {
    var element = sender.getEventElement(event);
    sender.dropDown.style.display = 'none';
    sender.setValue(element.innerHTML);
    application.eventPreventDefault(event);
    return false;
  }
  
  this.valueChangeHandler = function(event) {
    var keyCode = event.keyCode;
    var value = sender.getValue();
    if (value.length > 3) {
      if ((keyCode == 32) || (keyCode == 8) || ((keyCode > 48) && (keyCode < 112))) {
        var componentString = 'application.' + sender.ownerForm.name + '.' + sender.name;
        var url = '/chat/main.php?' + componentString + '.value=' + value + '&' + componentString + '.getDropDownValueList=1'; 
        application.httpGateway.get(url, sender.getDropDown);
      }
    } else {
      sender.dropDown.style.display = 'none';
    }
  }
  
  this.getDropDown = function(event) {
    var result = new Array();
    result = event['data'].split(',');
    if (result[0] > 0) {
      sender.dropDown.innerHTML = '';
      result[0] = '';
      var value = '';
      for (i in result) {
        value = result[i];
        if (value != ',') {
          sender.dropDown.innerHTML += value;
        }
      }
      sender.attachOwnEvents(sender.dropDown);
      sender.dropDown.style.display = 'block';
    } else {
      sender.dropDown.style.display = 'none';
    }
  }

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);
  
}

bmTextLookupEdit.prototype.recreateEvents = function() {

  bmCustomEdit.prototype.recreateEvents.call(this);
  this.attachOwnEvents(this.dropDown);

}

bmTextLookupEdit.prototype.serializeValue = function() {

  var value = this.getValue();
  if (value.length != 0) {
    var componentString = this.getComponentString();
    var url = '/chat/main.php?' + componentString + '.value=' + value + '&' + componentString + '.serializeValue=1';
    application.httpGateway.get(url, null);
  }

}
