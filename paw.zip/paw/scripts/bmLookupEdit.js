function bmLookupEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmLookupEdit.inherit(bmCustomEdit);

bmLookupEdit.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Edit');
  
}
