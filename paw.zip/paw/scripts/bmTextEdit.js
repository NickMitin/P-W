function bmTextEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmTextEdit.inherit(bmCustomEdit);

bmTextEdit.prototype.trigger = null;

bmTextEdit.prototype.create = function(application, owner, parameters) {

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}

bmTextEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + 'Edit');

}
