function bmDataGridStyles(application, owner, parameters) {
  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
}

bmDataGridStyles.inherit(bmObject);

bmDataGridStyles.prototype.hotTrackRow = 'default';
bmDataGridStyles.prototype.selectedRow = 'default';

bmDataGridOptionsBehaviour.prototype.hotTrack = false;

function bmDataGridOptionsBehaviour(application, owner, parameters) {
  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
}

bmDataGridOptionsBehaviour.inherit(bmObject);

bmDataGridOptionsBehaviour.prototype.hotTrack = false;



function bmDataGrid(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmDataGrid.inherit(bmCustomControl);

bmDataGrid.prototype.editUrl = null;
bmDataGrid.prototype.styles = null;
bmDataGrid.prototype.optionsBehaviour = null;

bmDataGrid.prototype.getEditUrl = function() {

  if (this.editUrl == null) {
    var componentString = this.getComponentString();
    this.editUrl = this.reloadUrl + '&' + componentString + '.editRow='; 
  }
  return this.editUrl;
}

bmDataGrid.prototype.create = function(application, owner, parameters) {

  this.type = 'bmDataGrid';
  this.className = 'bmDataGrid';
  this.ownEvents = {'linkclick': 1, 'toolbarbuttonclick': 1};
  this.styles = new bmDataGridStyles(application, this, {'name': 'styles'});
  this.optionsBehaviour = new bmDataGridOptionsBehaviour(application, this, {'name': 'optionsBehaviour'});
  
  var sender = this;
  
  this.toolBarButtonHandler = function(event) {
    if ((handlers = sender.events['toolbarbuttonclick']) != null) {
      var handler;
      for (i in handlers) {
        handler = handlers[i];
        var result = handler(event);
        if (result) {
          application.eventPreventDefault(event);
          return false;
        }
      } 
    }
    var element = application.getEventElement(event);
    if (element.id.indexOf('ToolBarButtonDelete') != -1) {
      if (!confirm('Вы уверены, что хотите удалить запись?')) {
        application.eventPreventDefault(event);
        return false;  
      }
    }
  }
  
  this.linkClickHandler = function(event) {
    if ((handlers = sender.events['linkclick']) != null) {
      var handler;
      for (i in handlers) {
        handler = handlers[i];
        var result = handler(event);
        if (result) {
          application.eventPreventDefault(event);
          return false;
        }
      } 
    }
    
  }
  
  this.checkBoxHandler = function(event) {
    var element = application.getEventElement(event);
    var id = element.id.match(/.+\d{4}/i)[0];
    var edit = document.getElementById(id + 'Edit');
    edit.value = (element.checked) ? 1 : 0;
  }
  
  this.dataRowClickHandler = function(event) {
    var element = application.getEventElement(event);
    var rowInfo = element.id.match(/\w+DataRow_([a-f0-9]+)_([12])/);
    var id = rowInfo[1];
    var rowOrder = rowInfo[2];
    
    var rowStyle = '';
    
    if (element.selected) {
      element.selected = false;
      rowStyle = rowOrder == 1 ? sender.styles.oddRow : sender.styles.evenRow;
    } else {
      element.selected = true;
      rowStyle = sender.styles.selectedRow;
    }
    element.className = rowStyle;
  }
  
  this.dataRowMouseOverHandler = function(event) {
    var element = application.getEventElement(event);
    element.className = sender.styles.hotTrackRow;
  }
  
  this.dataRowMouseOutHandler = function(event) {
    var element = application.getEventElement(event);
    var rowInfo = element.id.match(/\w+DataRow_([a-f0-9]+)_([12])/);
    var rowOrder = rowInfo[2];
    if (element.selected) {
      element.className = sender.styles.selectedRow;
    } else {
      element.className = rowOrder == 1 ? sender.styles.oddRow : sender.styles.evenRow;
    }
  }
  bmCustomControl.prototype.create.call(this, application, owner, parameters);

}                    

bmDataGrid.prototype.ownInitialize = function() {

  this.attachOwnEvents(this.instance);
  
}

bmDataGrid.prototype.recreateEvents = function() {

  bmCustomControl.prototype.recreateEvents.call(self);
  this.attachOwnEvents(this.instance);
  
}

bmDataGrid.prototype.attachOwnEvents = function(node) {
  var childNode = null;
  var i;
  for (i = 0; i < node.childNodes.length; ++i) {
    childNode = node.childNodes[i];
    if (childNode.nodeType == 1) {
      if ((childNode.nodeName == 'INPUT') && (childNode.type == 'checkbox') && (childNode.id.indexOf('Trigger') != -1)) {
        application.attachEvent(childNode, 'click', this.checkBoxHandler);   
      } else if (childNode.nodeName == 'A') {
        if (childNode.id.indexOf('ToolBarButton') != -1) {
          application.attachEvent(childNode, 'click', this.toolBarButtonHandler);
          application.attachEvent(childNode, 'keyPress', this.toolBarButtonHandler);      
        } else {
          application.attachEvent(childNode, 'click', this.linkClickHandler);
          application.attachEvent(childNode, 'keyPress', this.linkClickHandler);
        }                                         
      } else if (childNode.nodeName == 'TR' && childNode.id.indexOf('DataRow') != -1) {
        application.attachEvent(childNode, 'click', this.dataRowClickHandler);
        if (this.optionsBehaviour.hotTrack) {
          application.attachEvent(childNode, 'mouseover', this.dataRowMouseOverHandler);
          application.attachEvent(childNode, 'mouseout', this.dataRowMouseOutHandler);
        }
      }
      this.attachOwnEvents(childNode);
    }
  }
}

