function bmRTTIInspector(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmRTTIInspector.inherit(bmCustomControl);

bmRTTIInspector.prototype.initialize = function() {
  
  this.control = document.getElementById(this.name + 'Button');
  
}

bmRTTIInspector.prototype.create = function(application, owner, parameters) {

  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  this.initialize();
}

bmRTTIInspector.prototype.recreateEvents = function() {

  this.initialize();
  bmCustomControl.prototype.recreateEvents.call(this);

}

