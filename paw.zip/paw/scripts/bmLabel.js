
function bmLabel(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmLabel.inherit(bmCustomControl);

bmLabel.prototype.ownInitialize = function() {
  
  this.control = this.instance;
  
}

