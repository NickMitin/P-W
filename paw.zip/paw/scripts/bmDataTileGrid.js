function bmDataTileGrid(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
  
  var sender = this;
  
  this.editButtonHandler = function(event) {
    var element = sender.getEventElement(event);
    var url = sender.getEditUrl();
    sender.reload(url + element.title)
    return false;
  }
  
  this.checkBoxHandler = function(event) {
    var element = sender.getEventElement(event);
    var id = element.id.match(/.+\d{4}/i)[0];
    var edit = document.getElementById(id + 'Edit');
    edit.value = (element.checked) ? 1 : 0;
  }
  
  this.initialize();

}

bmDataTileGrid.inherit(bmCustomControl);

bmDataTileGrid.prototype.editUrl = null;

bmDataTileGrid.prototype.getEditUrl = function() {

  if (this.editUrl == null) {
    var componentString = this.getComponentString();
    this.editUrl = this.reloadUrl + '&' + componentString + '.editRow='; 
  }
  return this.editUrl;
}

bmDataTileGrid.prototype.create = function(application, owner, parameters) {

  this.type = 'bmDataTileGrid';
  this.className = 'bmDataTileGrid';
  bmCustomControl.prototype.create.call(this, application, owner, parameters);

}

bmDataTileGrid.prototype.initialize = function() {

  this.attachOwnEvents(this.instance);

}

bmDataTileGrid.prototype.recreateEvents = function() {

  bmCustomControl.prototype.recreateEvents.call(self);
  this.attachOwnEvents(this.instance);
  
}

bmDataTileGrid.prototype.attachOwnEvents = function(node) {
  var childNode = null;
  for (i in node.childNodes) {
    childNode = node.childNodes[i];
    if (childNode.nodeName == 'IMG' && childNode.alt == 'edit') {
      application.attachEvent(node.parentNode, 'click', this.editButtonHandler);
      application.attachEvent(node.parentNode, 'keyPress', this.editButtonHandler);  
    }
    if ((childNode.nodeName == 'INPUT') && (childNode.type == 'checkbox') && (childNode.id.indexOf('Trigger') != -1)) {
      application.attachEvent(node, 'click', this.checkBoxHandler);   
    }
    this.attachOwnEvents(childNode);
  }
}
