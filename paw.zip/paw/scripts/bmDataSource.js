
  function dataSourceManageRows(formName) {
    document.forms[formName].submit();
  }
