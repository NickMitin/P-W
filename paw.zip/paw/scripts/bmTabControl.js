function bmTabControl(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmTabControl.inherit(bmCustomControl);

bmTabControl.prototype.create = function(application, owner, parameters) {

  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  
  var sender = this;
  
  this.tabClickHandler = function(event) {
    
  }
  
  this.initialize(); 

}

bmTabControl.prototype.initialize = function() {

  var instance = this.instance;
  
  if (typeof document.evaluate == 'function') {
  
    var iterator = document.evaluate("//li[contains(@class, 'bmTabControlTab')]", instance, null, XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
    
    var node = iterator.iterateNext();
    while (node) {

      application.attachEvent(node, 'mouseover', this.tabClickHandler);
      node = iterator.iterateNext();
    }
  }
  
}

bmTabControl.prototype.recreateEvents = function() {

  bmCustomControl.prototype.recreateEvents.call();
  this.initialize();

}

