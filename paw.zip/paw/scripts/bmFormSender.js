function bmFormSender(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}  

bmFormSender.inherit(bmAJAXWrapper);

bmFormSender.prototype.fComponent = null;

bmFormSender.prototype.prepareFormData = function(formId) {
  var result = "";
  var element = null;
  var form = window.document.getElementById(formId);
  if (form != null) {
    for (i = 0; i < form.elements.length; ++i) {
      element = form.elements[i];
      result += "--bmFormSender\ncontent-disposition: form-data; name=\"" + element.name + "\"\ncontent-type: text/plain; charset=\"utf-8\"\n\n" + element.value + "\n";
    }
  }
  result += "--bmFormSender";
  return result;
}

bmFormSender.prototype.send = function(url, formId) {
  if (!this.fBusy) {
  
    var data = this.prepareFormData(formId);
    var headers = new Array();
    headers["connection"] = "close";
    headers["content-length"] = data.length;
    headers["content-type"] = "multipart/form-data; boundary=\"bmFormSender\"";
    this.execute("POST", url, null, data, headers);
    
  }
}
