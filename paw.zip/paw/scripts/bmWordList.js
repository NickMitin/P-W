function bmWordList(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmWordList.inherit(bmCustomControl);

