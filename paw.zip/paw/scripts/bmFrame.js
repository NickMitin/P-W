function bmFrame(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmFrame.inherit(bmCustomControl);

bmFrame.prototype.container = null;

bmFrame.prototype.initialize = function() {
  this.container = document.getElementById(this.name + 'Frame');
}

bmFrame.prototype.create = function(application, owner, parameters) {
  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  this.initialize();
}

bmFrame.prototype.getContentDocument = function() {
  return this.container.contentDocument;
}

bmFrame.prototype.recreateEvents = function() {

  this.initialize();
  bmCustomControl.prototype.create.recreateEvents(this);
  
}

