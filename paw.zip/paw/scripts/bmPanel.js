function bmPanel(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmPanel.inherit(bmCustomPanel);

bmPanel.prototype.create = function(application, owner, parameters) {

  this.type = 'bmPanel';
  this.className = 'bmPanel';
  bmCustomPanel.prototype.create.call(this, application, owner, parameters);

}

bmPanel.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name);
  
}
