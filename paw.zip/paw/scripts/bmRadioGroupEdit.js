function bmRadioGroupEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmRadioGroupEdit.inherit(bmCustomEdit);

bmRadioGroupEdit.prototype.create = function(application, owner, parameters) {

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}
