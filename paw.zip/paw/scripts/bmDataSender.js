function bmDataSender(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}  

bmDataSender.inherit(bmAJAXWrapper);

bmDataSender.prototype.fComponent = null;

bmDataSender.prototype.prepareData = function(data) {
  var result = "";
  var element = null;
  if (data != null) {
    var name = "";
    for (name in data) {                                                      
      result += "--bmDataSender\ncontent-disposition: form-data; name=\"" + name + "\"\ncontent-type: text/plain; charset=\"utf-8\"\n\n" + data[name] + "\n";
    }
  }
  result += "--bmDataSender";
  return result;
}

bmDataSender.prototype.send = function(url, data) {
  if (!this.fBusy) {
  
    data = this.prepareData(data);
    var headers = new Array();
    headers["connection"] = "close";
    headers["content-length"] = data.length;
    headers["content-type"] = "multipart/form-data; boundary=\"bmDataSender\"";
    this.execute("POST", url, null, data, headers);
    
  }
}
