function bmComponent(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmComponent.inherit(bmObject);

bmComponent.prototype.name = null;
bmComponent.prototype.components = null;

bmComponent.prototype.create = function(application, owner, parameters) {

  bmObject.prototype.create.call(this, application, owner, parameters);
  
  this.components = new Array();
  this.name = parameters['name'];
  
  if (this.owner == null) {
    alert(this.name);
  }
  
  if (this.owner.components != null) {
    this.owner.components[this.name] = this;
  }

}

bmComponent.prototype.getComponentString = function() {

  var result = this.name;
  var component = this.owner;
  while (component != null) {
    if (component.name != null) {
      result = component.name + '.' + result;
    }
    component = component.owner;
  }
  
  result = 'application.' + result;
  
  return result;

}                      
