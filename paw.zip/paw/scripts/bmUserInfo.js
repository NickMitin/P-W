function bmUserInfo(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmUserInfo.inherit(bmObject);

bmUserInfo.prototype.id = 'guest';

bmUserInfo.prototype.create = function(application, owner, parameters) {

  bmObject.prototype.create.call(this, application, owner, parameters);
  
  
}

bmUserInfo.prototype.initialize = function(data) {
  eval(data);
}
