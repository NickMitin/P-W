function bmHTMLForm(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmHTMLForm.inherit(bmCustomControl);

bmCustomControl.prototype.reloadCount = 0;

bmHTMLForm.prototype.ownInitialize = function() {
  this.instance = document.getElementById(this.name);
  document.pawAccess = this;
}

bmHTMLForm.prototype.create = function(application, owner, parameters) {

  this.type = 'bmHTMLForm';
  this.className = 'bmHTMLForm';
  bmCustomControl.prototype.create.call(this, application, owner, parameters); 
  
  application.formName = this.name;
  application.activeForm = this;
  
  var sender = this;
  
  this.loadHandler = function(event) {
    var elementsBuffer = document.getElementById(sender.name + 'ElementsBuffer');
    if (elementsBuffer != null) {
      sender.elementsBuffer = elementsBuffer;
    }
    var waitScreen = document.getElementById(sender.name + 'WaitScreen');
    if (waitScreen != null) {
      sender.waitScreen = waitScreen;
    }

    if (sender.load != null) {
      sender.load(event);
    }
    if (sender.userLoad != null) {
      sender.userLoad(event);
    }
    if (sender.waitScreen) {
     sender.waitScreen.style.display = 'none';
    }
  }
  
  application.attachEvent(window, "load", this.loadHandler); 

}

bmHTMLForm.prototype.showWaitScreen = function() {
  this.waitScreen.style.display = 'block';
}

bmHTMLForm.prototype.hideWaitScreen = function() {
  this.waitScreen.style.display = 'none';
}

bmHTMLForm.prototype.data = null; 
bmHTMLForm.prototype.elementsBuffer = null;

bmHTMLForm.prototype.createBufferElement = function() {


  var bufferElement = document.createElement('div');
  var id = Math.floor(Math.random() * 1000) + 1;
  bufferElement.setAttribute('style', 'display: none;');
  bufferElement.setAttribute('id', 'bufferElement' + id);
  this.elementsBuffer.appendChild(bufferElement);
  return bufferElement;
 
}

bmHTMLForm.prototype.deleteBufferElement = function(element) {

  this.elementsBuffer.removeChild(element);
 
}
