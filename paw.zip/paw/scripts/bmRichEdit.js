function bmRichEditEnable(richEdit) {
  richEdit.firstChild.contentDocument.designMode = "on";
}

function bmRichEditExecCommand(richEdit, command, parameter) {
  richEdit.firstChild.contentDocument.execCommand(command, false, parameter);
}

function bmRichEditWrapSelection(richEdit, aNode) {
  var selection = richEdit.firstChild.contentDocument.defaultView.getSelection();
  var selectionRange = selection.getRangeAt(0).cloneRange();
  selection.removeAllRanges();
  selectionRange.surroundContents(aNode);
  selectionRange.setStart(aNode, 0);
  selectionRange.setEnd(aNode, 0);
  selection.addRange(selectionRange);
}

function bmRichEditBoldSelection(richEdit) {
  bmRichEditExecCommand(richEdit, "bold", null);
}

function bmRichEditItalicSelection(richEdit) {
  bmRichEditExecCommand(richEdit, "italic", null);
}

function bmRichEditUnderlineSelection(richEdit) {
  bmRichEditExecCommand(richEdit, "underline", null);
}

function bmRichEditSubscriptSelection(richEdit) {
  bmRichEditExecCommand(richEdit, "subscript", null);
}

function bmRichEditURLSelection(richEdit, aURL) {
  bmRichEditExecCommand(richEdit, "createlink", aURL);
}

function bmRichEditImageSelection(richEdit, aImage) {
  bmRichEditExecCommand(richEdit, "insertimage", aImage);
}

function bmRichEditFontNameSelection(richEdit, aFontName) {
  bmRichEditExecCommand(richEdit, "fontname", aFontName);
}

function bmRichEditInsertHTML(richEdit, aHTML) {
  bmRichEditExecCommand(richEdit, "inserthtml", aHTML);
}

/*function bmRichEditItalicSelection(richEditId) {
  var fDocument = richEditCache[richEditId].contentDocument;
  var fWindow = fDocument.defaultView;
  if (fWindow.getSelection().toString().length != 0) {
    var bold = fDocument.createElement("span");
    bold.style.fontStyle = "italic";
    bmRichEditWrapSelection(fWindow, bold);
  } 
}*/

function bmRichEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmRichEdit.inherit(bmCustomControl);

bmRichEdit.prototype.contentDocument = null;

bmRichEdit.prototype.create = function(application, owner, parameters) {

  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  //this.control = document.getElementById(this.name + 'Edit');
  //this.contentDocument = this.control.contentDocument;
  //this.contentDocument.designMode = 'on';

}
