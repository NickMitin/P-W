function bmCustomPanel(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCustomPanel.inherit(bmCustomControl);

bmCustomPanel.prototype.show = function(x, y) {
  this.setLeft(x);
  this.setTop(y);
  this.instance.style.zIndex = 9999;
  this.setVisible(true);
}

bmCustomPanel.prototype.hide = function() {
  this.setVisible(false);
}
