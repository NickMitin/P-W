function bmMenuItem(application, owner, parameters) {
  
  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmMenuItem.inherit(bmObject);
bmMenuItem.prototype.hasChildren = false;

bmMenuItem.prototype.create = function(application, owner, parameters) {

  this.type = 'bmMenuItem';
  this.className = 'bmMenuItem';
  bmObject.prototype.create.call(this, application, owner, parameters);
  
  var sender = this;
  
  this.onHideMenuItems = function() {
    sender.menuItems.hide();
  }
  
  this.menuItemClickHandler = function(event) {
    var ownerMenu = sender.menuItems.ownerMenu;
    if ((handlers = ownerMenu.events['itemclick']) != null) {
      var handler;
      for (i in handlers) {
        handler = handlers[i];
        event.menuItem = sender;
        var result = handler(event);
        if (result) {
          application.eventPreventDefault(event);
          return false;
        }
      } 
    }
  }
  
  this.menuItemMouseOverHandler = function(event) {
    var ownerMenu = sender.menuItems.ownerMenu;
    event.item = sender;
    if (sender.hasChildren) {
      sender.menuItems.show();
      sender.instance.firstChild.className = ownerMenu.menuItemHoveredStyle;
    }
    if ((handlers = ownerMenu.events['itemhover']) != null) {
      var handler;
      for (i in handlers) {
        handler = handlers[i];
        event.menuItem = sender;
        var result = handler(event);
        if (result) {
          application.eventPreventDefault(event);
          return false;
        }
      } 
    }
  }
  
  this.menuItemMouseOutHandler = function(event) {
    
    var ownerMenu = sender.menuItems.ownerMenu; 
    event.item = sender;
    
    if (sender.hasChildren) {
      sender.menuItems.hide();
      sender.instance.firstChild.className = ownerMenu.menuItemStyle;
    }
    if ((handlers = ownerMenu.events['itemleave']) != null) {
      var handler;
      for (i in handlers) {
        handler = handlers[i];
        event.menuItem = sender;
        var result = handler(event);
        if (result) {
          application.eventPreventDefault(event);
          return false;
        }
      } 
    }
    
  }
  
  this.menuItems = new bmMenuItems(application, this, {'name': 'menuItems'});
  
}

bmMenuItem.prototype.id = null;
bmMenuItem.prototype.menuItems = null;
bmMenuItem.prototype.instance = null;
bmMenuItem.prototype.hasChildren = false;
bmMenuItem.prototype.active = false;

function bmMenuItems(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmMenuItems.inherit(bmObject);

bmMenuItems.prototype.items = null;
bmMenuItems.prototype.instance = null;
bmMenuItems.prototype.ownerMenu = null;

bmMenuItems.prototype.create = function(application, owner, parameters) {

  this.type = 'bmMenuItems';
  this.className = 'bmMenuItems';
  this.items = new Array();
  bmObject.prototype.create.call(this, application, owner, parameters);
  this.ownerMenu = this.getOwnerMenu(); 
  
}

bmMenuItems.prototype.getOwnerMenu = function() {

  var ownerMenu = this.owner;
  
  while (ownerMenu.className != 'bmMenu') {
    ownerMenu = ownerMenu.owner;
  }
  
  return ownerMenu;
  
}

bmMenuItems.prototype.add = function(element, parameters) {

  parameters['name'] = element.id;
  var menuItem = new bmMenuItem(this.application, this, parameters);
  menuItem.instance = element;
  element.componentAccess = menuItem;
  return menuItem;
  
  
}

bmMenuItems.prototype.get = function(element) {

  return this.items[element.id];
  
}

bmMenuItems.prototype.show = function() {

  var parentItem = this.owner.instance;
  
  var y = parentItem.offsetTop + parentItem.offsetHeight;
  
  this.instance.style.left = '0';
  this.instance.style.top = y + 'px';
  this.instance.style.display = 'block';
  
}

bmMenuItems.prototype.hide = function() {
  this.instance.style.display = 'none';
}

//MENU

function bmMenu(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmMenu.inherit(bmCustomControl);

bmMenu.prototype.currentMenuItem = null;
bmMenu.prototype.currentMenuItems = null;
bmMenu.prototype.subItemsHideDelay = 0;  
bmMenu.prototype.menuItemStyle = '';
bmMenu.prototype.menuItemHoveredStyle = '';

bmMenu.prototype.create = function(application, owner, parameters) {
  this.type = 'bmMenu';
  this.className = 'bmMenu';
  this.ownEvents = {'itemclick': 1, 'itemhover': 1, 'itemleave': 1};
  this.menuItems = new bmMenuItems(application, this, {'name': 'menuItems'});
  bmCustomControl.prototype.create.call(this, application, owner, parameters);
}

bmMenu.prototype.ownInitialize = function() {
  
  this.control = this.instance;
  this.attachOwnEvents(this.instance);
  
}

bmMenu.prototype.attachOwnEvents = function(node) {

  var childNode = null;
  var menuItem = null;
  var saveMenuItem = null;
  var saveMenuItems = null;
  var i;
  for (i = 0; i < node.childNodes.length; ++i) {
    menuItem = null;
    childNode = node.childNodes.item(i);
    if (childNode.nodeName == 'UL' || childNode.nodeName == 'LI') {
      if (childNode.nodeName == 'UL') {
        saveMenuItems = this.currentMenuItems;
        if (this.currentMenuItem != null) {
          this.currentMenuItems = this.currentMenuItem.menuItems;
        } else {
          this.currentMenuItems = this.menuItems;
        }
        this.currentMenuItems.instance = childNode;
        childNode.componentAccess = this.currentMenuItems;
      } else if (childNode.nodeName == 'LI') {
        if (childNode.className.indexOf('hasChildren') != -1) {
          menuItem = this.currentMenuItems.add(childNode, {'hasChildren': true});
          menuItem.hasChildren = true;
          saveMenuItem = this.currentMenuItem;
          this.currentMenuItem = menuItem;
        } else {
          menuItem = this.currentMenuItems.add(childNode, {'hasChildren': false});
        }
        application.attachEvent(menuItem, 'mouseover', menuItem.menuItemMouseOverHandler, true);
        application.attachEvent(menuItem, 'mouseout', menuItem.menuItemMouseOutHandler, true);
        application.attachEvent(menuItem, 'click', menuItem.menuItemClickHandler, true);
        application.attachEvent(menuItem, 'keypress', menuItem.menuItemClickHandler, true);
      }
    }
    this.attachOwnEvents(childNode);
  }
  if (node.nodeName == 'UL' && saveMenuItems != null) {
    this.currentMenuItems = saveMenuItems;
  }

}

bmMenu.prototype.recreateEvents = function() {

  bmCustomControl.prototype.recreateEvents.call(this);
  this.attachOwnEvents(this.instance);

}

