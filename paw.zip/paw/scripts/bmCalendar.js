function bmCalendar(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCalendar.inherit(bmCustomControl);

bmCalendar.prototype.create = function(application, owner, parameters) {

  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  
}
