function recalculateLayout() {
  cwidth = (getDocumentWidth() > getWindowWidth()) ? getDocumentWidth() : getWindowWidth();
  cheight = (getDocumentHeight() > getWindowHeight()) ? getDocumentHeight() : getWindowHeight();
  cleft = (cwidth - element.offsetWidth) / 2;
  ctop = (cheight - element.offsetHeight) / 2;
  element.style.left = cleft + "px";
  element.style.top = ctop + "px";
}
