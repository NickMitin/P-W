function bmDataPanel(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmDataPanel.inherit(bmCustomPanel);

bmDataPanel.prototype.create = function(application, owner, parameters) {

  bmCustomPanel.prototype.create.call(this, application, owner, parameters);

}

bmDataPanel.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + "Panel");
  
}

bmDataPanel.prototype.submit = function (reload, handler) {
  if (reload) {
    this.control.submit();
  } else if ((typeof handler == 'function') || (handler == null)) {
    application.httpGateway.sendForm('/chat/main.php', this.control.id, handler)
  } else {
    //TODO: ERROR;
  }
}
