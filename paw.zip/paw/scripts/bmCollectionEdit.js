function bmCollectionEditOpen(component, collection) {
  window.open("./main.php?application.switchForm=fCollectionEdit&application.fCollectionEdit.component=" + component + "&application.fCollectionEdit.collection=" + collection, "blank", "width=400, height=600");
  return false;
}
