function bmDateEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmDateEdit.inherit(bmCustomEdit);

bmDateEdit.prototype.trigger = null;

bmDateEdit.prototype.create = function(application, owner, parameters) {

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}

bmDateEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + "Edit");  

}
