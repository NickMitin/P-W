function bmApplication(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
  
}

bmApplication.inherit(bmObject);

bmApplication.prototype.formName = '';
bmApplication.prototype.activeForm = null;
bmApplication.prototype.path = '/';

bmApplication.prototype.create = function(application, owner, parameters) {

  bmObject.prototype.create.call(this, application, owner, parameters);
  
  this.httpGateway = new bmHTTPRequest(this, this, null);
  this.userInfo = new bmUserInfo(this, this, null);
  this.cgi = new bmCGI(this, this, null);
  this.userPopupCache = new Array();
  
  var sender = this;
  
  this.onGetUserInfo = function(event) {
    sender.userInfo.initialize(event.data);
  }
  
  this.getUserInfo();
  
}

bmApplication.prototype.getUserInfo = function() {
  this.httpGateway.get('/chat/main.php?application.getUserInfo=1', this.onGetUserInfo);
}

bmApplication.prototype.attachEvent = function(component, eventName, handler, toInstance) {
  if (handler != null) {
    if (toInstance) {
      component = component.instance;
    } else {
      if ((component.control != null) && (typeof component.control == 'object')) {
        component = component.control;
      }
    }
    if (typeof component.attachEvent == "object") {
      component.attachEvent("on" + eventName, handler);
    } else if (typeof component.addEventListener == "function") {
      component.addEventListener(eventName, handler, false);
    }                                                       
  }
}

bmApplication.prototype.getElementOffsetTop = function(element) {
  
  var top = 0;

  while (element.offsetParent) {
    top += element.offsetTop;
    element = element.offsetParent;
  }
  return top;  
  
}

bmApplication.prototype.getElementOffsetLeft = function(element) {
  
  var left = 0;

  while (element.offsetParent) {
    left += element.offsetLeft;
    element = element.offsetParent;
  }
  return left;  
  
}

bmApplication.prototype.getElementHeight = function(element) {

  return element.offsetHeight;
  
}

bmApplication.prototype.createForm = function(url, name, parameters) {
  if (name == null) {
    name = '_self';
  }
  return window.open(url, name, parameters);
}

bmApplication.prototype.eventPreventDefault = function(event) {

  if (event.preventDefault) {
    event.preventDefault();
    event.stopPropagation();
  } else {
    event.returnValue = false;
  }
}

bmApplication.prototype.getOriginalEventElement = function(event, nodeName) {
  
  if (typeof event.target == 'object') {
    return event.target;
  } else {
    var currentTarget = event.srcElement;
    if (nodeName != null) {
      while (currentTarget.nodeName != nodeName) {
        currentTarget = currentTarget.parentNode;
      }
    }
    return currentTarget;
  }
  
}

bmApplication.prototype.getEventElement = function(event, nodeName) {
  
  if (typeof event.currentTarget == 'object') {
    return event.currentTarget;
  } else {
    var currentTarget = event.srcElement;
    if (nodeName != null) {
      while (currentTarget.nodeName != nodeName) {
        currentTarget = currentTarget.parentNode;
      }
    }
    return currentTarget;
  }
  
}

var application = new bmApplication(null, null, null);
