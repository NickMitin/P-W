var requests = new Array();

function deleteRequests() {
  for (i = 0; i < requests.length; ++i) {
    
    if (requests[i] && requests[i].done) {
      delete requests[i].fRequest['onreadystatechange'];
      delete requests[i].fRequest;
      delete requests[i];
    }
  }
  setTimeout(deleteRequests, 1000);
}

setTimeout(deleteRequests, 1000);

function bmHTTPRequestWrapper(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
  
  var sender = this;
  
  this.createRequest();
  
  this.fRequest.open(parameters["method"], parameters["url"], true);
  
  this.fRequest.onreadystatechange = function() {
    if (sender.fRequest.readyState == 4) {
      var status = 200;
      try {
        status = sender.fRequest.status;
      } catch(error) {
        status = 200;
      }
      if (status == 200 || status == 0) {
        var event = new Array();
        event["data"] = sender.fRequest.responseText;
        if (parameters["handler"] != null) {
          parameters["handler"](event);
        }
        
      } else {
      }
      sender.done = true;
    }
  }
  
  var i;
  var headers = new Array();
  var headers = parameters["headers"];
  if (parameters["headers"] !== null) {                          
    for (i in parameters["headers"]) {
      this.fRequest.setRequestHeader(i, parameters["headers"][i]);
    }
  }
  this.fRequest.send(parameters["data"]);

}

bmHTTPRequestWrapper.inherit(bmObject);

bmHTTPRequestWrapper.prototype.fRequest = null;
bmHTTPRequestWrapper.prototype.done = false;

bmHTTPRequestWrapper.prototype.create = function(application, owner, parameters) {

  bmObject.prototype.create.call(this, application, owner, parameters);
  
}

bmHTTPRequestWrapper.prototype.createRequest = function() {
  if (typeof ActiveXObject == "function") {
    this.fRequest = new ActiveXObject("Microsoft.XMLHTTP");
  } else if (typeof XMLHttpRequest == "function") {
    this.fRequest = new XMLHttpRequest();
  }
}

function bmHTTPRequest(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmHTTPRequest.inherit(bmObject);

bmHTTPRequest.prototype.fRequest = null;
bmHTTPRequest.prototype.fQueue = null;

bmHTTPRequest.prototype.create = function(application, owner, parameters) {

  bmObject.prototype.create.call(this, application, owner, parameters);

}

bmHTTPRequest.prototype.execute = function(method, url, data, headers, handler) {
  parameters = new Array();
  parameters["method"] = method;
  parameters["url"] = url;
  parameters["data"] = data;
  parameters["headers"] = headers;
  parameters["handler"] = handler;
  requests[requests.length] = new bmHTTPRequestWrapper(application, this, parameters);
}

bmHTTPRequest.prototype.execute_1 = function(method, url, data, headers, control) {
  parameters = new Array();
  parameters["method"] = method;
  parameters["url"] = url;
  parameters["data"] = data;
  parameters["headers"] = headers;
  parameters["control"] = control;
  var request = new bmHTTPRequestWrapper(application, this, parameters);
}

bmHTTPRequest.prototype.get = function(request, handler) {
  var headers = new Array();
  headers["content-type"] = "text/html; charset=utf-8";
  this.execute("GET", request, null, headers, handler);
}

bmHTTPRequest.prototype.get_1 = function(request, control) {
  var headers = new Array();
  headers["content-type"] = "text/html; charset=utf-8";
  this.execute_1("GET", request, null, headers, control);
}

bmHTTPRequest.prototype.prepareFormData = function(formId) {
  var result = "";
  var element = null;
  var form = window.document.getElementById(formId);
  if (form != null) {
    for (i = 0; i < form.elements.length; ++i) {
      element = form.elements[i];
      var append = true;

      if ((element.checked === false) && ((element.type == 'radio') || (element.type == 'checkbox'))) {
        append = false;
      } 
      if (element.name.length == 0) {
        append = false;
      }
      
      if (append) {
        result += "--bmHTTPRequest\ncontent-disposition: form-data; name=\"" + element.name + "\"\ncontent-type: text/plain; charset=\"utf-8\"\n\n" + element.value + "\n";
      }
    }
  }
  result += "--bmHTTPRequest";
  return result;
}

bmHTTPRequest.prototype.sendForm = function(url, formId, handler) {
  var data = this.prepareFormData(formId);
  var headers = new Array();
  headers["connection"] = "close";
  headers["content-length"] = data.length;
  headers["content-type"] = "multipart/form-data; boundary=\"bmHTTPRequest\"";  
  this.execute("POST", url, data, headers, handler);
}

bmHTTPRequest.prototype.prepareData = function(data) {
  var result = "";
  var element = null;
  if (data != null) {
    var name = "";
    for (name in data) {                                                      
      result += "--bmHTTPRequest\ncontent-disposition: form-data; name=\"" + name + "\"\ncontent-type: text/plain; charset=\"utf-8\"\n\n" + data[name] + "\n";
    }
  }
  result += "--bmHTTPRequest";
  return result;
}

bmHTTPRequest.prototype.sendData = function(url, data, handler) {
  
  data = this.prepareData(data);
  var headers = new Array();
  headers["connection"] = "close";
  headers["content-length"] = data.length;
  headers["content-type"] = "multipart/form-data; boundary=\"bmHTTPRequest\"";     
  this.execute("POST", url, data, headers, handler);
  
}
