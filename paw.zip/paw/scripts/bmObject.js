Function.prototype.inherit = function(parentClassOrObject) { 
	if (parentClassOrObject.constructor == Function) { 
		this.prototype = new parentClassOrObject(null, null, false);
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject.prototype;
	} else { 
		this.prototype = parentClassOrObject;
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject;
	} 
	return this;
}

function bmObject(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmObject.prototype.className = 'bmObject'

bmObject.prototype.create = function(application, owner, parameters) {
  this.application = application;
  this.owner = owner;
  this.parameters = parameters;
}

bmObject.prototype.type = 'bmObject';
