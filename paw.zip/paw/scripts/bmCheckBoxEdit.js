function bmCheckBoxEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCheckBoxEdit.inherit(bmCustomEdit);

bmCheckBoxEdit.prototype.trigger = null;

bmCheckBoxEdit.prototype.create = function(application, owner, parameters) {
  
  var sender = this;
  
  this.clickHandler = function(event) {
  
    if ((sender.trigger != null) && (sender.control != null)) {
      var value = (sender.trigger.checked) ? "1" : "0";
      sender.setValue(value);
    }
    
  }
  
  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}

bmCheckBoxEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + 'Edit');
  this.trigger = document.getElementById(this.name + 'Trigger');
  application.attachEvent(this.trigger, "click", this.clickHandler);
  
} 

bmCheckBoxEdit.prototype.recreateEvents = function() {
  bmCustomControl.prototype.recreateEvents.call(this);
  application.attachEvent(this.trigger, "click", this.clickHandler);
}
