function bmChat(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmChat.inherit(bmCustomControl);

bmChat.prototype.lastId = 0;
bmChat.prototype.roomId = 0;
bmChat.prototype.getRepliesTimeout = 15000;

bmChat.prototype.replies = new Array();
bmChat.prototype.repliesContainer = null;
bmChat.prototype.replyPattern = '';

bmChat.prototype.anchor = null;

bmChat.prototype.create = function(application, owner, parameters) {

  bmCustomControl.prototype.create.call(this, application, owner, parameters);
  
  var sender = this;
  
  sender.onGetReplies = function(event) {
  
    sender.instance.innerHTML = event.data;
    
    sender.state = 'idle';
    
    setTimeout(sender.getReplies, sender.getRepliesTimeout);
  
  }
  
  bmChat.prototype.getReplies = function() {
  
    if (sender.state == 'idle') {
      sender.state = 'reloading';
      //debugger;
      application.httpGateway.get('/chat/main.php?application.' + sender.ownerForm.name + '.' + sender.name + '.roomId=' + sender.roomId + '&application.' + sender.ownerForm.name + '.' + sender.name + '.getReplies=' + sender.lastId, sender.onGetReplies);
    } else {
      setTimeout(sender.getReplies, sender.getRepliesTimeout);
    }

  }
  
  bmChat.prototype.onGetReplyPattern = function(event) {

    sender.replyPattern = event.data;
  
  }
  
  //application.httpGateway.get('/main.php?' + sender.getComponentString() + '.getReplyPattern=1', sender.onGetReplyPattern);
  
}

bmChat.prototype.ownInitialize = function() {
  this.repliesContainer = document.getElementById(this.name + 'RepliesContainer');
  this.anchor = document.getElementById(this.name + 'Anchor');
  this.buffer = document.createElement('table');
}

bmChat.prototype.addReply = function(replyText) {

  var newReply = document.createElement('div');
  var replyText = this.replyPattern;
  replyText = replyText.replace(/%userName%/g, application.userInfo.id);
  replyText = replyText.replace(/%replyText%/g, replyText);
  newReply.innerHTML = replyText;
  this.repliesContainer.insertBefore(newReply.firstChild, this.anchor);
  
}
