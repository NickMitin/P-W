function bmCollection(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCollection.inherit(bmObject);

bmCollection.prototype.collectionItemClass = "bmCollectionItem";

bmCollection.prototype.add = function(keyValue) {
  var newItem = new this.collectionItemClass(this.application, this, null);
  //newItem.
}
