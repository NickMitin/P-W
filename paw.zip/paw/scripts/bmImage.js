function bmImage(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }
  
  var sender = this;

}

bmImage.inherit(bmCustomControl);

bmImage.prototype.zoom = false;

bmImage.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Image');
  this.attachOwnEvents(this.instance);
  
}

bmImage.prototype.attachOwnEvents = function() {
  if (this.zoom) {
    application.attachEvent(this.instance, 'mouseover', this.mouseOverHandler);
  }
}

bmImage.prototype.getPicture = function() {
  return this.control.src;
}

bmImage.prototype.setPicture = function(picture) {
  this.control.src = picture;
}

bmImage.prototype.recreateEvents = function() {

  bmCustomControl.prototype.recreateEvents.call(this);
  this.attachOwnEvents(this.instance);

}
