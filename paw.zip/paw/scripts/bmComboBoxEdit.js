function bmComboBoxEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmComboBoxEdit.inherit(bmCustomEdit);

bmComboBoxEdit.prototype.create = function(application, owner, parameters) {

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}

bmComboBoxEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + "Edit"); 
  
}
