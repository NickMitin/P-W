function bmHyperLinkEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmHyperLinkEdit.inherit(bmCustomEdit);

bmHyperLinkEdit.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Edit');
  
}
