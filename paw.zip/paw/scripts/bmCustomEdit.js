function bmCustomEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCustomEdit.inherit(bmCustomControl);

bmCustomEdit.prototype.setValue = function(value) {
  this.control.value = value;
}

bmCustomEdit.prototype.getValue = function() {
  return this.control.value;
}


