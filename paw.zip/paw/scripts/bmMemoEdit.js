function bmMemoEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmMemoEdit.inherit(bmCustomEdit);

bmMemoEdit.prototype.allowBBCode = true;

bmMemoEdit.prototype.ownInitialize = function() {
  
  this.control = document.getElementById(this.name + 'Edit');
  
}

bmMemoEdit.prototype.wrapSelection = function(start, end) {

  this.control.focus();
  
  if (typeof this.control.selectionEnd == 'number') {
    var textLength = this.control.textLength;
	  var selectionStart = this.control.selectionStart;
	  var selectionEnd = this.control.selectionEnd;
	  var before = this.control.value.substring(0, selectionStart);
	  var text = this.control.value.substring(selectionStart, selectionEnd)
	  var after = this.control.value.substring(selectionEnd, textLength);
	  this.control.value = before + start + text + end + after;
    this.control.selectionStart = selectionStart + start.length;
    this.control.selectionEnd = this.control.selectionStart + text.length;
  } else if (document.selection) {
    document.selection.createRange().text =  start + document.selection.createRange().text + end;
  }
  
}

bmMemoEdit.prototype.insertAtCursor = function(text) {

  this.control.focus();
	
  if (typeof this.control.selectionEnd == 'number') {
    var textLength = this.control.textLength;
	  var selectionStart = this.control.selectionStart;
	  var selectionEnd = this.control.selectionEnd;
	  var before = this.control.value.substring(0, selectionStart);
	  var after = this.control.value.substring(selectionEnd, textLength);
	  this.control.value = before + text + after;
    this.control.selectionStart = selectionStart + text.length;
    this.control.selectionEnd = selectionStart + text.length;
  } else if (document.selection) {
    document.selection.createRange().text = text; 
  } 
  
}

bmMemoEdit.prototype.bbCodeSelection = function(code, parameter) {
  
  if (this.allowBBCode) {
    var start = (parameter) ? '[' + code + '=' + parameter + ']' : '[' + code + ']';
    this.wrapSelection(start, '[/' + code + ']');
  }
  
}

bmMemoEdit.prototype.boldSelection = function() {
  this.bbCodeSelection('b');
}

bmMemoEdit.prototype.underlineSelection = function() {
  this.bbCodeSelection('u');
}

bmMemoEdit.prototype.italicSelection = function() {
  this.bbCodeSelection('i');
}

bmMemoEdit.prototype.fontSizeSelection = function(fontSize) {
  this.bbCodeSelection('font', fontSize);
}

bmMemoEdit.prototype.insertImage = function(image) {
  this.bbCodeSelection('img', image);
}


