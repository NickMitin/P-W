function bmCustomControl(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmCustomControl.inherit(bmComponent);

bmCustomControl.prototype.events = null;
bmCustomControl.prototype.saveCursor = '';
bmCustomControl.prototype.instance = '';
bmCustomControl.prototype.initialization = '';
bmCustomControl.prototype.ownerForm = '';
bmCustomControl.prototype.reloadUrl = '';
bmCustomControl.prototype.state = 'undefined';

bmCustomControl.prototype.create = function(application, owner, parameters) {
  
  bmComponent.prototype.create.call(this, application, owner, parameters);
  
  this.state = 'creating';
  
  var me = this;
  
  this.reloadHandler = function(event) {
    if (me.instance != null) {
      me.replaceContent(event['data']);
    }
    me.state = 'idle';
    me.setCursor(me.saveCursor);
    if (me.userReloadHandler) {
      me.userReloadHandler(event);
    }
    return;
  }
  
  this.events = new Array();
  
  var owner = this;
  
  while (owner.type != 'bmHTMLForm') {
    owner = owner.owner;
  }
  
  this.ownerForm = owner;
  
  /*if ((this.owner.type != 'bmHTMLForm') && (this.type != 'bmHTMLForm')) {
    //this.ownerForm[parameters['name']] = this;
    var s = 'ded';
    this.ownerForm.(name) = 1;
    alert(this.ownerForm);
    //alert(this.ownerForm.ded);
    //alert(this.ownerForm.s);
  } */
  
  this.initialize(false); 
  
  this.state = 'idle';

} 

bmCustomControl.prototype.initialize = function(recreateEvents) {

  this.instance = document.getElementById(this.name);
  if (this.instance) {
    this.initialization = document.getElementById(this.name + 'Initialization');
    if (this.initialization) {
      eval(this.initialization.innerHTML);
    }
    if (this.ownInitialize) {
      this.ownInitialize();
    }
    if (this.recreateEvents && recreateEvents) {
      this.recreateEvents();
    }
  }
  if (recreateEvents) {
    for (i in this.components) {
      this.components[i].initialize(true);
    }
  }
}

bmCustomControl.prototype.recreateEvents = function() {
  
  for (eventName in this.events) {
    for (handler in this.events[eventName]) {
      application.attachEvent(this, eventName, this.events[eventName][handler]);
    }
  }
  
  var component = null;

}

bmCustomControl.prototype.getEventElement = function(event){
  
  if (typeof event.currentTarget == 'object') {
    return event.currentTarget;
  } else {
    return event.srcElement;
  }
  
}

bmCustomControl.prototype.getInitialEventElement = function(event){
  
  if (typeof event.target == 'object') {
    return event.target;
  } else {
    return event.srcElement;
  }
  
}

bmCustomControl.prototype.replaceContent = function(content) {

  //if (typeof this.instance.outerHTML == 'undefined') {
  
    var buffer = this.ownerForm.createBufferElement();
    buffer.innerHTML = content;
    var parent = this.instance.parentNode;
    var newInstance = buffer.firstChild.cloneNode(true);
    parent.replaceChild(newInstance, this.instance);
    this.ownerForm.deleteBufferElement(buffer); 
    this.initialize(true);
  
  //} else {
    
  //}
  //debugger;

}

bmCustomControl.prototype.control = null;
bmCustomControl.prototype.ownEvents = null;

bmCustomControl.prototype.setTop = function(value) {
  this.instance.style.top = value + 'px';
}

bmCustomControl.prototype.getTop = function() {
  return this.instance.offsetTop;
}

bmCustomControl.prototype.getHeight = function() {
  return this.instance.offsetHeight;
}

bmCustomControl.prototype.setLeft = function(value) {
  this.instance.style.left = value + 'px';
}

bmCustomControl.prototype.getLeft = function() {
  return this.instance.offsetLeft;
}

bmCustomControl.prototype.setCursor = function(value) {
  if (this.instance) {
    this.instance.style.cursor = value;
  }
}                                     

bmCustomControl.prototype.getCursor = function() {
  if (this.instance) {
    return this.instance.style.cursor;
  }
}

bmCustomControl.prototype.setVisible = function(value) {
  if (value) {
    this.instance.style.display = 'block';
  } else {
    this.instance.style.display = 'none';
  }
}                                     

bmCustomControl.prototype.getVisible = function() {
  return !(this.instance.style.display == 'none');
}

bmCustomControl.prototype.reload = function(parameters, handler) {
  
  if (this.state == 'idle') {
    this.saveCursor = this.getCursor();
    this.setCursor('wait');
    this.state = 'reloading';

    var url = this.getReloadUrl();
    if (parameters != null) {
      for (i in parameters) {
        url += '&' + i + '=' + parameters[i];
      }
    }
    this.userReloadHandler = handler;
    application.httpGateway.get(url, this.reloadHandler);
  }
}

bmCustomControl.prototype.createEvent = function(eventName) {
  if (this.events == null) {
    this.events = new Array();
  } else if (this.events[eventName] == null) {
    this.events[eventName] = new Array();
  }
  return this.events[eventName];
}

bmCustomControl.prototype.attachEvent = function(eventName, handler, toInstance) {

  var event = null;
  if ((event = this.events[eventName]) == null) {
    event = this.createEvent(eventName);
  }
  event.push(handler);
  
  if (this.ownEvents == null || (this.ownEvents != null && this.ownEvents[eventName] == null)) {
    application.attachEvent(this, eventName, handler, toInstance);
  }
}

bmCustomControl.prototype.getReloadUrl = function() {
  if (this.reloadUrl == '') {
    var formName = this.ownerForm.name;
    var control = this.name;
    this.reloadUrl = '/chat/main.php?application.switchForm=' + formName + '&application.' + formName + '.drawControl=' + control;
  }
  return this.reloadUrl;
}

