function bmFileEdit(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmFileEdit.inherit(bmCustomEdit);

bmFileEdit.prototype.create = function(application, owner, parameters) {

  bmCustomEdit.prototype.create.call(this, application, owner, parameters);

}

bmFileEdit.prototype.ownInitialize = function() {

  this.control = document.getElementById(this.name + "Edit");   

}
