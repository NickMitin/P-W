function bmBBCodeFormatter(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bmBBCodeFormatter.inherit(bmObject);
