<?php

  class bm%formName% extends bmHTMLForm {
    
    public function constructor($application, $owner, $parameters) {

      parent::constructor($application, $owner, $parameters);

    }
    
    public function %formName%Drawing($sender, $parameters) {

    } 
    
    public function %formName%Initialize($sender, $parameters) {

    }

  }                                                                             

  class bmHTML%formName%Painter extends bmHTMLFormPainter {

  }
  
  class bm%formName%Styles extends bmCustomControlStyles {
    
  }
  
?>
