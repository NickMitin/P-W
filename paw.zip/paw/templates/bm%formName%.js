function bm%formName%(application, owner, parameters) {

  if (parameters !== false) {
    this.create(application, owner, parameters);
  }

}

bm%formName%.inherit(bmHTMLForm);

bm%formName%.prototype.load = function(sender, event) {}

application.%formName% = new bm%formName%(application, application, {'name': '%formName%'}); 
